
#include "stdwin.h"
#include "style.h"

void
wsetitalic()
{
	wattr.style |= ITALIC;
	setattr ();
}

