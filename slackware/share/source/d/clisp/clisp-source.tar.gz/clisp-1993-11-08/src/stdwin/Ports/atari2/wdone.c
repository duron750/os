
#include "window.h"

extern int (*OldInter)();
int ButInter();

void
wdone()
{
	while ( nrwin > 0 ) wclose(winlist[nrwin-1]);

	vex_butv(vdi_handle,OldInter,&OldInter);

	delmenubar();
	evnt_dclick(ClickSpeed,1);			/* Old Speed */

	graf_mouse(0,(MFORM *)0);		/* Set back to arrow */

	if ( mouseoff ) {
		graf_mouse (M_ON, (MFORM *)0);
		mouseoff = FALSE;
	}
	v_clsvwk(vdi_handle);
	appl_exit();

	resetfonts();
	vdi_handle = -1;
}

