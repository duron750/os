
#include "stdwin.h"
#include "style.h"

void
wsetbitalic()
{
	wattr.style |= BOLD | ITALIC;
	setattr ();
}

