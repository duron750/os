
#include "window.h"

/*
	We force the scrolling by moving the origin of the window.
*/

void
autoscroll(win, h, v)
WINDOW	*win;
int	h;
int	v;
{
	int	dh = 0;
	int	dv = 0;

	if (win == NULL) return;

	if ( h < win->h )                    dh = h - win->h;
	else if ( h > win->h + win->width )  dh = h - (win->h + win->width);

	if ( v < win->v )                    dv = v - win->v;
	else if ( v > win->v + win->height ) dv = v - (win->v + win->height);

	if ( dh != 0 || dv != 0 ) {
		int	orgh = win->orgh + dh;
		int	orgv = win->orgv + dv;

		wsetorigin (win, orgh, orgv);
	}
}

