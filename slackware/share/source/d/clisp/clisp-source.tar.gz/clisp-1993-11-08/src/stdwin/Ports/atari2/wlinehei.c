
#include "window.h"

int
wlineheight ()
{
	return (chheight);
}

