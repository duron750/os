#include "stdwin.h"
#include "style.h"

TEXTATTR wattr;
int vst_effects(int handle,int effect);

extern int vdi_handle;

void
setattr()
{
	int	effect = 0;

	if ( wattr.style & BOLD )      effect |= 0x01;
	if ( wattr.style & ITALIC )    effect |= 0x04;
	if ( wattr.style & UNDERLINE ) effect |= 0x08;
	if ( wattr.style & HILITE )    effect |= 0x01;
	if ( wattr.style == PLAIN )    effect  = 0x00;

	vst_effects (vdi_handle, effect);
}

