
#include "stdwin.h"
#include "style.h"

void
wsetbold()
{
	wattr.style |= BOLD;
	setattr ();
}

