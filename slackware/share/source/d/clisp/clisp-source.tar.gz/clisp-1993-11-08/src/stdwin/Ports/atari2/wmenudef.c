
#include "window.h"

void
wmenudeflocalset(flag)
int	flag;
{
	deflocal = flag;
}

