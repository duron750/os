
#include <tos.h>

void
wfleep ()
{
	Cconws("\07\07");
}

