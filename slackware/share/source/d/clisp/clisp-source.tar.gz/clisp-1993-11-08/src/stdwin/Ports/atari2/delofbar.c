
#include "window.h"

void
delofbar(pbar, pm)
struct menubar *pbar;
void *pm;
{
	int	i;

	for (i = 0; i < pbar->nrmenus; i++) {
		if (pbar->menulist[i] == (MENU *)pm) {
			L_REMOVE (pbar->nrmenus, pbar->menulist, MENU *, i);
			break;
		}
	}
}

