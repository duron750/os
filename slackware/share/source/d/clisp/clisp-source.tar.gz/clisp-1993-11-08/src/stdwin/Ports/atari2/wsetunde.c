
#include "stdwin.h"
#include "style.h"

void
wsetunderline()
{
	wattr.style |= UNDERLINE;
	setattr ();
}

