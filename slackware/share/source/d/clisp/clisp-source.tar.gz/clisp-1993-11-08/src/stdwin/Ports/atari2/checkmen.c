
#include "window.h"

void
checkmenu(pm)
void *pm;
{
	int	k;

	for (k = 0; k < ((MENU *)pm)->nritems; k++) {
		struct m_item *i = ((MENU *)pm)->itemlist[k];
		char buf[256];
		char *cp = buf;
		char *text  = i->ittext;
		int	l;

		if (i->line != NULL && strlen (i->line) == ((MENU *)pm)->maxlen)
			continue;

		FREE (i->line);

		if (text == NULL)
			text = "";

		if (*text == '\0') {
			for (l = 0; l < ((MENU *)pm)->maxlen; ++l)
				*cp++ = '-';
			*cp = '\0';
		}
		else {
			*cp++ = ' '; *cp++ = ' ';
			while ( *text ) *cp++ = *text++;

			text = i->sctext;
			if (text != NULL) {
				l = cp - buf;
				l += strlen (text);
				while (l < ((MENU *)pm)->maxlen - 1) {
					++l;
					*cp++ = ' ';
				}
				while ( *text ) *cp++ = *text++;
			}
			*cp++ = ' ';
			*cp = '\0';
		}
		i->line = strdup(buf);
	}
	((MENU *)pm)->dirty = FALSE;
}

