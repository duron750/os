
#include "window.h"

void
rmcaret()
{
	WINDOW *win = active;

	if ( win != NULL && win->careton ) {
		draWcaret(win);
		win->careton = FALSE;
	}
}

