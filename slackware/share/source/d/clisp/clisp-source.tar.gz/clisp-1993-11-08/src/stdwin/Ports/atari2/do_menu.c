
#include "window.h"

int menu_is_open = 0;

void
do_menu(ep, msg_buf)
EVENT *ep;
int msg_buf[8];
{
	menu_is_open = 1;
	if ( m_link[msg_buf[4]].m != m_link[msg_buf[3]].m ||
						m_link[msg_buf[4]].it == -1 ) return;

	menu_tnormal(menu, msg_buf[3], 1);
	
	if ( m_link[msg_buf[4]].m == 0 ) {
		if ( m_link[msg_buf[4]].it == 0 ) {
			int	x_pos, y_pos, w_pos, h_pos;

			graf_mouse (ARROW, (MFORM *)0);
			form_center (w_u_about, &x_pos, &y_pos, &w_pos, &h_pos);
			form_dial (0, 0,0,0,0, x_pos, y_pos, w_pos, h_pos);
			objc_draw (w_u_about, ROOT, MAX_DEPTH, x_pos, y_pos, w_pos, h_pos);
			form_do (w_u_about, 0);
			form_dial (3, 0,0,0,0, x_pos, y_pos, w_pos, h_pos);
			graf_mouse (BUSY_BEE, (MFORM *)0);

			w_u_about[w_u_about[1].ob_tail].ob_state &= ~SELECTED;
			menu_is_open = 0;
		}

		return;
	}
	
	menu_is_open = 0;
	ep->type = WE_MENU;
	ep->window = active;
	ep->u.m.id = m_link[msg_buf[4]].m;
	ep->u.m.item = m_link[msg_buf[4]].it;
}

