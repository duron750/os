
#include <stdio.h>
#define NDEBUG
#include <assert.h>
#include "trees.h"

bool
tr_parent(t)
register TREE *t;
{
	register int old;
	if ( t->focus == 0 ) return FALSE;
	do {
		old = t->focus;
		t->focus = NEXT(t->focus);
		assert(t->focus >= 0 && t->focus < t->nobjs);
	} while (TAIL(t->focus) != old);
	return TRUE;
}

