
#include "window.h"

void
wxorline(beg_h, beg_v, end_h, end_v)
int beg_h;
int beg_v;
int end_h;
int end_v;
{
	int line[4];

	if ( drawing == NULL ) return;

	line[0] = beg_h + extrah;
	line[1] = beg_v + extrav;
	line[2] = end_h + extrah;
	line[3] = end_v + extrav;

	if ( curr_mode != 3 ) {
		vswr_mode(vdi_handle, 3);
		curr_mode = 3;
	}

	v_pline(vdi_handle, 2, line);
}

