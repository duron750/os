
#include "window.h"

void
wsetwintextattr(win, attr)
WINDOW *win;
TEXTATTR *attr;
{
	if ( win == NULL ) return;
	win->attr = *attr;
}

