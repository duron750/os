
#include "trees.h"

bool
tr_child(t)
register TREE *t;
{
	register int new = HEAD(t->focus);
	if ( new < 0 ) return FALSE;
	t->focus = new;
	return TRUE;
}

