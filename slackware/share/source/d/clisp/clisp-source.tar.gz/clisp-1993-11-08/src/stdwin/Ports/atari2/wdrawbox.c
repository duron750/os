
#include "window.h"

void
wdrawbox(left, top, right, bottom)
int left;
int top;
int right;
int bottom;
{
	int box[10];

	if ( drawing == NULL ) return;
	
 	if ( left >= right || top >= bottom ) return; 	/* Empty box */
	
	box[0] = box[6] = box[8] = left + extrah;
	box[1] = box[3] = box[9] = top + extrav;
	box[2] = box[4] = right + extrah - 1;
	box[5] = box[7] = bottom + extrav - 1;

	if (curr_mode != 1) {
		vswr_mode(vdi_handle, 1);
		curr_mode = 1;
	}

	v_pline(vdi_handle, 5, box);
}

