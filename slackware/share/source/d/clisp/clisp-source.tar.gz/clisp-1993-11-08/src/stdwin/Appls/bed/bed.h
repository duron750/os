#include "stdwdefi.h"
#include "stdwin.h"

#define DEF_ROWS        48
#define DEF_COLS        48

/* bed.c */
extern void newraster _ARGS((void));
extern void setsqrsize _ARGS((void));
/* file.c */
extern bool readbitmap _ARGS((void));
extern bool writebitmap _ARGS((void));
/* fmenu.c */
extern bool do_quit _ARGS((void));
extern bool do_file_menu _ARGS((EVENT *ep));
/* mmenu.c */
extern void do_mode_menu _ARGS((EVENT *ep));
/* mouse.c */
extern void wxorrect _ARGS((int left, int top, int right, int bottom));
extern void drawselrect _ARGS((void));
extern int getbit _ARGS((int row, int col));
extern void setbit _ARGS((int row, int col, int value));
extern void plotline _ARGS((void (*fp)(), bool value));
extern void plotcircle _ARGS((void (*fp)(), bool value));
extern void do_mouse _ARGS((EVENT *ep));
/* opmenu.c */
extern void do_op_menu _ARGS((EVENT *ep));

