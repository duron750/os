char    l1[] = "STDWIN version 0.1" ;
char    l2[] = "by" ;
char    l3[] = "Henk Lohuis" ;
char    l4[] = "Copyright (c) 1988" ;
char    l5[] = "Stichting Mathematisch Centrum" ;
char    l6[] = "Amsterdam" ;
char    but[] = " Ok " ;
char    empty[] = "" ;

TEDINFO linf1[] = { l1, empty, empty, 3, 6, 2, 0x1180, 0x0, -1, 19 , 0 } ;
TEDINFO linf2[] = { l2, empty, empty, 5, 6, 2, 0x1180, 0x0, -1, 3, 0 } ;
TEDINFO linf3[] = { l3, empty, empty, 5, 6, 2, 0x1180, 0x0, -1, 12, 0 } ;
TEDINFO linf4[] = { l4, empty, empty, 5, 6, 2, 0x1180, 0x0, -1, 19, 0 } ;
TEDINFO linf5[] = { l5, empty, empty, 5, 6, 2, 0x1180, 0x0, -1, 31, 0 } ;
TEDINFO linf6[] = { l6, empty, empty, 5, 6, 2, 0x1180, 0x0, -1, 10, 0 } ;

OBJECT about[] = {
-1, 1, 1, G_BOX, NONE, OUTLINED, 0x21100L, 0, 0, 240, 240,
0, 2, 8, G_IBOX, NONE, OUTLINED, 0x11100L, 0, 0, 240, 240,
3, -1, -1, G_TEXT, NONE, NORMAL, linf1, 0, 8, 240, 16,
4, -1, -1, G_TEXT, NONE, NORMAL, linf2, 0, 40, 240, 16,
5, -1, -1, G_TEXT, NONE, NORMAL, linf3, 0, 60, 240, 16,
6, -1, -1, G_TEXT, NONE, NORMAL, linf4, 0, 114, 240, 16,
7, -1, -1, G_TEXT, NONE, NORMAL, linf5, 0, 136, 240, 16,
8, -1, -1, G_TEXT, NONE, NORMAL, linf6, 0, 156, 240, 16,
1, -1, -1, G_BUTTON, 0x27, NORMAL, but, 104, 200, 32, 16
} ;
