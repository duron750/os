
#include "window.h"

int     Fopen( const char *filename, int mode );
long    Fread( int handle, long count, void *buf );
long    Fseek( long offset, int handle, int seekmode );
int     Fclose( int handle );

WORKPARM getaparm(void);
static int firstcall = 1;

void
wsetfont(char *name)
{
	FONT newfont;
	WORKPARM w;
	int handle;
	long length;
	if ( vdi_handle != -1 ) return;		/* Too late to change the font */
	vdiworkparams = w = getaparm();
	if ( ( handle = Fopen(name,0) ) >= 0 ) {
		if ( ( length = Fseek(0L,handle,2) ) > 0 ) {
			Fseek(0L,handle,0);
			if ( ( newfont = (FONT)malloc(length) ) != 0 ) {
				if ( Fread(handle,length,(void *)newfont) == length ) {
					if ( newfont->hoffsettable )
						newfont->hoffsettable += (long)newfont;
					newfont->coffsettable += (long)newfont;
					newfont->fontdata     += (long)newfont;
					if ( firstcall ) {
						oldfont = w->font;
						firstcall = 0;
					}
					do {
						w->font = newfont;
					} while ( ( w = w->next ) >= (WORKPARM)0x800 );
					free(fontbuffer);
					fontbuffer = newfont;
				}
				else free(newfont);
			}
		}
		Fclose(handle);
	}
}
