
#include "window.h"

void
wcsettimer (win, ctime)
WINDOW	*win;
int	ctime;
{
	if (win == NULL) return;
	win->alarm = ( ctime > 0 ) ? mclock() + (ctime*10L): 0L;
}

