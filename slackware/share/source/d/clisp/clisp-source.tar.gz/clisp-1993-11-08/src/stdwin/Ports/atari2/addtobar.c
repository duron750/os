
#include "window.h"

void
addtobar(pbar,pm)
struct menubar *pbar;
void *pm;
{
	int	i;

	for (i = 0; i < pbar->nrmenus; i++) {
		if (pbar->menulist[i] == (MENU *)pm) return;
	}

	L_APPEND (pbar->nrmenus, pbar->menulist, MENU *, ((MENU *)pm));
}

