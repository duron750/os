/* Interactive Printer Queue Viewer -- Spooler Manipulation Commands */

#include "qview.h"

bool
do_delete(which)
        int which;
{
        char buf[BUFSIZ];
        sprintf(buf, "exec /usr/ucb/lprm -P%s %3.3s >/dev/null 2>&1",
                printer, filelist[which].name+3);
        return system(buf) == 0;
}

bool
do_topqueue(which)
        int which;
{
        char buf[BUFSIZ];
        sprintf(buf, "/etc/lpc topq %s %3.3s >/dev/null 2>&1",
                printer, filelist[which].name+3);
        return system(buf) == 0;
}

bool
do_restart()
{
        char buf[BUFSIZ];
        sprintf(buf, "/etc/lpc restart %s >/dev/null 2>&1",
                printer);
        return system(buf) == 0;
}
