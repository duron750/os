
#include "window.h"
	
int
wcharwidth (x)
int	x;
{
	char c = x;
	return (wtextwidth (&c, 1));
}

