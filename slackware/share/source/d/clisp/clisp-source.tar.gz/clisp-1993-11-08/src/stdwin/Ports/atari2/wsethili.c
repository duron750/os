
#include "stdwin.h"
#include "style.h"

void
wsethilite()
{
	wattr.style |= HILITE;
	setattr ();
}

