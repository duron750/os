
#include "window.h"

int
wmenuadditem(pm, str, shortcut)
void *pm;
char *str;
int shortcut;
{
	struct m_item	*it = ALLOC (struct m_item);
	int	len = 0;
	char	buf[50];

	barchanged = TRUE;

 	it->ittext = strdup (str);
	it->checked = FALSE;
	it->enabled = str != NULL && *str != 0;

	if ( it->enabled ) len = 2 + strlen (it->ittext);

	if ( shortcut > -1 ) {
		sprintf (buf, "Alt-%c", shortcut);
		it->sctext = strdup (buf);
		setkey (((MENU *)pm)->id, ((MENU *)pm)->nritems, shortcut);

		len += ( 2 + strlen(it->sctext) );
	}
	else
		it->sctext = NULL;

	it->line = NULL;

	L_APPEND (((MENU *)pm)->nritems, ((MENU *)pm)->itemlist, struct m_item *, it);

	if ( ++len > ((MENU *)pm)->maxlen ) ((MENU *)pm)->maxlen = len;

	((MENU *)pm)->dirty = TRUE;

	return (((MENU *)pm)->nritems - 1);
}

