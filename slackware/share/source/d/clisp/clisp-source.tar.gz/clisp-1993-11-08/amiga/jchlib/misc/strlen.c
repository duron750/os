int strlen(const char* str)
{
  register int count;
  for (count = 0; *str != '\0'; count++, str++) ;
  return count;
}
