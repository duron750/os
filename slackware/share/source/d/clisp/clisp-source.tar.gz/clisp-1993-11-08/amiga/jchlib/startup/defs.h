/* GCC Library
 * J�rg H�hle, 21-Nov-92
 */

#define AMIGA_REALLY /* for all inlines */

#include <exec/types.h>
#include <exec/execbase.h>
#include <libraries/dosextens.h>
#include <workbench/startup.h>

#if 0
#define dotimes(dotimesvar,num,statement)  \
for (dotimesvar = (num); dotimesvar != 0; dotimesvar--) { statement; }
#else
#define dotimes(dotimesvar,num,statement)  \
{ dotimesvar = (num);            \
    while (dotimesvar != 0)       \
      { statement; dotimesvar--; } \
}
#endif

#define bcopy(from,to,num)  \
{ register int counter;             \
  register char* fromp = (from);     \
  register char* top = (to);          \
  dotimes(counter,(num),               \
	  { *(top)++ = *(fromp)++; } ); \
}

#define alloca __builtin_alloca

volatile void exit(int);
int main(int argc, char ** argv);
void wbmain(struct WBStartup * wbmsg);
int _tokenize(volatile char * copy, int len);
void _dumpargs(char * copy, char ** argv, int argc);
ULONG asciz_length(const char * string);

/* debugging only */
#ifdef DEBUG
#define debug_asciz_out(s)  deb_asciz_out(s)
#define debug_dez_out(n)  deb_dez_out(n)
#define debug_hex_out(n)  deb_hex_out(n)
void deb_asciz_out(const char * string);
void deb_dez_out(unsigned long number);
void deb_hez_out(unsigned long number);
#else
#define debug_asciz_out(s)
#define debug_dez_out(n)
#define debug_hex_out(n)
#endif

/* Variables defined by startup */
extern struct ExecBase * SysBase;	/* main.c */
extern struct DosLibrary * DOSBase;	/* main.c */
extern struct WBStartup * WBenchMsg;	/* main.c */
extern BPTR _WBOrigDir;			/* exit.c */
extern BPTR Input_handle;		/* clisp.c */
extern BPTR Output_handle;		/* clisp.c */
extern BOOL _Close_Input;		/* exit.c */
extern BOOL _Close_Output;		/* exit.c */
extern UWORD _OS_Version;		/* main.c */
/*extern struct Library * IconBase	 * wbmain.c */
