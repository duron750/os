
#define NCURSES_VERSION "1.8.5"

