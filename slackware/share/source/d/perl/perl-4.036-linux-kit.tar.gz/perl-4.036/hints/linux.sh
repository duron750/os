#Hints file (Perl 4.036) for Linux
#Created by: Louis J. LaBash, Jr. (lou@minuet.siue.edu) 18 Jan 94-ljl-
#Modified: 21 Jan 94-ljl-
cat <<'EOF'




              -*-Congratulations, you're running Linux -*-
    This is a configuration hints file for Linux, it suggest the defaults
    to use.  If your system is configured in a strange way, these defaults
    may be in error: then you're on your own.
                              --*--



EOF

cc='cc'
nativegcc='define'
d_mymalloc='undef'
yacc='bison -y'
mansrc='/usr/man/man1'
manext='1'

#end of linux.sh
