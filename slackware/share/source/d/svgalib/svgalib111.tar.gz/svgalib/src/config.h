
/* Don't edit this if you just want to use the shared library. */

/* Uncomment one of the following lines to disable a driver. This saves */
/* binary space. Unless you want your binaries to run on other machines */
/* and chipsets, commenting out what you don't need is a good idea.     */
/* Standard VGA support is always available.				*/

#define INCLUDE_ET4000_DRIVER
#define INCLUDE_CIRRUS_DRIVER
#define INCLUDE_TVGA_DRIVER
#define INCLUDE_OAK_DRIVER
#define INCLUDE_EGA_DRIVER
#define INCLUDE_MACH32_DRIVER
#define INCLUDE_S3_DRIVER

#define INCLUDE_ET4000_DRIVER_TEST
#define INCLUDE_CIRRUS_DRIVER_TEST
#define INCLUDE_TVGA_DRIVER_TEST
#define INCLUDE_OAK_DRIVER_TEST
#define INCLUDE_EGA_DRIVER_TEST
#define INCLUDE_MACH32_DRIVER_TEST
/* #define INCLUDE_S3_DRIVER_TEST */


/* Location of the svgalib configuration file. */

#define SVGALIB_CONFIG_FILE "/usr/local/lib/libvga.config"


/* Defining DYNAMIC enables runtime parsing of the file defined by      */
/* ET4000_REGS (usually /usr/local/lib/libvga.et4000) for the et4000    */
/* driver. See et4000/README for details. Commenting this out again	*/
/* saves binary space.							*/

/* If you just want to use the et4000.regs in the source directory,     */
/* comment out the definition of DYNAMIC.				*/

#define DYNAMIC
#define ET4000_REGS "/usr/local/lib/libvga.et4000"

/* The EGA driver may load additional modes (SuperEGA cards) like the	*/
/* et4000 driver does. Just define the configuration file below.	*/
/* [This should be taken with a grain of salt, EGA is untested.]	*/

#define EGA_REGS "/usr/local/lib/libvga.ega"


/* Defining USE_CLOCKS will cause the ET4000 driver to measure clock    */
/* frequencies (they are not actually used yet).			*/

/* #define USE_CLOCKS */
