main()
{
	if (fork() == 0)
		write(2, "child\n", 6);
	else {
		wait(0);
		write(2, "parent\n", 7);
	}
	exit(0);
}
