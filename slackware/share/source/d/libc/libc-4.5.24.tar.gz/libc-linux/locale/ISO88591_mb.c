#include <ansidecl.h>
#include <localeinfo.h>
#include <stddef.h>


CONST struct ctype_mbchar_info __ctype_mbchar_ISO_8859_1 =
  {
    0, NULL
  };
