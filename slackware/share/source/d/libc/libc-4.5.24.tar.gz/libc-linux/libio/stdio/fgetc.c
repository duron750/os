#include "libioP.h"
#include "stdio.h"

int
fgetc(fp)
     FILE *fp;
{
  CHECK_FILE(fp, EOF);
  COERCE_FILE(fp);
  return _IO_getc(fp);
}
