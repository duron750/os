#undef HAVE_GNU_LD
#define HAVE_GNU_LD
#include <gnu-stabs.h>
#undef fopen
symbol_alias (_IO_fopen, fopen);
