#include "libioP.h"
#include "stdio.h"

int
ferror(fp)
     FILE* fp;
{
  CHECK_FILE(fp, EOF);
  COERCE_FILE(fp);
  return _IO_ferror(fp);
}
