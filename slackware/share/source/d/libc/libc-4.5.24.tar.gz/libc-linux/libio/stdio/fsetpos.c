#undef HAVE_GNU_LD
#define HAVE_GNU_LD
#include <gnu-stabs.h>
#undef fsetpos
symbol_alias (_IO_fsetpos, fsetpos);
