#undef HAVE_GNU_LD
#define HAVE_GNU_LD
#include <gnu-stabs.h>
#undef ungetc
symbol_alias (_IO_ungetc, ungetc);
