#include "libioP.h"
#include "stdio.h"

/* Define non-macro versions of stdin/stdout/stderr,
 * for use by debuggers. */

#undef stdin
#undef stdout
#undef stderr
FILE* stdin = &_IO_stdin_._file;
FILE* stdout = &_IO_stdout_._file;
FILE* stderr = &_IO_stderr_._file;
