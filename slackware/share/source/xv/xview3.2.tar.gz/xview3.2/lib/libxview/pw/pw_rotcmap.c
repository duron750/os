#ifndef lint
#ifdef sccs
static char     sccsid[] = "@(#)pw_rotcmap.c 20.14 93/06/28 SMI";
#endif
#endif

/*
 * Sun Microsystems, Inc.
 */

/*
 * rotate a color map segment.
 */
