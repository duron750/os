/***************************************************************************\
|*									   *|
|*  pieces.h:	A version of Tetris to run on ordinary terminals,	   *|
|*		(ie., not needing a workstation, so should available	   *|
|*		to peasant Newwords+ users.  This module contains the	   *|
|*		definitions of the pieces.				   *|
|*									   *|
|*  Author:	Mike Taylor (mirk@uk.ac.warwick.cs)			   *|
|*  Started:	Fri May 26 12:26:05 BST 1989				   *|
|*									   *|
\***************************************************************************/

struct piece {
  char app[3];
  int points;
  int index[NO_ORIENTS][NO_SQUARES][NO_DIMS];
};

/*-------------------------------------------------------------------------*/

extern struct piece pieces[NO_PIECES];

/*-------------------------------------------------------------------------*/
