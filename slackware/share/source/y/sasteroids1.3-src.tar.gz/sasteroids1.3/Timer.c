// Copyright 1994 Brad Pitzel
//
// Feel free to use/distribute/modify as long as credit/copyrights for myself 
// are included.

#include "Timer.h"


timeval Timer::VlastClk;
timeval Timer::VnewClk;
long	Timer::VfTime=0;
long	Timer::Vlast=0;
int	Timer::VframeRate=0;
