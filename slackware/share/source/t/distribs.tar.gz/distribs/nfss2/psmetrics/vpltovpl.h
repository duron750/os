#include <stdio.h>
#ifdef MSDOS
#include <string.h>
#include <stdlib.h>
#define SEARCH strchr
#else
#define remove(file) unlink(file)
#ifdef SYSV
#include <string.h>
#define SEARCH strchr
#else
#define SEARCH index
#include <strings.h>
#endif
#endif

#define GRAVE "O 0"
#define ACUTE "O 1"
#define CIRCUMFLEX "O 2"
#define TILDE "O 3"
#define DIERESIS "O 4"
#define HUNGARUMLAUT "O 5"
#define RING "O 6"
#define CARON "O 7"
#define BREVE "O 10"
#define MACRON "O 11"
#define DOTACCENT "O 12"
#define CEDILLA "O 13"
#define OGONEK "O 14"
#define QUOTE "O 47"
#define BAR "O 25"

/* extra amount to raise accents above small caps */
#define SC_ACCENT_RAISE 170

#define LINELENGTH 256
#define MAXCHARS 300
#define MAXENTRY 20000   /* they can get pretty big! eg ligtable entries */

extern  struct character *findchar();
extern  float width(char *key);
extern  float height(char *key);
extern  float depth(char *key);
extern  float charic(char *key);
#ifndef MSDOS
extern  float max(float a,float b); 
#endif
extern  void error(char *s);
extern  char *mymalloc();
extern  char *namespace(void );
extern  struct character *anewchar();
extern  int count(char *line);
extern  void vchar(int charnum,char *charname,double charwd,double charht,double chardp,double charic,char *oldchar,char *accent,double moveright,double moveup,int WhichFont);
extern  void upperacc(int number,char *c,char *accent,char *name);
extern  void loweracc(int number,char *c,char *accent,char *name,double movedown);
extern  int generatenormal(void );
extern  int generatespecial(void );
extern  int getentry(void );
extern  void process(void );
extern  void generateligs(void );
extern  int main(int argc,char * *argv);
#ifndef ALLOC_RETURN_TYPE
#ifdef DOS
#define ALLOC_RETURN_TYPE void
#else
#define ALLOC_RETURN_TYPE char
#endif /* not DOS */
#endif /* not ALLOC_RETURN_TYPE */
extern ALLOC_RETURN_TYPE *calloc (), *malloc (), *realloc ();
