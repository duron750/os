/* defaults.h - 22:18 GMT +10:00 Fri 25 Jun 1993 - modifier Geoffrey Tobin */

#ifndef DEFAULTS_H
#define DEFAULTS_H

/* Initial default values for various DVItoVDU quantities */

#define DEF_XRES  300.0  /* Horizontal resolution in dpi */
#define DEF_YRES  300.0  /* Vertical   resolution in dpi */

#define DEF_PAPERWD  "8.5in"      /* Letter-size paper width  */
#define DEF_PAPERHT  "11in"       /* Letter-size paper height */

#if 0
#define DEF_PAPERWD  "210mm"      /* A4 paper width  */
#define DEF_PAPERHT  "297mm"      /* A4 paper height */
#endif

#define DEF_PK_DIR  ".:/usr/local/lib/texmf/fonts/pk/CanonCX"
#define DEF_TFM_DIR  ".:/usr/lib/texmf/fonts/postscript/tfm:/usr/lib/texmf/fonts/metafont/tfm"
    /* PK and TFM of last resort; assumed in resp. usual font directory: */
#define DEF_DUMMY_PK  "cmr10.300pk"
#define DEF_DUMMY_TFM  "cmr10.tfm"
   /* PS font prefix, by Karl Berry's convention. */
#define DEF_PS_PREFIX  "p"

#define DEF_CMD_HELP  "/usr/lib/texmf/ini/cmd.hlp"
#define DEF_IMMED_HELP  "/usr/lib/texmf/ini/immed.hlp"

#endif /* DEFAULTS_H */

/* end defaults.h */
