/* new.h - 19:41 GMT +10:00 Fri 20 August 1993 - Geoffrey Tobin */
/* Slightly simpler memory allocation. */

#ifndef NEW_H
#define NEW_H

#include "config.h"

#define new(T) (T *) malloc (sizeof (T))
#define New(T) (T *) Malloc (sizeof (T))
#define cnew(n,T) (T *) calloc ((size_t) n, sizeof (T))

#endif /* NEW_H */

/* end new.h */
