/* vis240vdu.c - 18:39 GMT +10:00 Sat 12 Jun 1993 - modifier Geoffrey Tobin */

/* From input file "../include/globals.p" */

#include "config.h"
#include "globals.h"

#include "screenio.h"
#include "vdu.h"

#include "regisvdu.h"

/*************************************************************************/

Void InitVIS240 (VOID)
{
  InitREGIS();
  /* the VIS240/241 has more text lines and a bigger window region: */
  bottoml = 29;
  windowwd = 800;
  windowht = 580 - windowv;

  textlinewidth = 72;  /* text characters per line - a guess */
}
/*InitVIS240 */

/*************************************************************************/

/* end vis240vdu.c */
