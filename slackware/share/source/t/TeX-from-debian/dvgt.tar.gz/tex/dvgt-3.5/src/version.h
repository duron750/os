/* version.h - 22:16 GMT +10:00 Fri 20 Aug 1993 - Geoffrey Tobin. */

#ifndef VERSION_H
#define VERSION_H

#define dvgt_version  \
  "This is dvgt 3.51+ (DVItoVDU, v. 3.0, gt mod 5 rev 1+) - Wed 13 Oct 93"

#endif /* VERSION_H */

/* end version.h */
