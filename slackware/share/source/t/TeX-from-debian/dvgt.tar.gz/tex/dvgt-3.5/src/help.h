/* help.h - 20:32 GMT +10:00 Mon 2 Aug 1993 - Geoffrey Tobin */
/* Precompiled help information. */

#ifndef HELP_H
#define HELP_H

#include "version.h"

#ifndef NULL
#define NULL  (char *) 0;
#endif

char * immed_help_strings[] =
{
dvgt_version,
"dvgt interactively views TeX-generated DVI files on some common VDUs.",
"This is the precompiled help, `help.h', shown if no arguments are given.",
"The options help file, `options.hlp', gives more information.",
"USAGE:",
"  dvgt  filename[.dvi]",
"        [-H x_offset]  [-V y_offset]  [-d dummy_pk]  [-e dummy_tfm]",
"        [-f pk_directory]  [-h helpfile]  [-i]  [-l]",
"        [-m magnification]  [-p ps_prefix]  [-r xres[,yres]]",
"        [-t tfm_directory]  [-v vdu]  [-x paperwd]  [-y paperht]",
"",
"-H horizontal_offset   (default = 0.0 in)",
"-V vertical_offset     (default = 0.0 in)",
"-l   (set landscape mode, instead of the default portrait mode)",
"-m magnification   (default= DVI file's intrinsic magnification)",
"-v vdu   (default value = value of TERM)   where  vdu  may be one of:",
"",
"   aed512 gigi kermit ncsatel regis tek4010 vis240 vis241 vis500 vis550",
"   vis603 vis630 vk100 vt100 vt100132 vt102 vt125 vt200 vt220 vt240 vt640",
"",
"The other parameters' default values are system dependent.",
"Try `dvgt -f', for example, to find the current default PK font directory.",
NULL
};

char * cmd_help_strings[] =
{
"MISCELLANEOUS                         CHANGING PAGE DISPLAY (TOGGLES)",
"?  Display this command help info     T  Terse - fast but inaccurate",
"S  Show options, fonts and page info  B  Bounding Box of glyphs",
"A  Toggle Auto window                 F  Full - accurate but slow",
"^L Refresh screen",
"Q  Quit from dvgt                     CHANGING UNITS OF DIMENSIONS",
"                                      C u  Where u is one of the units",
"SELECTING A PAGE                      BP, CM, IN, MM, PC, PT, PX, or SP",
"[i0. ... .i9]  Select TeX page        (big point, cm, inch, mm, pica,",
"i  Select the ith DVI page            point, paper pixel, or scaled point)",
"N  Next DVI page",
"P  Previous DVI page                  MOVING THE WINDOW",
"                                      W h,v  Move Window to given posn",
"CHANGING THE SIZE OF THE WINDOW              or to (minh,minv) if no h,v ",
"H x   Set Horiz. window size to x     U v    Move window Up by v",
"      or to unscaled width if no x           or by half current ht if no v",
"V y   Set Vertical window size to y   D v    Move window Down by v",
"      or to unscaled height if no y          or by half cur. ht if no v",
"ZI z  Zoom In by factor z             L h    Move window Left by h",
"      or by current factor if no z           or by half cur. width if no h",
"ZO z  Zoom Out, as for ZI             R h    Move window Right by h",
"ZCI z, ZCO z  Zoom wrt window center         or by half cur. width if no h",
NULL
};

#endif /* HELP_H */

/* end help.h */
