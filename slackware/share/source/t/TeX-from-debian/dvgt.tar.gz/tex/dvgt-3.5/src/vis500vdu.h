/* vis500vdu.h - 20:10 GMT +10:00 Sat 12 Jun 1993 - modifier Geoffrey Tobin */

#ifndef VIS500VDU_H
#define VIS500VDU_H

/* Include file ../include/vis500vdu.h from vis630vdu.c */


extern Void InitVIS500VDU (VOID);

extern Void VIS500MoveToTextLine __((int line));

extern Void VIS500ClearScreen (VOID);

extern Void VIS500ShowChar __((int screenh, int screenv, Char ch));

extern Void VIS500ShowRectangle __((int screenh, int screenv, int width,
				 int height, Char ch));
extern Void VIS500ResetVDU (VOID);

#endif /* VIS500VDU_H */

/* end vis500vdu.h */
