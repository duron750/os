/* lstring.h - 21:05 GMT +10:00 Tue 11 May 1993 - Geoffrey Tobin */
/* Length (and capacity) specified strings. */

#ifndef LSTRING_H
#define LSTRING_H

#include "config.h"

typedef struct LString
{
  int cap;  /* capacity */
  int len;  /* length */
  char * s; /* NULL-delimited character array, dynamically allocated */
} LString;

#ifdef __STDC__
LString * NewLString (int capacity);
#else
LString * NewLString ();
#endif

#ifdef __STDC__
LString * FreeLString (LString * S);
#else
LString * FreeLString ();
#endif

#ifdef __STDC__
Void Scovers (LString * S, int l, const char * s);
#else
Void Scovers ();
#endif

#ifdef __STDC__
Void Scopys (LString * S, const char * s);
#else
Void Scopys ();
#endif

#ifdef __STDC__
Void Scats (LString * S, const char * s);
#else
Void Scats ();
#endif

#endif  /* LSTRING_H */

/* end lstring.h */
