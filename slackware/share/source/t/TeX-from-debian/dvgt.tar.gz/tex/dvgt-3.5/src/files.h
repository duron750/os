/* files.h - 20:00 GMT +10:00 Thu 22 July 1993 - modified by Geoffrey Tobin */

#ifndef FILES_H
#define FILES_H

/* Include file ../include/files.h from fontreader.c */

/* Random file access routines; used in DVIReader and FontReader */
/* 0 = success, 1 = error */

/* SYSDEP: read-only flag, O_RDONLY, for open: defined in <fcntl.h> */

#include <fcntl.h>

#define bufflen         1024   /* size of buffer for holding DVI/PK bytes */
typedef unsigned char buffer[bufflen];

#endif /* FILES_H */

/* end files.h */
