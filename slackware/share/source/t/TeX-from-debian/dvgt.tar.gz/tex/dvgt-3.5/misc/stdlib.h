/* stdlib.h - 22:18 GMT +10:00 Fri 20 August 1993 - modifier Geoffrey Tobin */
/* - for Ian Dall's "dv"; adapted for dvgt */
/* Here is an attempt at defining templates for all the libc.a functions.
 * It is undoubtedly wrong for most machines!
 */
#ifdef __STDC__
#ifdef stdin
  extern int ungetc (int, FILE *);
  extern int fseek (FILE *, long, int);
  extern void rewind (FILE *);
  extern long ftell (FILE *);
  extern int fclose (FILE *);
  extern int fflush (FILE *);
  extern int fprintf(FILE *, char *,...);
#endif /* stdin */
  extern int abs(int);
  extern char * memccpy (char *, char *, int, int);
  extern char * memchr (char *, int, int);
  extern int memcmp (char *, char *, int);
  extern char * memcpy (char *, char *, int);
  extern char * memset (char *, int, int);
  extern char * memmove (char *, char *, int);
  extern int rand();
  extern void srand(unsigned);
  extern long strtol (char *, char **, int);
  extern long atol (char *);
  extern int atoi (char *);
  extern double strtod (char *, char **);
  extern double atof (char *);
  extern double atod (char *);
  extern void perror (char *);
  extern int toupper (int);
  extern int tolower (int);
  extern int toascii (int);
  extern int sprintf (char *, char *,...);
  extern int printf(char *,...);
  extern void * malloc(unsigned);
  extern void * realloc(void *, unsigned);
  extern void * calloc(unsigned, unsigned);
  extern void free (void *);
  extern void exit (int);
#else /* not __STDC__ */
#ifdef stdin
  extern int ungetc ();
  extern int fseek ();
  extern void rewind ();
  extern long ftell ();
  extern int fclose ();
  extern int fflush ();
  extern int fprintf();
#endif /* stdin */
  extern int abs();
  extern char * memccpy ();
  extern char * memchr ();
  extern int memcmp ();
  extern char * memcpy ();
  extern char * memset ();
  extern char * memmove ();
  extern int rand();
  extern void srand();
  extern long strtol ();
  extern long atol ();
  extern int atoi ();
  extern double strtod ();
  extern double atof ();
  extern double atod ();
  extern void perror ();
  extern int toupper ();
  extern int tolower ();
  extern int toascii ();
  extern int sprintf ();
  extern int printf();
  extern char * malloc();
  extern char * realloc();
  extern char * calloc();
  extern void free ();
  extern void exit ();
#endif /* __STDC__ */
