/* regisvdu.h - 21:11 GMT +10:00 Mon 24 May 1993 - Geoffrey Tobin */

#ifndef CONFIG_H
#include "config.h"
#endif

extern Void InitREGIS (VOID);

/* end regisvdu.h */
