/* fontreader.h - 21:10 GMT +10:00 Mon 24 May 1993 - modifier Geoffrey Tobin */

#ifndef FONTREADER_H
#define FONTREADER_H

/* Include file ../include/fontreader.h from dvitovdu.c */

/* FontReader */

extern Void InitFontReader (VOID);
extern Void PixelTableRoutine __((fontinfo * currfont));
extern boolean GetBitmap __((int ht, int wd, int mapadr, int_or_mptr *bitmap));
extern boolean BuildFileSpec __((const char * areas, const char * name, string spec));
extern boolean BuildFontSpec __((fontinfo *fontptr));
extern boolean OpenFontFile __((Char *name));
extern Void CloseFontFile (VOID);

#endif /* FONTREADER_H */

/* end fontreader.h */
