/* vt100vdu.h - 20:10 GMT +10:00 Sat 12 Jun 1993 - modifier Geoffrey Tobin */

#ifndef VT100VDU_H
#define VT100VDU_H

/* Include file ../include/vt100vdu.h from vis630vdu.c */


extern Void InitVT100VDU (VOID);

extern Void VT100StartText (VOID);

extern Void VT100MoveAbs __((int row, int col));

extern Void VT100MoveToTextLine __((int line));

extern Void VT100ClearTextLine __((int line));

extern Void VT100ClearScreen (VOID);

extern Void VT100StartGraphics (VOID);

extern Void VT100LoadFont __((Char *fontname, int fontsize, double mag,
			      double hscale, double vscale));

extern Void VT100ShowChar __((int screenh, int screenv, Char ch));

extern Void VT100ShowRectangle __((int screenh, int screenv, int width,
				   int height, Char ch));

#endif /* VT100VDU_H */

/* end vt100vdu.h */
