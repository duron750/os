#!/bin/csh
rm -rf *~ *.tfm *.vpl *.vf *.afm testfont.*
