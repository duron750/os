#define VERSION_STRING "xdvik version 1.5"

