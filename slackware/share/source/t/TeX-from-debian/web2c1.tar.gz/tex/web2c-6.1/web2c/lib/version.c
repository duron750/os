/* This string is appended to all the banners.  */
#ifndef VERSION_STRING
#define VERSION_STRING " (C version 6.1)"
#endif

char *versionstring = VERSION_STRING;
