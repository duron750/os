/* This file is included from gftodvi.ch, since variant records are
   too hard to translate automatically.  */

typedef union {
   scaled sc;
   fourquarters qqqq;
} memoryword;
