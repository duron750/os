char F2C_version[] = "23 April 1993  18:34:30";
char xxxvers[] = "\n@(#) FORTRAN 77 to C Translator, VERSION 23 April 1993  18:34:30\n";
