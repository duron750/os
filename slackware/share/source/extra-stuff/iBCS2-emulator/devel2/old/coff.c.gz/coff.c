/* This program is compiled with the following command line:

cc -o test test.c

I don't have a makefile. If you really want one, write it. I just entered
the compile command above and it works just fine.

The program is simply a variation of the sample program presented in the
Using COFF book, published by O'Rielly & Associates.

It has been modified to work with the defines used with the Linux Loader
and the data structures presented with the gas assembler. In addition, I
added an ascii dump to the hex dump used in the original and expanded the
flag bits to the appropriate defines.

All copyrights presented in the original article have been included in
this program. (That is to say that there were none. However, the program
was presented in a copyrighted book.)

The original source file may be obtained by anonymous ftp at:

ora.com:/pub/nutshell/samples/coff/coff.cz
*/

#include <stdio.h>
#include <time.h>		/* Used for ctime function */
#include <unistd.h>
#include <errno.h>

/* Headers for working with COFF files */
#if 1
#include <linux/coff.h> /* Definitions from kernel's coff loader */

/********************************************************************/
/********************************************************************/
/***********                                                *********/
/***********   S T A R T   O F   A D D E D   D A T A        *********/
/***********                                                *********/
/********************************************************************/
/********************************************************************/

/*
 * The low 4 bits of s_flags is used as a section "type"
 */

#define STYP_REG	0x00		/* "regular" section:
						allocated, relocated, loaded */
#define STYP_DSECT	0x01		/* "dummy" section:
						not allocated, relocated,
						not loaded */
#define STYP_NOLOAD	0x02		/* "noload" section:
						allocated, relocated,
						 not loaded */
#define STYP_GROUP	0x04		/* "grouped" section:
						formed of input sections */
#define STYP_PAD	0x08		/* "padding" section:
						not allocated, not relocated,
						 loaded */

#define STYP_COPY	0x10		/* "copy" section:
						for decision function used
						by field update;  not
						allocated, not relocated,
						loaded;  reloc & lineno
						entries processed normally */
#define	STYP_TEXT	0x20		/* section contains text only */
#define STYP_DATA	0x40		/* section contains data only */
#define STYP_BSS	0x80		/* section contains bss only */

/*
 *  In a minimal file or an update file, a new function
 *  (as compared with a replaced function) is indicated by S_NEWFCN
 */

#define S_NEWFCN  0x10

/*
 * In 3b Update Files (output of ogen), sections which appear in SHARED
 * segments of the Pfile will have the S_SHRSEG flag set by ogen, to inform
 * dufr that updating 1 copy of the proc. will update all process invocations.
 */

#define S_SHRSEG	0x20

/*
 * Relocatable symbols have a section number of the
 * section in which they are defined. Otherwise, section
 * numbers have the following meanings:
 */

#define  N_UNDEF  0     /* undefined symbol */
#define  N_ABS	 -1     /* value of symbol is absolute */
#define  N_DEBUG -2     /* special debugging symbol -- value */
                        /* of symbol is meaningless */
#define  N_TV	 -3     /* indicates symbol needs */
                        /* transfer vector (preload) */
#define  P_TV	 -4     /* indicates symbol needs */
                        /* transfer vector (postload) */
/*
 *   STORAGE CLASSES
 */

#define  C_EFCN          -1    /* physical end of function */
#define  C_NULL          0
#define  C_AUTO          1     /* automatic variable */
#define  C_EXT           2     /* external symbol */
#define  C_STAT          3     /* static */
#define  C_REG           4     /* register variable */
#define  C_EXTDEF        5     /* external definition */
#define  C_LABEL         6     /* label */
#define  C_ULABEL        7     /* undefined label */
#define  C_MOS           8     /* member of structure */
#define  C_ARG           9     /* function argument */
#define  C_STRTAG        10    /* structure tag */
#define  C_MOU           11    /* member of union */
#define  C_UNTAG         12    /* union tag */
#define  C_TPDEF         13    /* type definition */
#define  C_USTATIC	 14    /* undefined static */
#define  C_ENTAG         15    /* enumeration tag */
#define  C_MOE           16    /* member of enumeration */
#define  C_REGPARM	 17    /* register parameter */
#define  C_FIELD         18    /* bit field */
#define  C_BLOCK         100   /* ".bb" or ".eb" */
#define  C_FCN           101   /* ".bf" or ".ef" */
#define  C_EOS           102   /* end of structure */
#define  C_FILE          103   /* file name */

/*
 * The fundamental type of a symbol packed into the low 
 * 4 bits of the word.
 */

#define  _EF	".ef"

#define  T_NULL     0
#define  T_ARG      1          /* function argument (only used by compiler) */
#define  T_CHAR     2          /* character */
#define  T_SHORT    3          /* short integer */
#define  T_INT      4          /* integer */
#define  T_LONG     5          /* long integer */
#define  T_FLOAT    6          /* floating point */
#define  T_DOUBLE   7          /* double word */
#define  T_STRUCT   8          /* structure  */
#define  T_UNION    9          /* union  */
#define  T_ENUM     10         /* enumeration  */
#define  T_MOE      11         /* member of enumeration */
#define  T_UCHAR    12         /* unsigned character */
#define  T_USHORT   13         /* unsigned short */
#define  T_UINT     14         /* unsigned integer */
#define  T_ULONG    15         /* unsigned long */

/*
 * derived types are:
 */

#define  DT_NON      0          /* no derived type */
#define  DT_PTR      1          /* pointer */
#define  DT_FCN      2          /* function */
#define  DT_ARY      3          /* array */

/*
 * type packing constants
 */

#define  N_BTMASK     017
#define  N_TMASK      060
#define  N_TMASK1     0300
#define  N_TMASK2     0360
#define  N_BTSHFT     4
#define  N_TSHIFT     2

/*
 * MACROS
 */

	/*   Basic Type of  x   */

#define  BTYPE(x)  ((x) & N_BTMASK)

	/*   Is  x  a  pointer ?   */

#define  ISPTR(x)  (((x) & N_TMASK) == (DT_PTR << N_BTSHFT))

	/*   Is  x  a  function ?  */

#define  ISFCN(x)  (((x) & N_TMASK) == (DT_FCN << N_BTSHFT))

	/*   Is  x  an  array ?   */

#define  ISARY(x)  (((x) & N_TMASK) == (DT_ARY << N_BTSHFT))

	/* Is x a structure, union, or enumeration TAG? */

#define ISTAG(x)  ((x)==C_STRTAG || (x)==C_UNTAG || (x)==C_ENTAG)

#define  INCREF(x) ((((x)&~N_BTMASK)<<N_TSHIFT)|(DT_PTR<<N_BTSHFT)|(x&N_BTMASK))

#define  DECREF(x) ((((x)>>N_TSHIFT)&~N_BTMASK)|((x)&N_BTMASK))

/********************************************************************/
/********************************************************************/
/***********                                                *********/
/***********   E N D   O F   A D D E D   D A T A            *********/
/***********                                                *********/
/********************************************************************/
/********************************************************************/

/*
 *     Remove the macros from the coff.h header. Replace them with a
 *     version which will choose the appropriate endian mode based upon
 *     a global flag.
 */

#undef  COFF_SHORT
#undef  COFF_LONG
#define COFF_SHORT(v) (flip ? COFF_SHORT_H(v) : COFF_SHORT_L(v))
#define COFF_LONG(v)  (flip ? COFF_LONG_H(v)  : COFF_LONG_L(v))

#else
#include <aouthdr.h>
#include <filehdr.h>
#include <scnhdr.h>
#include <linenum.h>
#include <reloc.h>
#include <syms.h>
#endif
		/* Global variables */

int     flip = 0;       /* Set non-zero for big-endian header formats */
long	num_sections;	/* Number of section */
long	section_seek;   /* Used to seek to first section */

long	symptr;		/* File pointer to symbol table entries */
long	num_symbols;	/* Number of symbols */

char 	*str_tab;	/* Pointer to start of string char. array */
long 	str_length;	/* Length in bytes of string array */

FILE 	*fd;		/* COFF file descriptor */

int     opt_y = 1;      /* -y specified */
int     opt_l = 1;      /* -l specified */
int     opt_s = 1;      /* -s specified */
int     opt_e = 1;      /* -e specified */
int     opt_r = 0;      /* -r specified */

void print_se (struct COFF_syment *se);
void print_ae (char *ae);
void read_symbols(void);
void read_strings(void);
void read_sections(void);
void read_headers(void);
int main (int argc, char *argv[]);

void useage(void)
{
  fprintf (stderr,
	   "coff [-r] [-y] [-l] [-s] [-e] file\n"
	   "-r : print raw data information\n"
	   "-y : suppress symbol table information\n"
	   "-l : suppress lineno information\n"
	   "-s : suppress string information\n"
	   "-e : suppress relocation information\n");
}

int main (int argc, char *argv[])
{
  static char szOptions[] = "ylser";
  int    option;
/*
 *  Evaluate the options to the program.
 */
  option = getopt (argc, argv, szOptions);
  while (option != EOF)
    {
      switch (option)
	{
	case 'r': opt_r = 1; break;   /* Print raw data */
	case 'y': opt_y = 0; break;   /* Suppress symbol table data */
	case 's': opt_s = 0; break;   /* Suppress string data */
	case 'l': opt_l = 0; break;   /* Suppress line number data */
	case 'e': opt_e = 0; break;   /* Suppress relocation data */

	default:
	  useage();
	  exit (1);
	  break;
	}
      option = getopt (argc, argv, szOptions);
    }
/*
 *  Open the input file
 */
  if (optind == argc)
    {
      useage();
    }
  else
    {
      fd = fopen (argv [optind], "r");
      if (fd != 0)
	{
	  read_headers();
	  read_sections();
	  read_strings();
	  read_symbols();
	}
      else
	{
	  fprintf (stderr,
		   "Error %d opening input file %s\n",
		   errno,
		   argv[optind]);
	}
    }
  return (0);
}

void print_hdr_flags(int flags)
{
  if (flags & COFF_F_RELFLG)
    printf (", relflg");
  if (flags & COFF_F_EXEC)
    printf (", exec");
  if (flags & COFF_F_LNNO)
    printf (", lnno");
  if (flags & COFF_F_LSYMS)
    printf (", lsyms");
  if (flags & COFF_F_MINMAL)
    printf (", minmal");
  if (flags & COFF_F_UPDATE)
    printf (", update");
  if (flags & COFF_F_SWABD)
    printf (", swabd");
  if (flags & COFF_F_AR16WR)
    printf (", ar16wr");
  if (flags & COFF_F_AR32WR)
    printf (", ar32wr");
  if (flags & COFF_F_AR32W)
    printf (", ar32w");
  if (flags & COFF_F_PATCH)
    printf (", patch/nodf");
}

void print_hdr_magic (int type)
{
  switch (type)
    {
    case COFF_I386MAGIC:
      printf ("I386MAGIC");
      break;
    default:
      printf ("??unknown??");
      break;
    }
}

void read_headers(void)
{
  COFF_FILHDR  file_header;	/* File header structure */
  COFF_AOUTHDR optional_header;/* Optional header structure */
  long int time_buf;

  fread (&file_header, COFF_FILHSZ, 1, fd);
/*
 *   Look for the big-endian formats.
 */

  flip = 1;
  if (COFF_SHORT (file_header.f_magic) != 0x1DF)
    {
      flip = 0;
    }

  printf("FILE HEADER VALUES\n");
  printf("f_magic  = 0%o, ", (int) COFF_SHORT (file_header.f_magic));
  print_hdr_magic ((int) COFF_SHORT (file_header.f_magic));
  printf("\n");
  printf("f_nscns  = %d\n",   (int) COFF_SHORT (file_header.f_nscns));

  time_buf         = COFF_LONG (file_header.f_timdat);
  printf("f_timdat = %s",ctime(&time_buf));

  printf("f_symptr = %d\n",  (int) COFF_LONG  (file_header.f_symptr));
  printf("f_nsyms  = %d\n",  (int) COFF_LONG  (file_header.f_nsyms));
  printf("f_opthdr = %d\n",  (int) COFF_SHORT (file_header.f_opthdr));
  printf("f_flags  = 0%o",   (int) COFF_SHORT (file_header.f_flags));
  print_hdr_flags ((int) COFF_SHORT (file_header.f_flags));
  printf("\n");

  /* Save the global values */
  
  num_sections = (long) COFF_SHORT (file_header.f_nscns);
  num_symbols  = (long) COFF_LONG  (file_header.f_nsyms);
  symptr       = (long) COFF_LONG  (file_header.f_symptr);

  if (COFF_SHORT (file_header.f_opthdr))
    { 
      fread (&optional_header, COFF_AOUTSZ, 1, fd);
      
      printf("OPTIONAL HEADER VALUES\n");
      printf("magic      = 0%o\n",(int) COFF_SHORT (optional_header.magic));
      printf("vstamp     = %d\n",(int) COFF_SHORT (optional_header.vstamp));
      printf("tsize      = %d\n",(int) COFF_LONG (optional_header.tsize));
      printf("dsize      = %d\n",(int) COFF_LONG (optional_header.dsize));
      printf("bsize      = %d\n",(int) COFF_LONG (optional_header.bsize));
      printf("entry      = 0x%x\n",(int) COFF_LONG (optional_header.entry));
      printf("text_start = 0x%x\n",(int) COFF_LONG (optional_header.text_start));
      printf("data_start = 0x%x\n",(int) COFF_LONG (optional_header.data_start));
/*
      printf("flags      = 0x%x\n",(int) COFF_LONG (optional_header.flags));
*/
    }

  /* File offset for first section headers */
  section_seek = COFF_FILHSZ + (long) COFF_SHORT (file_header.f_opthdr);
}

void print_sect_mod (int flag)
{
  switch (flag & 0xF0)
    {
    case STYP_COPY:
      printf ("copy");
      break;
    case STYP_TEXT:
      printf ("text");
      break;
    case STYP_DATA:
      printf ("data");
      break;
    case STYP_BSS:
      printf ("bss");
      break;
    default:
      printf ("unknown subtype = 0x%02X", (int) ((flag >> 4) & 0x0f));
      break;
    }
}

void print_sect_flags (int flag)
{
  switch (flag & 0x0F)
    {
    case STYP_REG:
      printf ("regular, ");
      print_sect_mod (flag);
      break;
    case STYP_DSECT:
      printf ("dummy");
      break;
    case STYP_NOLOAD:
      printf ("noload");
      break;
    case STYP_GROUP:
      printf ("group");
      break;
    case STYP_PAD:
      printf ("pad");
      break;
    default:
      printf ("unknown type 0x%02X", (int) flag & 0x0F);
      break;
    }
}

void dump_ascii_line (char *ptr, int size, long base, long first)
{
  printf (" ");
  while (size-- != 0)
    {
      if (first != base)
	{
	  printf (" ");
	  ++first;
	}
      else
	{
	  if ((*ptr & 0x80) == 0)
	    {
	      if (*ptr >= 0x20 && *ptr < 0x7F)
		{
		  printf ("%c",
			  (int) (unsigned int) (unsigned short) (*ptr & 0xFF));
		  ++ptr;
		  continue;
		}
	    }
	  printf (".");
	  ++ptr;
	}
    }
  printf ("\n");
}

void dump_hex_line (char *ptr, int size, long base, long first)
{
  int   count = 0;

  printf ("%08X ", first);

  while (count++ != 16)
    {
      if (first != base)
	{
	  printf ("   ");
	}
      else
	{
	  ++base;
	  if (size == 0)
	    {
	      printf ("   ");
	    }
	  else
	    {
	      printf ("%02X ",
		      (int) (unsigned int) (unsigned short) (*ptr & 0xFF));
	      ++ptr;
	      --size;
	    }
	}
      ++first;
    }
}

void dump_hex_buffer (char *ptr, int size, long base)
{
  int count;
  count = 16 - (base & 0x0F);
  if (count > size)
    {
      count = size;
    }

  if (count > 0)
    {
      dump_hex_line   (ptr, count, base, base & 0xFFFFFFF0);
      dump_ascii_line (ptr, count, base, base & 0xFFFFFFF0);
      size -= count;
      ptr  += count;
      base += count;
    }

  while (size > 16)
    {
      dump_hex_line   (ptr, 16, base, base);
      dump_ascii_line (ptr, 16, base, base);
      size -= 16;
      ptr  += 16;
      base += 16;
    }

  if (size != 0)
    {
      dump_hex_line   (ptr, size, base, base);
      dump_ascii_line (ptr, size, base, base);
    }
}

void read_sections(void)
{
  COFF_SCNHDR   sh; /* Section header structure */
  COFF_RELOC	re; /* Relocation entry structure */
  COFF_LINENO	le; /* Line number entry structure */
  char 	*raw_data;
  int	i,j;
  
  for (i = 0; i < num_sections; i++) 
    {
      fseek (fd, section_seek, 0);
      fread (&sh, COFF_SCNHSZ, 1, fd);
      section_seek += COFF_SCNHSZ;
      
      printf("\n %s - SECTION HEADER - \n", sh.s_name); 
      printf("s_paddr   = 0x%x\n", (int) COFF_SHORT (sh.s_paddr));
      printf("s_vaddr   = 0x%x\n", (int) COFF_LONG  (sh.s_vaddr));
      printf("s_size    = %d\n",   (int) COFF_LONG  (sh.s_size));
      printf("s_scnptr  = %d\n",   (int) COFF_LONG  (sh.s_scnptr));
      printf("s_relptr  = %d\n",   (int) COFF_LONG  (sh.s_relptr));
      printf("s_lnnoptr = %d\n",   (int) COFF_LONG  (sh.s_lnnoptr));
      printf("s_nreloc  = %d\n",   (int) COFF_SHORT (sh.s_nreloc));
      printf("s_nlnno   = %d\n",   (int) COFF_SHORT (sh.s_nlnno));
      printf("s_flags   = 0x%X, ", (int) COFF_SHORT (sh.s_flags));
      print_sect_flags ((int) COFF_SHORT (sh.s_flags));
      printf("\n");

      /* Output raw data only for text and data sections */
      if (strcmp(sh.s_name,".bss") != 0 && opt_r == 1)
	{
	  raw_data = (char *) malloc((size_t) COFF_LONG (sh.s_size));
	  fseek (fd,       (int) COFF_LONG (sh.s_scnptr), 0);
	  fread (raw_data, (int) COFF_LONG (sh.s_size), 1, fd);
	  
	  printf ("RAW DATA\n");
	  dump_hex_buffer (raw_data,
			   (int) COFF_LONG (sh.s_size),
			   (int) COFF_LONG (sh.s_vaddr));
	  free (raw_data);
	}
	
      if (COFF_SHORT (sh.s_nreloc) && opt_e == 1)
	{	
	  printf("\nRELOCATION ENTRIES\n");
	  fseek(fd, (long int) COFF_LONG (sh.s_relptr), 0);
	  j=0;

	  while(j < (int) COFF_SHORT (sh.s_nreloc)) 
	    {
	      fread(&re, COFF_RELSZ, 1, fd);
	      printf("r_vaddr = 0x%X",   (int) COFF_LONG (re.r_vaddr));
	      printf(" r_symndx = %d",   (int) COFF_LONG (re.r_symndx));
	      printf(" r_type = 0x%X\n", (int) COFF_SHORT (re.r_type));
	      j++;
	    }
	}
      
      if (COFF_SHORT (sh.s_nlnno) && opt_l == 1)
	{
	  printf ("\nLINE NUMBER ENTRIES \n");
	  fseek (fd, (long int) COFF_LONG (sh.s_lnnoptr), 0);
	  j = 0;
	  while(j < (int) COFF_SHORT (sh.s_nlnno)) 
	    {
	      fread(&le, COFF_LINESZ, 1, fd);
	      if (COFF_SHORT (le.l_lnno) == 0)
		printf("function address 0x%X\n",
		       (int) COFF_LONG (le.l_addr.l_symndx));
	      else 
		printf ("line# %d at address 0x%X\n",
			(int) COFF_SHORT (le.l_lnno),
			(int) COFF_LONG (le.l_addr.l_paddr));
	      j++;
	    }
	}
    }
}

void read_strings(void)
{
  int 	strings;
  char	*str_ptr;
  
  strings = symptr + COFF_SYMESZ * num_symbols;
  fseek (fd, strings, 0);
  fread (&str_length, 4, 1, fd);

  if (str_length && opt_s == 1) {
    printf("\nSTRING TABLE DUMP\n");
    str_length-=4;
    str_tab = (char *)malloc (str_length);
    fseek(fd,(strings+4),0);
    fread(str_tab,str_length,1,fd);
    str_ptr=str_tab;
    do
      {
	printf ("%s\n", str_ptr);
	while (*str_ptr++ != '\0');
      }
    while (str_ptr < (str_tab + str_length));
  }
}

void read_symbols(void)
{
  struct COFF_syment  se;
  union COFF_auxent   ae;
  int	i;
  int	j;

  if (opt_y == 1)
    {
      fseek(fd, symptr, 0);

      printf("\nSYMBOL TABLE ENTRIES\n");
      i = 0;
      while (i != num_symbols) 
	{
	  fread(&se, COFF_SYMESZ, 1, fd);
	  print_se(&se);
	  i++;
	  for (j = 0; j < (int) COFF_SHORT (se.e_numaux); j++) 
	    {
	      fread(&ae, COFF_AUXESZ, 1, fd);
	      print_ae ((char *) &ae);
	      i++;
	    }
	}
    }
}

void print_se (struct COFF_syment *se)
{
  int i;
  if (COFF_LONG (se->e.e.e_zeroes) != 0L)
    {
      for ( i = 0; i < 8; i++) 
	{
	  if ((se->e.e_name[i] > 0x1f) && (se->e.e_name[i] < 0x7f))
	    printf("%c", se->e.e_name[i]);
	  else 
	    printf(" ");
	}
    } 
  else
    printf("%s", &str_tab [(int) COFF_LONG (se->e.e.e_offset) - 4]);

  printf(" n_scnum=%d ", (int) COFF_SHORT (se->e_scnum));
  
  switch (COFF_SHORT (se->e_type) & 0xf) 
    {
    case T_CHAR:   printf("T_CHAR"); break;
    case T_SHORT:  printf("T_SHORT"); break;
    case T_INT:    printf("T_INT"); break;
    case T_LONG:   printf("T_LONG"); break;
    case T_FLOAT:  printf("T_FLOAT"); break;
    case T_DOUBLE: printf("T_DOUBLE"); break;
    case T_STRUCT: printf("T_STRUCT"); break;
    case T_UNION:  printf("T_UNION"); break;
    case T_ENUM:   printf("T_ENUM"); break;
    case T_MOE:    printf("T_MOE"); break;
    case T_UCHAR:  printf("T_UCHAR"); break;
    case T_USHORT: printf("T_USHORT"); break;
    case T_UINT:   printf("T_UINT"); break;
    case T_ULONG:  printf("T_ULONG"); break;
    default:       printf("n_type=%d", COFF_SHORT (se->e_type) & 0xf); break;
    }

  if (ISFCN (COFF_SHORT (se->e_type)))       
    printf(",DT_FCN ");
  else 
    if (ISPTR (COFF_SHORT (se->e_type)))  
      printf(",DT_PTR ");
    else 
      if (ISARY (COFF_SHORT (se->e_type)))  
	printf(",DT_ARY ");
  
  switch (COFF_SHORT (se->e_sclass))  
    {
    case C_NULL:
      printf(" C_NULL=0x%x",(int) COFF_LONG (se->e_value));
      break;
    case C_STAT:
      printf(" C_STAT=0x%x",(int) COFF_LONG (se->e_value));
      break;
    case C_EXT:
      printf(" C_EXT=0x%x",(int) COFF_LONG (se->e_value));
      break;
    case C_AUTO:
      printf(" C_AUTO=0x%x",(int) COFF_LONG (se->e_value));
      break;
    case C_FILE:
      printf(" C_FILE");
      break;
    case C_STRTAG:
      printf(" C_STRTAG");
      break;
    case C_EOS:
      printf(" C_EOS=0x%x",(int) COFF_LONG (se->e_value));
      break;
    case C_FCN:
      printf(" C_FCN=0x%x",(int) COFF_LONG (se->e_value));
      break;
    case C_EFCN:
      printf(" C_EFCN=0x%x",(int) COFF_LONG (se->e_value));
      break;
    default:
      printf(" n_sclass=0x%X", (int) COFF_SHORT (se->e_sclass));
      break;
    }

  printf(" n_numaux=%d\n", (int) COFF_SHORT (se->e_numaux));
}

void print_ae (char *ae)
{
  int i;
  printf(" Aux. = ");
  for( i = 1; i <= COFF_AUXESZ; i++ ) 
    {
      printf("%1X",(*ae>>4)&0xF);
      printf("%1X ",(*ae&0xF));
      ae++; 
    }
  printf("\n");
}
