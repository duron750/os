/*
 * ibcs trace -- mask of trace values
 *
 * $Id: trace.h,v 1.4 1994/05/26 15:04:57 mike Exp $
 * $Source: /var/CVS/ibcs/include/ibcs/trace.h,v $
 */
#define	TRACE_API	0x00000001 /* all call/return values */
#define	TRACE_IOCTL	0x00000002 /* all ioctl calls */
#define	TRACE_IOCTL_F	0x00000004 /* ioctl calls that fail */
#define TRACE_SIGNAL	0x00000008 /* all signal calls */
#define TRACE_SIGNAL_F	0x00000010 /* signal calls that fail */
#define TRACE_SOCKSYS	0x00000020 /* socksys and spx devices */
#define TRACE_COFF_LD	0x00000040 /* COFF loader */
#define	TRACE_FUNC	0x10000000 /* trace this function */

extern int ibcs_trace;
extern IBCS_func *ibcs_func_p;

extern int ibcs_trace_set(int arg);
extern int ibcs_trace_func(int per, int func, int val);
