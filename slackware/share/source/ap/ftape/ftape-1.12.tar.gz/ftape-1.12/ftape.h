#ifndef _FTAPE_H
#define _FTAPE_H

/*
 * Copyright (C) 1994 Bas Laarhoven.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; see the file COPYING.  If not, write to
the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.

 *
 $Source: /usr/src/distr/ftape-1.12/RCS/ftape.h,v $
 $Author: bas $
 *
 $Revision: 1.6 $
 $Date: 1994/05/26 23:43:45 $
 $State: Beta $
 *
 *      This file contains global definitions, typedefs and macro's
 *      for the QIC-40/80 floppy-tape driver for Linux.
 */

#include <linux/sched.h>

#include "tracing.h"

#define LINUX_TAPE_LABEL        "Linux raw format V1"
#define LINUX_TAPE_LABEL_LEN    (18)
#define LINUX_TAPE_LABEL_VERS   (LINUX_TAPE_LABEL_LEN + 1)

#define SECTOR_SIZE     (1024)
#define SECTORS_PER_SEGMENT (32)
#define BUFF_SIZE       (SECTORS_PER_SEGMENT * SECTOR_SIZE)
#define FTAPE_UNIT      (ftape_unit & 3)
#define FLOPPY_DMA      (2)
#define RQM_DELAY       (12)
#define MILLISECOND     (1)
#define SECOND          (1000)
#if !defined( HZ)
# error "HZ undefined."
#endif
#define MSPT            (SECOND / HZ) /* milliseconds per tick */

/* This defines the number of retries that the driver will allow
 * before giving up (and letting a higher level handle the error).
 */
#define RETRIES_ON_CRC_ERROR 3  /* number of low level retries */
#define RETRIES_ON_ECC_ERROR 3  /* ecc error when correcting segment */
#define RETRIES_ON_WRITE_ERROR 5 /* general write error */

/*      some usefull macro's
 */
#define ABS(a)          ((a) < 0 ? -(a) : (a))
#define NR_ITEMS( x)    (sizeof( x)/ sizeof( *x))

/*  this function only serves to suppress a compiler warning :-(
 */
static inline const char* RCSdummy( void) { return RCSid; }

typedef unsigned char byte;

#endif
