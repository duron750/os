.so man3/gets.3
