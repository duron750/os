#define VERSIONSTR "zsh 2.4.306 beta"
