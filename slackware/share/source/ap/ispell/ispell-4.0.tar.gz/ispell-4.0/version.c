char version[] = "GNU Ispell, version 4.0";
