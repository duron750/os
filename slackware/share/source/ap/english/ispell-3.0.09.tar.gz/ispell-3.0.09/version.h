/*
 * Since the strings in this file are printed out when the "-v" switch is
 * given to ispell, you may want to translate them into your native language.
 * However, any translation of these strings MUST accurately preserve the
 * legal rights under international law;  you may wish to consult a lawyer
 * about this since you will be responsible for the results of any
 * incorrect translation.
 */

static char * Version_ID[] = {
    "@(#) International Ispell Version 3.0.09 (beta), 01/10/92",
    "@(#) Copyright (c), 1983, by Pace Willisson",
    "@(#) International version Copyright (c) 1987, 1988, 1990, 1991, 1992,",
    "@(#) by Geoff Kuenning, Manhattan Beach, CA.  All rights reserved.",
    "@(#) Permission for non-profit reproduction and use is hereby granted.",
    "@(#) Commercial organizations may distribute ispell as a free part of a",
    "@(#) larger proprietary package for which a fee is charged.  Commercial",
    "@(#) organizations may also charge a reasonable reproduction fee for",
    "@(#) distributing ispell alone.  Modifications may be made so",
    "@(#) long as this notice is preserved, modified versions are",
    "@(#) clearly marked as such in this notice, all changes are",
    "@(#) dated, and the author of each modification is identified.",
    NULL
};

static char RCS_Version_ID[] =
    "$Id: version.h,v 1.18 1992/01/10 10:54:11 geoff Exp $";

/*
 * $Log:	version.h,v $
 * Revision 1.18  1992/01/10  10:54:11  geoff
 * Update to patch level 9.
 *
 * Revision 1.17  1992/01/09  09:29:54  geoff
 * Update to version 8, including adding 1992 to the copyright date.
 *
 * Revision 1.16  91/09/17  22:44:16  geoff
 * Update to patch level 6.  Clarify some issues in the copyright.
 * 
 * Revision 1.15  91/08/10  18:15:16  geoff
 * Update to patch 5.
 * 
 * Revision 1.14  91/07/27  20:50:12  geoff
 * Update to patch 4
 * 
 * Revision 1.13  91/07/17  02:10:25  geoff
 * Update to patch 3
 * 
 * Revision 1.12  91/07/05  16:48:36  geoff
 * Update to patch 2.
 * 
 * Revision 1.11  91/06/23  22:20:45  geoff
 * Update to patch 1
 * 
 * Revision 1.10  91/06/17  21:43:40  geoff
 * Update to beta status
 * 
 * Revision 1.9  90/12/29  03:05:13  geoff
 * Update current date, and update copyrights to include 1991, since that's
 * the expected release date.
 * 
 * Revision 1.8  90/09/04  01:12:25  geoff
 * Add a comment about the possibility of translation.  Update the alpha
 * date.  Update the copyright to include 1990.
 * 
 * Revision 1.7  89/04/27  23:35:02  geoff
 * Add an expanded copyright, and update the version to 3.0 alpha.  Note that
 * there is more than one 3.0 alpha;  check the date given to be sure which
 * one you have!
 * 
 * Revision 1.6  88/02/29  00:40:38  geoff
 * Update to reflect new (list-linked) capitalization handling
 * 
 * Revision 1.5  87/09/09  00:33:28  geoff
 * Update version to reflect adding collation information, bug fixes
 * 
 * Revision 1.4  87/08/28  21:21:11  geoff
 * Change to support a multi-line version that omits RCS information and
 * includes a copyright message.  Also change version number to reflect
 * alpha to Stefan Taxhet.
 * 
 * Revision 1.3  87/06/09  23:40:54  geoff
 * Update to reflect posting of patch 2a
 * 
 * Revision 1.2  87/05/28  21:20:24  geoff
 * Take out the #ifndef lint
 * 
 * Revision 1.1  87/05/25  21:34:56  geoff
 * Initial revision
 * 
 */
