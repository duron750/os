#!/bin/sh
PATH=$PATH:/sbin:/usr/sbin:/usr/local/sbin
export PATH
exec sudo.bin $*
