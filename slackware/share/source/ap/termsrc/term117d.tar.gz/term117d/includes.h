
/*
**
*/

#include "term.h"

#if defined(I_ERRNO)
#include <errno.h>
#endif

#ifdef I_TYPES
#ifndef titan
#include <sys/types.h>
#else
#include <types.h>
#endif
#endif

#ifdef I_SYS
#include <sys/time.h>
#include <sys/types.h>
#ifdef _AIX
#include <sys/select.h>
#endif
#ifdef SVR4
int gettimeofday(struct timeval *);
int select(int, fd_set *, fd_set *, fd_set *, struct timeval *);
#endif
#endif

#ifdef DYNIXPTX
#include <sys/types.h>
#include <time.h>
#include <sys/select.h>
int select(int, fd_set *, fd_set *, fd_set *, struct timeval *);
#endif

#ifdef I_IOCTL
#include <sys/ioctl.h>
#include <fcntl.h>
#endif

#ifdef I_STRING
#include <string.h>
#endif

#ifdef I_SOCKET
#include <sys/types.h>

#if !defined(NO_UNIX_DOMAIN) && !defined(TERM_NFS_DIR)
#include <sys/un.h>
#endif

#include <netinet/in.h>
#include <netdb.h>
#include <sys/socket.h>
#ifdef SYSV
#include <sys/utsname.h>
#endif
#ifdef SVR4
int accept(int, struct sockaddr *, int *);
int bind(int, struct sockaddr *, int);
int connect(int, struct sockaddr *, int);
int listen(int, int);
int socket(int, int, int);
int socketpair(int, int, int, int[]);
#endif
#endif

#ifdef I_GETOPT
#if defined(linux)
#include <getopt.h>
#else
#if defined(__hpux) || defined(__386BSD__) || defined(___386BSD___) || defined(SVR4) || defined(__NetBSD__) || defined(__OSF1__) || defined(__osf__) || defined(BSDI)
#if defined(__hpux__) || defined(__hpux) 
#include <unistd.h>
extern char *optarg;
extern int optind, opterr;
#endif
/* Do nothing -- declared in stdlib.h */
#else
int getopt(int argc, char *argv[], char *);
extern char *optarg;
extern int optind, opterr;
#endif
#endif
#endif

#ifdef I_TTY

# ifdef USE_TERMIOS
#  if defined(titan)
#   include <sys/stermio.h>
#  else
#  include <termios.h>
#  endif
# else
#  include <sgtty.h>
# endif

#endif

#include <stdio.h>
#if !defined(titan)
#  include <stdlib.h>
#else /* not titan */
extern char *getenv(char *name);
#include <malloc.h>
#endif /* titan */
#ifndef NeXT
#include "config.h"
#include <unistd.h>
#ifdef ultrix
#include <sys/file.h>
#endif
#else /* next */
#include <sys/types.h>
#include <sys/file.h>
#endif

