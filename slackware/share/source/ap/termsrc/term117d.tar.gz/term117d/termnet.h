/* Replace normal networking commands */

#define rcmd          term_rcmd
#define gethostbyname term_gethostbyname
#define gethostbyaddr term_gethostbyaddr
#define connect       term_connect
#define getsockname   term_getsockname
#define close_fd      term_close_fd
#define shutdown      term_shutdown
#define close         term_close
#define bind          term_bind
#define listen        term_listen
#define accept        term_accept

/* The ==-3 stuff is a trick to keep exec as a function... */
/* This may cause problems on machines that use recursive defines... */
/* I don't have a clue how to aviod this, since I can't figure out how */
/* to use an arbitrary # of arguments in a static function. */
#ifdef NEVER
#define execl \
         (seteuid(getuid())+setegid(getgid())==-3) ? -1 : (execl)
#define execle(term_exec_args) \
         (seteuid(getuid())+setegid(getgid())==-3) ? -1 : execle(term_exec_args)
#define execlp(term_exec_args) \
         (seteuid(getuid())+setegid(getgid())==-3) ? -1 : execlp(term_exec_args)
#define exect(term_exec_args) \
         (seteuid(getuid())+setegid(getgid())==-3) ? -1 : exect(term_exec_args)
#define execv(term_exec_args) \
         (seteuid(getuid())+setegid(getgid())==-3) ? -1 : execv(term_exec_args)
#define execvp(term_exec_args) \
         (seteuid(getuid())+setegid(getgid())==-3) ? -1 : execvp(term_exec_args)
#endif

