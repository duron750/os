/* $XFree86: mit/server/ddx/x386/x386Version.h,v 2.64 1994/03/08 04:46:31 dawes Exp $ */

#define X386_VERSION " 2.1 "
