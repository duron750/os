/*
 * $XFree86: mit/server/ddx/x386/common/xf86_Option.c,v 2.0 1993/07/31 09:01:53 dawes Exp $
 *
 * The purpose of this file is to initialise the xf86_OptionTab[] which
 * is setup in xf86_Option.h
 */

#define INIT_OPTIONS

#include "X.h"
#include "os.h"
#include "x386.h"

