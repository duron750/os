/* $XFree86: mit/server/ddx/x386/vga16/ibm/ibmTrace.h,v 2.0 1993/08/19 16:08:28 dawes Exp $ */

#define TRACE(x) /* empty */
