void *safemalloc(int, char *identifier);
void *safefree(void *ptr, char *which1, char *which2);
void check_all_mem(char *which1, char *which2);
