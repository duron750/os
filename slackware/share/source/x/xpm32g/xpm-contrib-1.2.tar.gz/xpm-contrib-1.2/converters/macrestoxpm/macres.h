/*
Copyright (c) 1993 Jason Patterson.

Permission to use, copy, modify, and distribute this software and its
documentation for any purpose and without fee is hereby granted.

Be aware, however, that using this software to extract icons from commercial
Macintosh applications may violate the copyright on these applications.

JASON PATTERSON DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE,
INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS. IN NO
EVENT SHALL JASON PATTERSON BE LIABLE FOR ANY SPECIAL, INDIRECT OR
CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM THE LOSS
OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
PERFORMANCE OF THIS SOFTWARE.
*/

/************************************************************************/
/*									*/
/* macrestoxpm: extract icons from mac reources and write out xpm icons	*/
/*									*/
/************************************************************************/

#define ICN   1
#define ics   2
#define icl4  3
#define ics4  4
#define icl8  5
#define ics8  6
#define ICON  7
#define SICN  8
#define CURS  9
#define other 0

extern int type;
