#include <X11/Intrinsic.h>
#include "main.h"

#ifdef _NO_PROTO
void QuitCB(widget, client_data, call_data)
Widget widget;
char *client_data;
caddr_t call_data;
#else
void QuitCB(Widget widget, char *client_data, caddr_t call_data)
#endif
{
/*
    if (on_root) {
	XtDestroyWidget(toplevel);
	XSetCloseDownMode(XtDisplay(widget), RetainPermanent);
	XCloseDisplay(XtDisplay(widget));
    };
*/
    exit(0);
};




#include <Xm/Xm.h>
#include "draw.h"
#include "main.h"

#ifdef _NO_PROTO
void SingleSelectionCB(widget, client_data, call_data)
Widget widget;
char *client_data;
caddr_t call_data;
#else
void SingleSelectionCB(Widget widget, char *client_data, caddr_t call_data)
#endif
{  
    int itemCount = 0;
    int n = 0;
    Arg args[10];  
    XmStringTable selectedItems;
    char *fName;

    
    XtSetArg(args[n], XmNselectedItemCount, &itemCount); n++;
    XtGetValues(widget, args, n);

    if(itemCount > 0) {
        n = 0;
	XtSetArg(args[n], XmNselectedItems, &selectedItems); n++;
	XtGetValues(widget, args, n);
	XmStringGetLtoR(selectedItems[0], XmSTRING_DEFAULT_CHARSET, &fName);
	DrawPixmap(XtDisplay(widget), drawingWindow, fName);
	free(fName);
    };
};
