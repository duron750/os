
#ifdef _NO_PROTO
void SetFileNames();
#else /* _NO_PROTO */
void SetFileNames(Widget fList, char **items, int nItems);
#endif /* _NO_PROTO */
