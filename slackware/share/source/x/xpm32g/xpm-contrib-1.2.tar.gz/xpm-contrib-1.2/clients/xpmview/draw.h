



#ifdef _NO_PROTO
extern void DrawPixmap();
#else
extern void DrawPixmap(Display *dpy, Window window, char *fName);
#endif
