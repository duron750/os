

extern Widget toplevel;  
extern Widget mainWindow;
extern Widget fList;
extern Widget form;
extern Widget separator;
extern Widget quitButton;
extern Widget draw;
extern Window drawingWindow;
extern unsigned char on_root;


#ifdef _NO_PROTO
extern void SetWatchCursor();
#else /* _NO_PROTO */
extern void SetWatchCursor(Widget w);
#endif /* _NO_PROTO */

#ifdef _NO_PROTO
extern void UnsetWatchCursor();
#else /* _NO_PROTO */
extern void UnsetWatchCursor(Widget w);
#endif /* _NO_PROTO */


