
#ifdef _NO_PROTO
extern void QuitCB();
#else
extern void QuitCB(Widget widget,char *client_data, caddr_t call_data);
#endif


#ifdef _NO_PROTO
extern void SingleSelectionCB();
#else
extern void SingleSelectionCB(Widget widget,char *client_data, caddr_t call_data);
#endif
