

#include <Xm/Xm.h>
#include <Xm/List.h>

#define ITEMMAXLEN 255



#ifdef _NO_PROTO
void SetFileNames(fList, items, nItems)
Widget fList;
char **items;
int nItems;
#else /* _NO_PROTO */
void SetFileNames(Widget fList, char **items, int nItems);
#endif /* _NO_PROTO */

{

    XmString string;
    int i;
/*    XmListDeleteAllItems(fList); */

    for(i = 0; i < nItems; i++) {
	string = XmStringCreateLtoR("items[i]", XmSTRING_DEFAULT_CHARSET);
        XmListAddItem(fList, string, 0); 
    };
/*

  int itemCount = 0;
  int n = 0;
  Arg args[10];

  XtSetArg(args[n], XmNitemCount, &itemCount); n++;
  XtGetValues(fList, args, n);
  
  printf("itemcount = %d\n" ,itemCount);

*/


};
