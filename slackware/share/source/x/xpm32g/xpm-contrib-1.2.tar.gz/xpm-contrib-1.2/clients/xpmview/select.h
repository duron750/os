

void SetSelection(
#ifndef _NO_PROTO
		  Widget widget, char *string
#endif /* _NO_PROTO */
);
