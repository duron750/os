/*
 * $Id: xpm-contrib.shar,v 1.2 1993/10/27 17:01:15 lehors Exp $
 *
 * Copyright 1992 Lionel Mallet
 *
 * Permission to use, copy, modify, distribute, and sell this software and its
 * documentation for any purpose is hereby granted without fee, provided that
 * the above copyright notice appears in all copies and that both that
 * copyright notice and this permission notice appear in supporting
 * documentation, and that the name of Lionel MALLET not be used in
 * advertising or publicity pertaining to distribution of the software
 * without specific, written prior permission.  Lionel MALLET makes no
 * representations about the suitability of this software for any
 * purpose.  It is provided "as is" without express or implied warranty.
 *
 * Lionel MALLET DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS
 * SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND
 * FITNESS, IN NO EVENT SHALL Lionel MALLET BE LIABLE FOR ANY SPECIAL,
 * INDIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER
 * RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION
 * OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN
 * CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 *  This software is opened and free. Furthermore, everybody is kindly
 * invited to participate to improve it for the benefit of all.
 * Improvements can be new features, bugs fixes and porting issues
 * resolution.
 *
 * Author:  Tim Wise - Scientific & Engineering Software (SES), Inc.
 */


extern void unsetKillfromWM();


static void PopupTextOptions(button, textOptions)
    Widget      button;
    TextOptions *textOptions;
{
    Position	   x, y;
    Dimension	   width, height;

    if (!textOptions->up) {

        XtVaGetValues( button, 
                       XtNwidth,  &width,
                       XtNheight, &height,
                       NULL );
        
        XtTranslateCoords(button, 
			  (Position) (width / 2), (Position) (height / 2),
			  &x, &y );
    
        XtVaSetValues( textOptions->shell, 
                       XtNx, x,
                       XtNy, y,
                       NULL );

#ifndef USE_ATHENA
	XtManageChild(textOptions->popup);
#else
	XtPopup(textOptions->popup, XtGrabNone);
#endif
    unsetKillfromWM(textOptions->popup);
    textOptions->up = True;
    } else textOptions->up = False;

}


static void PopdownTextOptions( w, client_data, call_data )
    Widget	w;		/* button of form of popup */
    XtPointer	client_data;	/* TextOptions* */
    XtPointer	call_data;	/* unused */
{
    TextOptions *text_options = (TextOptions *) client_data;
#ifndef USE_ATHENA
    XtUnmanageChild(textOptions->popup);
#else
    XtPopdown(textOptions->popup);
#endif
}


static void Apply( w, client_data, call_data )
    Widget	w;		/* apply button */
    XtPointer	client_data;	/* TextOptions* */
    XtPointer	call_data;	/* unused */
{
    TextOptions *text_options = (TextOptions *) client_data;
    String	new_font_name = NULL;
    String	new_text_string = NULL;
    
    /* get new font name and new text string */
#ifndef USE_ATHENA
    /* Big hack for Motif: avoid arbitrary resizing problems */
    Dimension width, height;
    XtVaGetValues(textOptions->popup, XmNwidth, &width, XmNheight, &height,
		  NULL);
    
    new_font_name = (String) XmTextFieldGetString(text_options->font);
    new_text_string = (String) XmTextFieldGetString(text_options->text);
    
#else
    XtVaGetValues( text_options->font, 
                   XtNstring, &new_font_name, 
                   NULL );
    new_font_name = XtNewString( new_font_name );

    XtVaGetValues( text_options->text, 
                   XtNstring, &new_text_string, 
                   NULL );
    new_text_string = XtNewString( new_text_string );
#endif

    /* if new font name != current font name, ... */

    if (strcmp( new_font_name, text_options->font_name )) {

        Display     *dpy      = XtDisplay(text_options->popup);
        XFontStruct *new_font = XLoadQueryFont( dpy, new_font_name );

        if (new_font) {
#ifndef USE_ATHENA
	    XmString xmstr;

	    xmstr = XmStringCreateLtoR("Valid font, text ready to paste",
				       XmSTRING_DEFAULT_CHARSET);
	    XtVaSetValues(text_options->status, XmNlabelString, xmstr, NULL);
	    XmStringFree(xmstr);
	    
	    /* Big hack for Motif: avoid arbitrary resizing problems */
	    XtVaSetValues(textOptions->shell, XmNwidth, width,
			  XmNheight, height, NULL);
#else    
            XtVaSetValues(text_options->status, 
			  XtNlabel, "Valid font, text ready to paste",
			  NULL );
#endif
        }
        else {
#ifndef USE_ATHENA
	    XmString xmstr;

	    xmstr = XmStringCreateLtoR("No font with this name!",
				       XmSTRING_DEFAULT_CHARSET);
	    XtVaSetValues(text_options->status, XmNlabelString, xmstr, NULL);
	    XmStringFree(xmstr);
	    
	    /* Big hack for Motif: avoid arbitrary resizing problems */
	    XtVaSetValues(textOptions->shell, XmNwidth, width,
			  XmNheight, height, NULL);
#else    
            XtVaSetValues( text_options->status, 
                           XtNlabel, "No font with this name!", 
                           NULL );
#endif
        }

        if (text_options->font_struct)
            XFreeFont( dpy, text_options->font_struct );
        XtFree( text_options->font_name );

        text_options->font_struct = new_font;
        text_options->font_name   = XtNewString( new_font_name );

        PWSetFont( pixmap_widget, text_options->font_struct );
    }

    /* if new text string != current text string, ... */
    if (strcmp( new_text_string, text_options->text_string ) != 0) {

        XtFree( text_options->text_string );
        text_options->text_string = XtNewString( new_text_string );
        PWSetText( pixmap_widget, text_options->text_string );
    }

#ifndef USE_ATHENA
#endif

    XtFree( new_font_name );
    XtFree( new_text_string );
}

#ifdef USE_ATHENA
static void ApplyAction( w, event, params, num_params )
    Widget	w;		/* either text or font widget */
    XEvent	*event;
    String	*params;
    Cardinal	*num_params;
{
    Widget	form = XtParent(w);

    /* how to get TextOptions data structure ? */
    /* oh, just use that global pointer */
    Apply( w, (XtPointer) textOptions, (XtPointer) NULL );
}


static XtActionsRec actions[] = {
  { "apply", ApplyAction }
};
#endif

TextOptions* CreateTextOptions(parent, name ) 
    Widget	parent;
    String	name;
{
    Widget	popup, shell, textOptions, 
		title, 
		status, 
		font_label, font, 
		text_label, text, 
		close, apply;
    String	font_name, text_string;
    
    TextOptions *text_options = (TextOptions *)XtCalloc(1,
							sizeof(TextOptions));

#ifdef USE_ATHENA
    XtAppAddActions(pixmap_context, actions, XtNumber(actions));
#endif

#ifndef USE_ATHENA
    textOptions = XmCreateFormDialog(parent, name, NULL, 0);
    popup = textOptions;
    shell = XtParent(popup);
    
    title = XmCreateLabelGadget(textOptions, "title", NULL, 0);
    XtManageChild(title);

    status = XmCreateLabelGadget(textOptions, "fontStatus", NULL, 0);
    XtManageChild(status);

    font_label = XmCreateLabelGadget(textOptions, "fontLabel", NULL, 0);
    XtManageChild(font_label);

    font = (Widget) XmCreateTextField(textOptions, "fontName", NULL, 0);
    XtManageChild(font);
    XtAddCallback(font, XmNactivateCallback, Apply, (XtPointer)text_options);

    text_label = XmCreateLabelGadget(textOptions, "textLabel", NULL, 0);
    XtManageChild(text_label);
    
    text = (Widget) XmCreateTextField(textOptions, "textString", NULL, 0);
    XtManageChild(text);
    XtAddCallback(text, XmNactivateCallback, Apply, (XtPointer)text_options);
    
    close = XmCreatePushButtonGadget(textOptions, "close", NULL, 0);
    XtManageChild(close);
    XtAddCallback(close, XmNactivateCallback, PopdownTextOptions,
		  (XtPointer)text_options);

    apply = XmCreatePushButtonGadget(textOptions, "apply", NULL, 0);
    XtManageChild(apply);
    XtAddCallback(apply, XmNactivateCallback, Apply, (XtPointer)text_options);
    
#else
    popup = XtCreatePopupShell(
			"textOptionsShell", transientShellWidgetClass, 
			parent,
			NULL, 0 );
    shell = popup;
    
    textOptions = XtCreateManagedWidget( 
			"textOptions", formWidgetClass, 
			popup,
			NULL, 0 );

    title = XtCreateManagedWidget(
			"title", labelWidgetClass, 
			textOptions,
			NULL, 0 );

    status = XtCreateManagedWidget(
			"fontStatus", labelWidgetClass, 
			textOptions,
			NULL, 0 );

    font_label = XtCreateManagedWidget(
			"fontLabel", labelWidgetClass, 
			textOptions,
			NULL, 0 );

    font = XtCreateManagedWidget(
			"fontName", asciiTextWidgetClass, 
			textOptions,
			NULL, 0 );

    text_label = XtCreateManagedWidget(
			"textLabel", labelWidgetClass, 
			textOptions,
			NULL, 0 );

    text = XtCreateManagedWidget(
			"textString", asciiTextWidgetClass, 
			textOptions,
			NULL, 0 );

    close = XtCreateManagedWidget(
			"close", commandWidgetClass, 
			textOptions,
			NULL, 0 );
    XtAddCallback(close, XtNcallback, PopdownTextOptions,
		  (XtPointer)text_options);

    apply = XtCreateManagedWidget(
			"apply", commandWidgetClass, 
			textOptions,
			NULL, 0 );
    XtAddCallback(apply, XtNcallback, Apply, (XtPointer) text_options);
#endif

    text_options->up     = False;
    text_options->popup  = popup;
    text_options->shell  = shell;
    text_options->text   = text;
    text_options->font   = font;
    text_options->status = status;

#ifndef USE_ATHENA
    text_options->font_name = (String)XmTextFieldGetString(text_options->font);
#else
    XtVaGetValues( text_options->font, 
                   XtNstring, &font_name, 
                   NULL );
    text_options->font_name = XtNewString( font_name );
#endif
    text_options->font_struct = XLoadQueryFont(XtDisplay(parent),
					       text_options->font_name);

#ifndef USE_ATHENA
    text_options->text_string=(String)XmTextFieldGetString(text_options->text);
#else
    XtVaGetValues( text_options->text, 
                   XtNstring, &text_string, 
                   NULL );
    text_options->text_string = XtNewString(text_string);
#endif

    
    return text_options;
}

