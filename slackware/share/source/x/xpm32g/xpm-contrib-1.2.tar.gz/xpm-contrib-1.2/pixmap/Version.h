/* * Last edited: Oct 29 9:44 1992 (mallet) */
static char *version = "$PixmapEditorVersion: 2.1 $";

static char *info ="\n\
Pixmap 2.1 was derived from Davor Matic's Bitmap\n\
by Lionel Mallet - Simulog, helped by Tim Wise - SES Inc.\n\
(Davor Matic is member of the Xconsortium AnneX)\n\
Pixmap uses the enhanced Xpm library written by\n\
Arnaud Le Hors from Groupe Bull.\n\
\n\
For bugs and suggestions write to:\n\
         pixmap@sophia.inria.fr";
