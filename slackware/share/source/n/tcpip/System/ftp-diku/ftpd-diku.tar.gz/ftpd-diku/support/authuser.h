#ifndef AUTHUSER_H
#define AUTHUSER_H

extern unsigned short auth_tcpport;
extern char *auth_xline();
extern int auth_fd();
extern char *auth_tcpuser();

#endif
