
/*  A Bison parser, made from ftpcmd.y with Bison version GNU Bison version 1.22
  */

#define YYBISON 1  /* Identify Bison output.  */

#define	A	258
#define	B	259
#define	C	260
#define	E	261
#define	F	262
#define	I	263
#define	L	264
#define	N	265
#define	P	266
#define	R	267
#define	S	268
#define	T	269
#define	SP	270
#define	CRLF	271
#define	COMMA	272
#define	STRING	273
#define	NUMBER	274
#define	USER	275
#define	PASS	276
#define	ACCT	277
#define	REIN	278
#define	QUIT	279
#define	PORT	280
#define	PASV	281
#define	TYPE	282
#define	STRU	283
#define	MODE	284
#define	RETR	285
#define	STOR	286
#define	APPE	287
#define	MLFL	288
#define	MAIL	289
#define	MSND	290
#define	MSOM	291
#define	MSAM	292
#define	MRSQ	293
#define	MRCP	294
#define	ALLO	295
#define	REST	296
#define	RNFR	297
#define	RNTO	298
#define	ABOR	299
#define	DELE	300
#define	CWD	301
#define	LIST	302
#define	NLST	303
#define	SITE	304
#define	STAT	305
#define	HELP	306
#define	NOOP	307
#define	MKD	308
#define	RMD	309
#define	PWD	310
#define	CDUP	311
#define	STOU	312
#define	SMNT	313
#define	SYST	314
#define	SIZE	315
#define	MDTM	316
#define	UMASK	317
#define	IDLE	318
#define	CHMOD	319
#define	GROUP	320
#define	GPASS	321
#define	NEWER	322
#define	MINFO	323
#define	LEXERR	324

#line 27 "ftpcmd.y"


#ifndef lint
static char sccsid[] = "@(#)ftpcmd.y	5.23 (Berkeley) 6/1/90";
#endif /* not lint */

#include <sys/param.h>
#include <sys/socket.h>

#include <netinet/in.h>

#include <arpa/ftp.h>

#include <stdio.h>
#include <signal.h>
#include <ctype.h>
#include <pwd.h>
#include <setjmp.h>
#include <syslog.h>
#include <sys/stat.h>
#include <time.h>
#include <string.h>
#include "support/ftw.h"
#include <malloc.h>

extern	struct tab sitetab[], cmdtab[];
extern	struct sockaddr_in data_dest;
extern	int logged_in;
extern	struct passwd *pw;
extern	int anonymous;
extern	int logging;
extern	int	cmdlogging;
extern	int type;
extern	int form;
extern	int debug;
extern	int timeout;
extern	int maxtimeout;
extern  int pdata;
extern	char hostname[], remotehost[];
extern	char proctitle[];
extern	char *globerr;
extern	int usedefault;
extern  int transflag;
extern  char tmpline[];
extern	int data;
char	**glob();
off_t	restart_point;

extern	char	*strunames[];
extern	char	*typenames[];
extern	char	*modenames[];
extern	char	*formnames[];

static	int cmd_type;
static	int cmd_form;
static	int cmd_bytesz;
char	cbuf[512];
char	*fromname;


#line 107 "ftpcmd.y"
typedef union {
    char	*String;
    int		Number;
} YYSTYPE;

#ifndef YYLTYPE
typedef
  struct yyltype
    {
      int timestamp;
      int first_line;
      int first_column;
      int last_line;
      int last_column;
      char *text;
   }
  yyltype;

#define YYLTYPE yyltype
#endif

#include <stdio.h>

#ifndef __cplusplus
#ifndef __STDC__
#define const
#endif
#endif



#define	YYFINAL		230
#define	YYFLAG		-32768
#define	YYNTBASE	70

#define YYTRANSLATE(x) ((unsigned)(x) <= 324 ? yytranslate[x] : 85)

static const char yytranslate[] = {     0,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     1,     2,     3,     4,     5,
     6,     7,     8,     9,    10,    11,    12,    13,    14,    15,
    16,    17,    18,    19,    20,    21,    22,    23,    24,    25,
    26,    27,    28,    29,    30,    31,    32,    33,    34,    35,
    36,    37,    38,    39,    40,    41,    42,    43,    44,    45,
    46,    47,    48,    49,    50,    51,    52,    53,    54,    55,
    56,    57,    58,    59,    60,    61,    62,    63,    64,    65,
    66,    67,    68,    69
};

#if YYDEBUG != 0
static const short yyprhs[] = {     0,
     0,     1,     4,     7,    12,    17,    22,    25,    30,    35,
    40,    45,    54,    60,    66,    72,    76,    82,    86,    92,
    98,   101,   107,   112,   115,   119,   125,   128,   133,   136,
   142,   148,   152,   156,   161,   168,   174,   182,   192,   197,
   204,   212,   220,   228,   238,   248,   254,   257,   263,   269,
   272,   275,   281,   286,   288,   289,   291,   293,   305,   307,
   309,   311,   313,   317,   319,   323,   325,   327,   331,   334,
   336,   338,   340,   342,   344,   346,   348,   350,   352
};

static const short yyrhs[] = {    -1,
    70,    71,     0,    70,    72,     0,    20,    15,    73,    16,
     0,    21,    15,    74,    16,     0,    25,    15,    76,    16,
     0,    26,    16,     0,    27,    15,    78,    16,     0,    28,
    15,    79,    16,     0,    29,    15,    80,    16,     0,    40,
    15,    19,    16,     0,    40,    15,    19,    15,    12,    15,
    19,    16,     0,    30,    84,    15,    81,    16,     0,    31,
    84,    15,    81,    16,     0,    32,    84,    15,    81,    16,
     0,    48,    84,    16,     0,    48,    84,    15,    18,    16,
     0,    47,    84,    16,     0,    47,    84,    15,    81,    16,
     0,    50,    84,    15,    81,    16,     0,    50,    16,     0,
    45,    84,    15,    81,    16,     0,    43,    15,    81,    16,
     0,    44,    16,     0,    46,    84,    16,     0,    46,    84,
    15,    81,    16,     0,    51,    16,     0,    51,    15,    18,
    16,     0,    52,    16,     0,    53,    84,    15,    81,    16,
     0,    54,    84,    15,    81,    16,     0,    55,    84,    16,
     0,    56,    84,    16,     0,    49,    15,    51,    16,     0,
    49,    15,    51,    15,    18,    16,     0,    49,    15,    62,
    84,    16,     0,    49,    15,    62,    84,    15,    83,    16,
     0,    49,    15,    64,    84,    15,    83,    15,    81,    16,
     0,    49,    15,    63,    16,     0,    49,    15,    63,    15,
    19,    16,     0,    49,    15,    65,    84,    15,    73,    16,
     0,    49,    15,    66,    84,    15,    74,    16,     0,    49,
    15,    67,    84,    15,    18,    16,     0,    49,    15,    67,
    84,    15,    18,    15,    81,    16,     0,    49,    15,    68,
    84,    15,    18,    15,    81,    16,     0,    57,    84,    15,
    81,    16,     0,    59,    16,     0,    60,    84,    15,    81,
    16,     0,    61,    84,    15,    81,    16,     0,    24,    16,
     0,     1,    16,     0,    42,    84,    15,    81,    16,     0,
    41,    15,    75,    16,     0,    18,     0,     0,    18,     0,
    19,     0,    19,    17,    19,    17,    19,    17,    19,    17,
    19,    17,    19,     0,    10,     0,    14,     0,     5,     0,
     3,     0,     3,    15,    77,     0,     6,     0,     6,    15,
    77,     0,     8,     0,     9,     0,     9,    15,    75,     0,
     9,    75,     0,     7,     0,    12,     0,    11,     0,    13,
     0,     4,     0,     5,     0,    82,     0,    18,     0,    19,
     0,     0
};

#endif

#if YYDEBUG != 0
static const short yyrline[] = { 0,
   120,   121,   126,   129,   135,   146,   156,   161,   197,   210,
   223,   228,   233,   241,   249,   257,   263,   271,   277,   285,
   293,   298,   306,   318,   323,   329,   337,   342,   358,   363,
   371,   379,   385,   391,   396,   401,   412,   428,   442,   449,
   462,   468,   474,   479,   485,   491,   499,   521,   539,   562,
   568,   573,   586,   598,   601,   606,   609,   612,   625,   629,
   633,   639,   644,   649,   654,   659,   663,   668,   674,   681,
   685,   689,   695,   699,   703,   709,   728,   731,   756
};

static const char * const yytname[] = {   "$","error","$illegal.","A","B","C",
"E","F","I","L","N","P","R","S","T","SP","CRLF","COMMA","STRING","NUMBER","USER",
"PASS","ACCT","REIN","QUIT","PORT","PASV","TYPE","STRU","MODE","RETR","STOR",
"APPE","MLFL","MAIL","MSND","MSOM","MSAM","MRSQ","MRCP","ALLO","REST","RNFR",
"RNTO","ABOR","DELE","CWD","LIST","NLST","SITE","STAT","HELP","NOOP","MKD","RMD",
"PWD","CDUP","STOU","SMNT","SYST","SIZE","MDTM","UMASK","IDLE","CHMOD","GROUP",
"GPASS","NEWER","MINFO","LEXERR","cmd_list","cmd","rcmd","username","password",
"byte_size","host_port","form_code","type_code","struct_code","mode_code","pathname",
"pathstring","octal_number","check_login",""
};
#endif

static const short yyr1[] = {     0,
    70,    70,    70,    71,    71,    71,    71,    71,    71,    71,
    71,    71,    71,    71,    71,    71,    71,    71,    71,    71,
    71,    71,    71,    71,    71,    71,    71,    71,    71,    71,
    71,    71,    71,    71,    71,    71,    71,    71,    71,    71,
    71,    71,    71,    71,    71,    71,    71,    71,    71,    71,
    71,    72,    72,    73,    74,    74,    75,    76,    77,    77,
    77,    78,    78,    78,    78,    78,    78,    78,    78,    79,
    79,    79,    80,    80,    80,    81,    82,    83,    84
};

static const short yyr2[] = {     0,
     0,     2,     2,     4,     4,     4,     2,     4,     4,     4,
     4,     8,     5,     5,     5,     3,     5,     3,     5,     5,
     2,     5,     4,     2,     3,     5,     2,     4,     2,     5,
     5,     3,     3,     4,     6,     5,     7,     9,     4,     6,
     7,     7,     7,     9,     9,     5,     2,     5,     5,     2,
     2,     5,     4,     1,     0,     1,     1,    11,     1,     1,
     1,     1,     3,     1,     3,     1,     1,     3,     2,     1,
     1,     1,     1,     1,     1,     1,     1,     1,     0
};

static const short yydefact[] = {     1,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
    79,    79,    79,     0,     0,    79,     0,     0,    79,    79,
    79,    79,     0,    79,     0,     0,    79,    79,    79,    79,
    79,     0,    79,    79,     2,     3,    51,     0,    55,    50,
     0,     7,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,    24,     0,     0,     0,     0,     0,    21,     0,
     0,    27,    29,     0,     0,     0,     0,     0,    47,     0,
     0,    54,     0,    56,     0,     0,     0,    62,    64,    66,
    67,     0,    70,    72,    71,     0,    74,    75,    73,     0,
     0,     0,     0,     0,    57,     0,     0,    77,     0,    76,
     0,     0,    25,     0,    18,     0,    16,     0,    79,     0,
    79,    79,    79,    79,    79,     0,     0,     0,     0,    32,
    33,     0,     0,     0,     4,     5,     0,     6,     0,     0,
     0,    69,     8,     9,    10,     0,     0,     0,     0,    11,
    53,     0,    23,     0,     0,     0,     0,     0,    34,     0,
     0,    39,     0,     0,     0,     0,     0,     0,    28,     0,
     0,     0,     0,     0,     0,    61,    59,    60,    63,    65,
    68,    13,    14,    15,     0,    52,    22,    26,    19,    17,
     0,     0,    36,     0,     0,     0,    55,     0,     0,    20,
    30,    31,    46,    48,    49,     0,     0,    35,    78,     0,
    40,     0,     0,     0,     0,     0,     0,     0,    37,     0,
    41,    42,     0,    43,     0,     0,    12,     0,     0,     0,
     0,    38,    44,    45,     0,     0,     0,    58,     0,     0
};

static const short yydefgoto[] = {     1,
    35,    36,    73,    75,    96,    77,   169,    82,    86,    90,
    99,   100,   200,    46
};

static const short yypact[] = {-32768,
    39,    -4,    11,    14,    29,    43,    60,    86,    90,    99,
-32768,-32768,-32768,   100,   101,-32768,   102,    91,-32768,-32768,
-32768,-32768,   103,   104,    -8,   105,-32768,-32768,-32768,-32768,
-32768,   107,-32768,-32768,-32768,-32768,-32768,   108,   109,-32768,
   106,-32768,    69,    50,    17,   113,   114,   115,   119,   120,
   117,   122,-32768,   126,     8,    21,    32,   -48,-32768,   127,
   125,-32768,-32768,   129,   130,   131,   132,   134,-32768,   135,
   136,-32768,   137,-32768,   138,   139,   141,   140,   143,-32768,
   -10,   144,-32768,-32768,-32768,   145,-32768,-32768,-32768,   146,
   122,   122,   122,    58,-32768,   147,   122,-32768,   148,-32768,
   122,   122,-32768,   122,-32768,   128,-32768,    88,-32768,    93,
-32768,-32768,-32768,-32768,-32768,   122,   149,   122,   122,-32768,
-32768,   122,   122,   122,-32768,-32768,   133,-32768,    92,    92,
   120,-32768,-32768,-32768,-32768,   150,   151,   152,   157,-32768,
-32768,   154,-32768,   155,   156,   158,   159,   160,-32768,    95,
   161,-32768,   162,   164,   166,   167,   168,   169,-32768,   170,
   171,   172,   173,   174,   142,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,-32768,-32768,   176,-32768,-32768,-32768,-32768,-32768,
   177,   165,-32768,   178,   165,   108,   109,   179,   180,-32768,
-32768,-32768,-32768,-32768,-32768,   181,   182,-32768,-32768,   183,
-32768,   187,   188,   189,    97,   191,   175,   192,-32768,   122,
-32768,-32768,   122,-32768,   122,   184,-32768,   193,   194,   195,
   190,-32768,-32768,-32768,   196,   197,   198,-32768,   212,-32768
};

static const short yypgoto[] = {-32768,
-32768,-32768,   -13,   -11,   -77,-32768,    65,-32768,-32768,-32768,
   -91,-32768,    28,    22
};


#define	YYLAST		217


static const short yytable[] = {   136,
   137,   138,   108,   132,   131,   142,    61,    62,    95,   144,
   145,    37,   146,   109,   110,   111,   112,   113,   114,   115,
    87,    88,   102,   103,   158,    38,   160,   161,    39,    89,
   162,   163,   164,    47,    48,   104,   105,    51,   229,     2,
    54,    55,    56,    57,    40,    60,   106,   107,    64,    65,
    66,    67,    68,   171,    70,    71,    83,    41,     3,     4,
    84,    85,     5,     6,     7,     8,     9,    10,    11,    12,
    13,    78,   139,   140,    79,    42,    80,    81,    14,    15,
    16,    17,    18,    19,    20,    21,    22,    23,    24,    25,
    26,    27,    28,    29,    30,    31,   166,    32,    33,    34,
    43,   167,   148,   149,    44,   168,    53,   151,   152,   182,
   183,   213,   214,    45,    49,    50,    52,    58,   218,    59,
    63,   219,    69,   220,    76,    72,    74,    91,    92,    93,
   150,    97,   153,   154,   155,   156,   157,    94,    95,    98,
   101,   116,   117,   118,   119,   147,   120,   121,   122,   123,
   124,   165,   125,   126,   129,   127,   128,   130,   196,   133,
   134,   135,   141,   143,   159,   172,   173,   174,   175,   176,
   177,   178,   203,   179,   180,   204,   185,   181,   186,   184,
   187,   188,   189,   199,   190,   191,   192,   193,   194,   195,
   197,   216,   198,   201,   170,     0,   205,   206,   209,   207,
   208,   210,   221,   211,   212,   215,   225,   217,   222,   223,
   224,   230,   202,   227,   226,     0,   228
};

static const short yycheck[] = {    91,
    92,    93,    51,    81,    15,    97,    15,    16,    19,   101,
   102,    16,   104,    62,    63,    64,    65,    66,    67,    68,
     4,     5,    15,    16,   116,    15,   118,   119,    15,    13,
   122,   123,   124,    12,    13,    15,    16,    16,     0,     1,
    19,    20,    21,    22,    16,    24,    15,    16,    27,    28,
    29,    30,    31,   131,    33,    34,     7,    15,    20,    21,
    11,    12,    24,    25,    26,    27,    28,    29,    30,    31,
    32,     3,    15,    16,     6,    16,     8,     9,    40,    41,
    42,    43,    44,    45,    46,    47,    48,    49,    50,    51,
    52,    53,    54,    55,    56,    57,     5,    59,    60,    61,
    15,    10,    15,    16,    15,    14,    16,    15,    16,    15,
    16,    15,    16,    15,    15,    15,    15,    15,   210,    16,
    16,   213,    16,   215,    19,    18,    18,    15,    15,    15,
   109,    15,   111,   112,   113,   114,   115,    19,    19,    18,
    15,    15,    18,    15,    15,    18,    16,    16,    15,    15,
    15,    19,    16,    16,    15,    17,    16,    15,    17,    16,
    16,    16,    16,    16,    16,    16,    16,    16,    12,    16,
    16,    16,   186,    16,    16,   187,    15,    18,    15,    19,
    15,    15,    15,    19,    16,    16,    16,    16,    16,    16,
    15,    17,    16,    16,   130,    -1,    18,    18,    16,    19,
    19,    15,    19,    16,    16,    15,    17,    16,    16,    16,
    16,     0,   185,    17,    19,    -1,    19
};
/* -*-C-*-  Note some compilers choke on comments on `#line' lines.  */
#line 3 "/usr/local/lib/bison.simple"

/* Skeleton output parser for bison,
   Copyright (C) 1984, 1989, 1990 Bob Corbett and Richard Stallman

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 1, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.  */


#ifndef alloca
#ifdef __GNUC__
#define alloca __builtin_alloca
#else /* not GNU C.  */
#if (!defined (__STDC__) && defined (sparc)) || defined (__sparc__) || defined (__sparc) || defined (__sgi)
#include <alloca.h>
#else /* not sparc */
#if defined (MSDOS) && !defined (__TURBOC__)
#include <malloc.h>
#else /* not MSDOS, or __TURBOC__ */
#if defined(_AIX)
#include <malloc.h>
 #pragma alloca
#else /* not MSDOS, __TURBOC__, or _AIX */
#ifdef __hpux
#ifdef __cplusplus
extern "C" {
void *alloca (unsigned int);
};
#else /* not __cplusplus */
void *alloca ();
#endif /* not __cplusplus */
#endif /* __hpux */
#endif /* not _AIX */
#endif /* not MSDOS, or __TURBOC__ */
#endif /* not sparc.  */
#endif /* not GNU C.  */
#endif /* alloca not defined.  */

/* This is the parser code that is written into each bison parser
  when the %semantic_parser declaration is not specified in the grammar.
  It was written by Richard Stallman by simplifying the hairy parser
  used when %semantic_parser is specified.  */

/* Note: there must be only one dollar sign in this file.
   It is replaced by the list of actions, each action
   as one case of the switch.  */

#define yyerrok		(yyerrstatus = 0)
#define yyclearin	(yychar = YYEMPTY)
#define YYEMPTY		-2
#define YYEOF		0
#define YYACCEPT	return(0)
#define YYABORT 	return(1)
#define YYERROR		goto yyerrlab1
/* Like YYERROR except do call yyerror.
   This remains here temporarily to ease the
   transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  */
#define YYFAIL		goto yyerrlab
#define YYRECOVERING()  (!!yyerrstatus)
#define YYBACKUP(token, value) \
do								\
  if (yychar == YYEMPTY && yylen == 1)				\
    { yychar = (token), yylval = (value);			\
      yychar1 = YYTRANSLATE (yychar);				\
      YYPOPSTACK;						\
      goto yybackup;						\
    }								\
  else								\
    { yyerror ("syntax error: cannot back up"); YYERROR; }	\
while (0)

#define YYTERROR	1
#define YYERRCODE	256

#ifndef YYPURE
#define YYLEX		yylex()
#endif

#ifdef YYPURE
#ifdef YYLSP_NEEDED
#define YYLEX		yylex(&yylval, &yylloc)
#else
#define YYLEX		yylex(&yylval)
#endif
#endif

/* If nonreentrant, generate the variables here */

#ifndef YYPURE

int	yychar;			/*  the lookahead symbol		*/
YYSTYPE	yylval;			/*  the semantic value of the		*/
				/*  lookahead symbol			*/

#ifdef YYLSP_NEEDED
YYLTYPE yylloc;			/*  location data for the lookahead	*/
				/*  symbol				*/
#endif

int yynerrs;			/*  number of parse errors so far       */
#endif  /* not YYPURE */

#if YYDEBUG != 0
int yydebug;			/*  nonzero means print parse trace	*/
/* Since this is uninitialized, it does not stop multiple parsers
   from coexisting.  */
#endif

/*  YYINITDEPTH indicates the initial size of the parser's stacks	*/

#ifndef	YYINITDEPTH
#define YYINITDEPTH 200
#endif

/*  YYMAXDEPTH is the maximum size the stacks can grow to
    (effective only if the built-in stack extension method is used).  */

#if YYMAXDEPTH == 0
#undef YYMAXDEPTH
#endif

#ifndef YYMAXDEPTH
#define YYMAXDEPTH 10000
#endif

/* Prevent warning if -Wstrict-prototypes.  */
#ifdef __GNUC__
int yyparse (void);
#endif

#if __GNUC__ > 1		/* GNU C and GNU C++ define this.  */
#define __yy_bcopy(FROM,TO,COUNT)	__builtin_memcpy(TO,FROM,COUNT)
#else				/* not GNU C or C++ */
#ifndef __cplusplus

/* This is the most reliable way to avoid incompatibilities
   in available built-in functions on various systems.  */
static void
__yy_bcopy (from, to, count)
     char *from;
     char *to;
     int count;
{
  register char *f = from;
  register char *t = to;
  register int i = count;

  while (i-- > 0)
    *t++ = *f++;
}

#else /* __cplusplus */

/* This is the most reliable way to avoid incompatibilities
   in available built-in functions on various systems.  */
static void
__yy_bcopy (char *from, char *to, int count)
{
  register char *f = from;
  register char *t = to;
  register int i = count;

  while (i-- > 0)
    *t++ = *f++;
}

#endif
#endif

#line 184 "/usr/local/lib/bison.simple"
int
yyparse()
{
  register int yystate;
  register int yyn;
  register short *yyssp;
  register YYSTYPE *yyvsp;
  int yyerrstatus;	/*  number of tokens to shift before error messages enabled */
  int yychar1 = 0;		/*  lookahead token as an internal (translated) token number */

  short	yyssa[YYINITDEPTH];	/*  the state stack			*/
  YYSTYPE yyvsa[YYINITDEPTH];	/*  the semantic value stack		*/

  short *yyss = yyssa;		/*  refer to the stacks thru separate pointers */
  YYSTYPE *yyvs = yyvsa;	/*  to allow yyoverflow to reallocate them elsewhere */

#ifdef YYLSP_NEEDED
  YYLTYPE yylsa[YYINITDEPTH];	/*  the location stack			*/
  YYLTYPE *yyls = yylsa;
  YYLTYPE *yylsp;

#define YYPOPSTACK   (yyvsp--, yyssp--, yylsp--)
#else
#define YYPOPSTACK   (yyvsp--, yyssp--)
#endif

  int yystacksize = YYINITDEPTH;

#ifdef YYPURE
  int yychar;
  YYSTYPE yylval;
  int yynerrs;
#ifdef YYLSP_NEEDED
  YYLTYPE yylloc;
#endif
#endif

  YYSTYPE yyval;		/*  the variable used to return		*/
				/*  semantic values from the action	*/
				/*  routines				*/

  int yylen;

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Starting parse\n");
#endif

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY;		/* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.
     The wasted elements are never initialized.  */

  yyssp = yyss - 1;
  yyvsp = yyvs;
#ifdef YYLSP_NEEDED
  yylsp = yyls;
#endif

/* Push a new state, which is found in  yystate  .  */
/* In all cases, when you get here, the value and location stacks
   have just been pushed. so pushing a state here evens the stacks.  */
yynewstate:

  *++yyssp = yystate;

  if (yyssp >= yyss + yystacksize - 1)
    {
      /* Give user a chance to reallocate the stack */
      /* Use copies of these so that the &'s don't force the real ones into memory. */
      YYSTYPE *yyvs1 = yyvs;
      short *yyss1 = yyss;
#ifdef YYLSP_NEEDED
      YYLTYPE *yyls1 = yyls;
#endif

      /* Get the current used size of the three stacks, in elements.  */
      int size = yyssp - yyss + 1;

#ifdef yyoverflow
      /* Each stack pointer address is followed by the size of
	 the data in use in that stack, in bytes.  */
#ifdef YYLSP_NEEDED
      /* This used to be a conditional around just the two extra args,
	 but that might be undefined if yyoverflow is a macro.  */
      yyoverflow("parser stack overflow",
		 &yyss1, size * sizeof (*yyssp),
		 &yyvs1, size * sizeof (*yyvsp),
		 &yyls1, size * sizeof (*yylsp),
		 &yystacksize);
#else
      yyoverflow("parser stack overflow",
		 &yyss1, size * sizeof (*yyssp),
		 &yyvs1, size * sizeof (*yyvsp),
		 &yystacksize);
#endif

      yyss = yyss1; yyvs = yyvs1;
#ifdef YYLSP_NEEDED
      yyls = yyls1;
#endif
#else /* no yyoverflow */
      /* Extend the stack our own way.  */
      if (yystacksize >= YYMAXDEPTH)
	{
	  yyerror("parser stack overflow");
	  return 2;
	}
      yystacksize *= 2;
      if (yystacksize > YYMAXDEPTH)
	yystacksize = YYMAXDEPTH;
      yyss = (short *) alloca (yystacksize * sizeof (*yyssp));
      __yy_bcopy ((char *)yyss1, (char *)yyss, size * sizeof (*yyssp));
      yyvs = (YYSTYPE *) alloca (yystacksize * sizeof (*yyvsp));
      __yy_bcopy ((char *)yyvs1, (char *)yyvs, size * sizeof (*yyvsp));
#ifdef YYLSP_NEEDED
      yyls = (YYLTYPE *) alloca (yystacksize * sizeof (*yylsp));
      __yy_bcopy ((char *)yyls1, (char *)yyls, size * sizeof (*yylsp));
#endif
#endif /* no yyoverflow */

      yyssp = yyss + size - 1;
      yyvsp = yyvs + size - 1;
#ifdef YYLSP_NEEDED
      yylsp = yyls + size - 1;
#endif

#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Stack size increased to %d\n", yystacksize);
#endif

      if (yyssp >= yyss + yystacksize - 1)
	YYABORT;
    }

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Entering state %d\n", yystate);
#endif

  goto yybackup;
 yybackup:

/* Do appropriate processing given the current state.  */
/* Read a lookahead token if we need one and don't already have one.  */
/* yyresume: */

  /* First try to decide what to do without reference to lookahead token.  */

  yyn = yypact[yystate];
  if (yyn == YYFLAG)
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* yychar is either YYEMPTY or YYEOF
     or a valid token in external form.  */

  if (yychar == YYEMPTY)
    {
#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Reading a token: ");
#endif
      yychar = YYLEX;
    }

  /* Convert token to internal form (in yychar1) for indexing tables with */

  if (yychar <= 0)		/* This means end of input. */
    {
      yychar1 = 0;
      yychar = YYEOF;		/* Don't call YYLEX any more */

#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Now at end of input.\n");
#endif
    }
  else
    {
      yychar1 = YYTRANSLATE(yychar);

#if YYDEBUG != 0
      if (yydebug)
	{
	  fprintf (stderr, "Next token is %d (%s", yychar, yytname[yychar1]);
	  /* Give the individual parser a way to print the precise meaning
	     of a token, for further debugging info.  */
#ifdef YYPRINT
	  YYPRINT (stderr, yychar, yylval);
#endif
	  fprintf (stderr, ")\n");
	}
#endif
    }

  yyn += yychar1;
  if (yyn < 0 || yyn > YYLAST || yycheck[yyn] != yychar1)
    goto yydefault;

  yyn = yytable[yyn];

  /* yyn is what to do for this token type in this state.
     Negative => reduce, -yyn is rule number.
     Positive => shift, yyn is new state.
       New state is final state => don't bother to shift,
       just return success.
     0, or most negative number => error.  */

  if (yyn < 0)
    {
      if (yyn == YYFLAG)
	goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }
  else if (yyn == 0)
    goto yyerrlab;

  if (yyn == YYFINAL)
    YYACCEPT;

  /* Shift the lookahead token.  */

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Shifting token %d (%s), ", yychar, yytname[yychar1]);
#endif

  /* Discard the token being shifted unless it is eof.  */
  if (yychar != YYEOF)
    yychar = YYEMPTY;

  *++yyvsp = yylval;
#ifdef YYLSP_NEEDED
  *++yylsp = yylloc;
#endif

  /* count tokens shifted since error; after three, turn off error status.  */
  if (yyerrstatus) yyerrstatus--;

  yystate = yyn;
  goto yynewstate;

/* Do the default action for the current state.  */
yydefault:

  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;

/* Do a reduction.  yyn is the number of a rule to reduce with.  */
yyreduce:
  yylen = yyr2[yyn];
  if (yylen > 0)
    yyval = yyvsp[1-yylen]; /* implement default value of the action */

#if YYDEBUG != 0
  if (yydebug)
    {
      int i;

      fprintf (stderr, "Reducing via rule %d (line %d), ",
	       yyn, yyrline[yyn]);

      /* Print the symbols being reduced, and their result.  */
      for (i = yyprhs[yyn]; yyrhs[i] > 0; i++)
	fprintf (stderr, "%s ", yytname[yyrhs[i]]);
      fprintf (stderr, " -> %s\n", yytname[yyr1[yyn]]);
    }
#endif


  switch (yyn) {

case 2:
#line 122 "ftpcmd.y"
{
			fromname = 0;
			restart_point = 0;
		;
    break;}
case 4:
#line 130 "ftpcmd.y"
{
			user(yyvsp[-1].String);
			if (cmdlogging) syslog(LOG_INFO, "USER %s", yyvsp[-1].String);
			free(yyvsp[-1].String);
		;
    break;}
case 5:
#line 136 "ftpcmd.y"
{
			if (cmdlogging)
				if (anonymous)
					syslog(LOG_INFO, "PASS %s", yyvsp[-1].String);
				else
					syslog(LOG_INFO, "PASS password");

			pass(yyvsp[-1].String);
			free(yyvsp[-1].String);
		;
    break;}
case 6:
#line 147 "ftpcmd.y"
{
			if (cmdlogging) syslog(LOG_INFO, "PORT");
			usedefault = 0;
			if (pdata >= 0) {
				(void) close(pdata);
				pdata = -1;
			}
			reply(200, "PORT command successful.");
		;
    break;}
case 7:
#line 157 "ftpcmd.y"
{
			if (cmdlogging) syslog(LOG_INFO, "PASV");
			passive();
		;
    break;}
case 8:
#line 162 "ftpcmd.y"
{
			if (cmdlogging) syslog(LOG_INFO, "TYPE %s", typenames[cmd_type]);
			switch (cmd_type) {

			case TYPE_A:
				if (cmd_form == FORM_N) {
					reply(200, "Type set to A.");
					type = cmd_type;
					form = cmd_form;
				} else
					reply(504, "Form must be N.");
				break;

			case TYPE_E:
				reply(504, "Type E not implemented.");
				break;

			case TYPE_I:
				reply(200, "Type set to I.");
				type = cmd_type;
				break;

			case TYPE_L:
#if NBBY == 8
				if (cmd_bytesz == 8) {
					reply(200,
					    "Type set to L (byte size 8).");
					type = cmd_type;
				} else
					reply(504, "Byte size must be 8.");
#else /* NBBY == 8 */
				UNIMPLEMENTED for NBBY != 8
#endif /* NBBY == 8 */
			}
		;
    break;}
case 9:
#line 198 "ftpcmd.y"
{
			if (cmdlogging) syslog(LOG_INFO, "STRU %s", strunames[yyvsp[-1].Number]);
			switch (yyvsp[-1].Number) {

			case STRU_F:
				reply(200, "STRU F ok.");
				break;

			default:
				reply(504, "Unimplemented STRU type.");
			}
		;
    break;}
case 10:
#line 211 "ftpcmd.y"
{
			if (cmdlogging) syslog(LOG_INFO, "MODE %s", modenames[yyvsp[-1].Number]);
			switch (yyvsp[-1].Number) {

			case MODE_S:
				reply(200, "MODE S ok.");
				break;

			default:
				reply(502, "Unimplemented MODE type.");
			}
		;
    break;}
case 11:
#line 224 "ftpcmd.y"
{
			if (cmdlogging) syslog(LOG_INFO, "ALLO %d", yyvsp[-1].Number);
			reply(202, "ALLO command ignored.");
		;
    break;}
case 12:
#line 229 "ftpcmd.y"
{
			if (cmdlogging) syslog(LOG_INFO, "ALLO %d R %d", yyvsp[-5].Number, yyvsp[-1].Number);
			reply(202, "ALLO command ignored.");
		;
    break;}
case 13:
#line 234 "ftpcmd.y"
{
			if (cmdlogging) syslog(LOG_INFO, "RETR %s", yyvsp[-1].String);
			if (yyvsp[-3].Number && yyvsp[-1].String != NULL)
				retrieve((char *) NULL, yyvsp[-1].String);
			if (yyvsp[-1].String != NULL)
				free(yyvsp[-1].String);
		;
    break;}
case 14:
#line 242 "ftpcmd.y"
{
			if (cmdlogging) syslog(LOG_INFO, "STOR %s", yyvsp[-1].String);
			if (yyvsp[-3].Number && yyvsp[-1].String != NULL)
				store(yyvsp[-1].String, "w", 0);
			if (yyvsp[-1].String != NULL)
				free(yyvsp[-1].String);
		;
    break;}
case 15:
#line 250 "ftpcmd.y"
{
			if (cmdlogging) syslog(LOG_INFO, "APPE %s", yyvsp[-1].String);
			if (yyvsp[-3].Number && yyvsp[-1].String != NULL)
				store(yyvsp[-1].String, "a", 0);
			if (yyvsp[-1].String != NULL)
				free(yyvsp[-1].String);
		;
    break;}
case 16:
#line 258 "ftpcmd.y"
{
			if (cmdlogging) syslog(LOG_INFO, "NLST");
			if (yyvsp[-1].Number)
				send_file_list(".");
		;
    break;}
case 17:
#line 264 "ftpcmd.y"
{
			if (cmdlogging) syslog(LOG_INFO, "NLST %s", yyvsp[-1].String);
			if (yyvsp[-3].Number && yyvsp[-1].String) {
				send_file_list(yyvsp[-1].String);
				free(yyvsp[-1].String);
			}
		;
    break;}
case 18:
#line 272 "ftpcmd.y"
{
			if (cmdlogging) syslog(LOG_INFO, "LIST");
			if (yyvsp[-1].Number)
				retrieve("/bin/ls -lgA", "");
		;
    break;}
case 19:
#line 278 "ftpcmd.y"
{
			if (cmdlogging) syslog(LOG_INFO, "LIST %s", yyvsp[-1].String);
			if (yyvsp[-3].Number && yyvsp[-1].String != NULL)
				retrieve("/bin/ls -lgA %s", yyvsp[-1].String);
			if (yyvsp[-1].String != NULL)
				free(yyvsp[-1].String);
		;
    break;}
case 20:
#line 286 "ftpcmd.y"
{
			if (cmdlogging) syslog(LOG_INFO, "STAT %s", yyvsp[-1].String);
			if (yyvsp[-3].Number && yyvsp[-1].String != NULL)
				statfilecmd(yyvsp[-1].String);
			if (yyvsp[-1].String != NULL)
				free(yyvsp[-1].String);
		;
    break;}
case 21:
#line 294 "ftpcmd.y"
{
			if (cmdlogging) syslog(LOG_INFO, "STAT");
			statcmd();
		;
    break;}
case 22:
#line 299 "ftpcmd.y"
{
			if (cmdlogging) syslog(LOG_INFO, "DELE %s", yyvsp[-1].String);
			if (yyvsp[-3].Number && yyvsp[-1].String != NULL)
				delete(yyvsp[-1].String);
			if (yyvsp[-1].String != NULL)
				free(yyvsp[-1].String);
		;
    break;}
case 23:
#line 307 "ftpcmd.y"
{
			if (cmdlogging) syslog(LOG_INFO, "RNTO %s", yyvsp[-1].String);
			if (fromname) {
				renamecmd(fromname, yyvsp[-1].String);
				free(fromname);
				fromname = (char *) NULL;
			} else {
				reply(503, "Bad sequence of commands.");
			}
			free(yyvsp[-1].String);
		;
    break;}
case 24:
#line 319 "ftpcmd.y"
{
			if (cmdlogging) syslog(LOG_INFO, "ABOR");
			reply(225, "ABOR command successful.");
		;
    break;}
case 25:
#line 324 "ftpcmd.y"
{
			if (cmdlogging) syslog(LOG_INFO, "CWD");
			if (yyvsp[-1].Number)
				cwd(pw->pw_dir);
		;
    break;}
case 26:
#line 330 "ftpcmd.y"
{
			if (cmdlogging) syslog(LOG_INFO, "CWD %s", yyvsp[-1].String);
			if (yyvsp[-3].Number && yyvsp[-1].String != NULL)
				cwd(yyvsp[-1].String);
			if (yyvsp[-1].String != NULL)
				free(yyvsp[-1].String);
		;
    break;}
case 27:
#line 338 "ftpcmd.y"
{
			if (cmdlogging) syslog(LOG_INFO, "HELP");
			help(cmdtab, (char *) NULL);
		;
    break;}
case 28:
#line 343 "ftpcmd.y"
{
			register char *cp = (char *)yyvsp[-1].String;

			if (cmdlogging) syslog(LOG_INFO, "HELP %s", yyvsp[-1].String);
			if (strncasecmp(cp, "SITE", 4) == 0) {
				cp = (char *)yyvsp[-1].String + 4;
				if (*cp == ' ')
					cp++;
				if (*cp)
					help(sitetab, cp);
				else
					help(sitetab, (char *) NULL);
			} else
				help(cmdtab, yyvsp[-1].String);
		;
    break;}
case 29:
#line 359 "ftpcmd.y"
{
			if (cmdlogging) syslog(LOG_INFO, "NOOP");
			reply(200, "NOOP command successful.");
		;
    break;}
case 30:
#line 364 "ftpcmd.y"
{
			if (cmdlogging) syslog(LOG_INFO, "MKD %s", yyvsp[-1].String);
			if (yyvsp[-3].Number && yyvsp[-1].String != NULL)
				makedir(yyvsp[-1].String);
			if (yyvsp[-1].String != NULL)
				free(yyvsp[-1].String);
		;
    break;}
case 31:
#line 372 "ftpcmd.y"
{
			if (cmdlogging) syslog(LOG_INFO, "RMD %s", yyvsp[-1].String);
			if (yyvsp[-3].Number && yyvsp[-1].String != NULL)
				removedir(yyvsp[-1].String);
			if (yyvsp[-1].String != NULL)
				free(yyvsp[-1].String);
		;
    break;}
case 32:
#line 380 "ftpcmd.y"
{
			if (cmdlogging) syslog(LOG_INFO, "PWD");
			if (yyvsp[-1].Number)
				pwd();
		;
    break;}
case 33:
#line 386 "ftpcmd.y"
{
			if (cmdlogging) syslog(LOG_INFO, "CDUP");
			if (yyvsp[-1].Number)
				cwd("..");
		;
    break;}
case 34:
#line 392 "ftpcmd.y"
{
			if (cmdlogging) syslog(LOG_INFO, "SITE HELP");
			help(sitetab, (char *) NULL);
		;
    break;}
case 35:
#line 397 "ftpcmd.y"
{
			if (cmdlogging) syslog(LOG_INFO, "SITE HELP %s", yyvsp[-1].String);
			help(sitetab, yyvsp[-1].String);
		;
    break;}
case 36:
#line 402 "ftpcmd.y"
{
			int oldmask;

			if (cmdlogging) syslog(LOG_INFO, "SITE UMASK");
			if (yyvsp[-1].Number) {
				oldmask = umask(0);
				(void) umask(oldmask);
				reply(200, "Current UMASK is %03o", oldmask);
			}
		;
    break;}
case 37:
#line 413 "ftpcmd.y"
{
			int oldmask;

			if (cmdlogging) syslog(LOG_INFO, "SITE UMASK %d", yyvsp[-1].Number);
			if (yyvsp[-3].Number) {
				if ((yyvsp[-1].Number == -1) || (yyvsp[-1].Number > 0777)) {
					reply(501, "Bad UMASK value");
				} else {
					oldmask = umask(yyvsp[-1].Number);
					reply(200,
					    "UMASK set to %03o (was %03o)",
					    yyvsp[-1].Number, oldmask);
				}
			}
		;
    break;}
case 38:
#line 429 "ftpcmd.y"
{
			if (cmdlogging) syslog(LOG_INFO, "SITE CHMOD %s %s", yyvsp[-3].Number, yyvsp[-1].String);
			if (yyvsp[-5].Number && yyvsp[-3].Number && yyvsp[-1].String) {
				if (yyvsp[-3].Number > 0777)
					reply(501,
				"CHMOD: Mode value must be between 0 and 0777");
				else if (chmod(yyvsp[-1].String, yyvsp[-3].Number) < 0)
					perror_reply(550, yyvsp[-1].String);
				else
					reply(200, "CHMOD command successful.");
				free(yyvsp[-1].String);
			}
		;
    break;}
case 39:
#line 443 "ftpcmd.y"
{
			if (cmdlogging) syslog(LOG_INFO, "SITE IDLE");
			reply(200,
			    "Current IDLE time limit is %d seconds; max %d",
				timeout, maxtimeout);
		;
    break;}
case 40:
#line 450 "ftpcmd.y"
{
			if (cmdlogging) syslog(LOG_INFO, "SITE IDLE %d", yyvsp[-1].Number);
			if (yyvsp[-1].Number < 30 || yyvsp[-1].Number > maxtimeout) {
				reply(501,
			"Maximum IDLE time must be between 30 and %d seconds",
				    maxtimeout);
			} else {
				timeout = yyvsp[-1].Number;
				(void) alarm((unsigned) timeout);
				reply(200, "Maximum IDLE time set to %d seconds", timeout);
			}
		;
    break;}
case 41:
#line 463 "ftpcmd.y"
{
			if (cmdlogging) syslog(LOG_INFO, "SITE GROUP %s", yyvsp[-1].String);
			if (yyvsp[-3].Number && yyvsp[-1].String) priv_group(yyvsp[-1].String);
			free(yyvsp[-1].String);
		;
    break;}
case 42:
#line 469 "ftpcmd.y"
{
			if (cmdlogging) syslog(LOG_INFO, "SITE GPASS password");
			if (yyvsp[-3].Number && yyvsp[-1].String) priv_gpass(yyvsp[-1].String);
			free(yyvsp[-1].String);
		;
    break;}
case 43:
#line 475 "ftpcmd.y"
{
			if (yyvsp[-3].Number && yyvsp[-1].String) newer(yyvsp[-1].String, ".", 0);
			free(yyvsp[-1].String);
		;
    break;}
case 44:
#line 480 "ftpcmd.y"
{
			if (yyvsp[-5].Number && yyvsp[-3].String && yyvsp[-1].String) newer(yyvsp[-3].String, yyvsp[-1].String, 0);
			free(yyvsp[-3].String);
			free(yyvsp[-1].String);
		;
    break;}
case 45:
#line 486 "ftpcmd.y"
{
			if (yyvsp[-5].Number && yyvsp[-3].String && yyvsp[-1].String) newer(yyvsp[-3].String, yyvsp[-1].String, 1);
			free(yyvsp[-3].String);
			free(yyvsp[-1].String);
		;
    break;}
case 46:
#line 492 "ftpcmd.y"
{
			if (cmdlogging) syslog(LOG_INFO, "STOU %s", yyvsp[-1].String);
			if (yyvsp[-3].Number && yyvsp[-1].String) {
				store(yyvsp[-1].String, "w", 1);
				free(yyvsp[-1].String);
			}
		;
    break;}
case 47:
#line 500 "ftpcmd.y"
{
			if (cmdlogging) syslog(LOG_INFO, "SYST");
#ifdef unix
#ifdef BSD
			reply(215, "UNIX Type: L%d Version: BSD-%d",
				NBBY, BSD);
#else /* BSD */
			reply(215, "UNIX Type: L%d", NBBY);
#endif /* BSD */
#else /* unix */
			reply(215, "UNKNOWN Type: L%d", NBBY);
#endif /* unix */
		;
    break;}
case 48:
#line 522 "ftpcmd.y"
{
			if (cmdlogging) syslog(LOG_INFO, "SIZE %s", yyvsp[-1].String);
			if (yyvsp[-3].Number && yyvsp[-1].String) {
				sizecmd(yyvsp[-1].String);
				free(yyvsp[-1].String);
			}
		;
    break;}
case 49:
#line 540 "ftpcmd.y"
{
			if (cmdlogging) syslog(LOG_INFO, "MDTM %s", yyvsp[-1].String);
			if (yyvsp[-3].Number && yyvsp[-1].String) {
				struct stat stbuf;

				if (stat(yyvsp[-1].String, &stbuf) < 0)
					perror_reply(550, yyvsp[-1].String);
				else if ((stbuf.st_mode&S_IFMT) != S_IFREG) {
					reply(550, "%s: not a plain file.",
						yyvsp[-1].String);
				} else {
					register struct tm *t;
					struct tm *gmtime();
					t = gmtime(&stbuf.st_mtime);
					reply(213,
					    "19%02d%02d%02d%02d%02d%02d",
					    t->tm_year, t->tm_mon+1, t->tm_mday,
					    t->tm_hour, t->tm_min, t->tm_sec);
				}
				free(yyvsp[-1].String);
			}
		;
    break;}
case 50:
#line 563 "ftpcmd.y"
{
			if (cmdlogging) syslog(LOG_INFO, "QUIT");
			reply(221, "Goodbye.");
			dologout(0);
		;
    break;}
case 51:
#line 569 "ftpcmd.y"
{
			yyerrok;
		;
    break;}
case 52:
#line 574 "ftpcmd.y"
{
			char *renamefrom();

			if (cmdlogging) syslog(LOG_INFO, "RNFR %s", yyvsp[-1].String);
			restart_point = (off_t) 0;
			if (yyvsp[-3].Number && yyvsp[-1].String) {
				fromname = renamefrom(yyvsp[-1].String);
				if (fromname == 0 && yyvsp[-1].String) {
					free(yyvsp[-1].String);
				}
			}
		;
    break;}
case 53:
#line 587 "ftpcmd.y"
{
			long atol();

			fromname = 0;
			restart_point = yyvsp[-1].Number;
			if (cmdlogging) syslog(LOG_INFO, "REST %d", restart_point);
			reply(350, "Restarting at %ld. %s", restart_point,
			    "Send STORE or RETRIEVE to initiate transfer.");
		;
    break;}
case 55:
#line 602 "ftpcmd.y"
{
			yyval.String = malloc(1);
			yyval.String[0] = '\0';
		;
    break;}
case 58:
#line 614 "ftpcmd.y"
{
			register char *a, *p;

			a = (char *)&data_dest.sin_addr;
			a[0] = yyvsp[-10].Number; a[1] = yyvsp[-8].Number; a[2] = yyvsp[-6].Number; a[3] = yyvsp[-4].Number;
			p = (char *)&data_dest.sin_port;
			p[0] = yyvsp[-2].Number; p[1] = yyvsp[0].Number;
			data_dest.sin_family = AF_INET;
		;
    break;}
case 59:
#line 626 "ftpcmd.y"
{
		yyval.Number = FORM_N;
	;
    break;}
case 60:
#line 630 "ftpcmd.y"
{
		yyval.Number = FORM_T;
	;
    break;}
case 61:
#line 634 "ftpcmd.y"
{
		yyval.Number = FORM_C;
	;
    break;}
case 62:
#line 640 "ftpcmd.y"
{
		cmd_type = TYPE_A;
		cmd_form = FORM_N;
	;
    break;}
case 63:
#line 645 "ftpcmd.y"
{
		cmd_type = TYPE_A;
		cmd_form = yyvsp[0].Number;
	;
    break;}
case 64:
#line 650 "ftpcmd.y"
{
		cmd_type = TYPE_E;
		cmd_form = FORM_N;
	;
    break;}
case 65:
#line 655 "ftpcmd.y"
{
		cmd_type = TYPE_E;
		cmd_form = yyvsp[0].Number;
	;
    break;}
case 66:
#line 660 "ftpcmd.y"
{
		cmd_type = TYPE_I;
	;
    break;}
case 67:
#line 664 "ftpcmd.y"
{
		cmd_type = TYPE_L;
		cmd_bytesz = NBBY;
	;
    break;}
case 68:
#line 669 "ftpcmd.y"
{
		cmd_type = TYPE_L;
		cmd_bytesz = yyvsp[0].Number;
	;
    break;}
case 69:
#line 675 "ftpcmd.y"
{
		cmd_type = TYPE_L;
		cmd_bytesz = yyvsp[0].Number;
	;
    break;}
case 70:
#line 682 "ftpcmd.y"
{
		yyval.Number = STRU_F;
	;
    break;}
case 71:
#line 686 "ftpcmd.y"
{
		yyval.Number = STRU_R;
	;
    break;}
case 72:
#line 690 "ftpcmd.y"
{
		yyval.Number = STRU_P;
	;
    break;}
case 73:
#line 696 "ftpcmd.y"
{
		yyval.Number = MODE_S;
	;
    break;}
case 74:
#line 700 "ftpcmd.y"
{
		yyval.Number = MODE_B;
	;
    break;}
case 75:
#line 704 "ftpcmd.y"
{
		yyval.Number = MODE_C;
	;
    break;}
case 76:
#line 710 "ftpcmd.y"
{
		/*
		 * Problem: this production is used for all pathname
		 * processing, but only gives a 550 error reply.
		 * This is a valid reply in some cases but not in others.
		 */
		if (logged_in && yyvsp[0].String && strncmp(yyvsp[0].String, "~", 1) == 0) {
			yyval.String = *glob(yyvsp[0].String);
			if (globerr) {
				reply(550, globerr);
				yyval.String = NULL;
			}
			free(yyvsp[0].String);
		} else
			yyval.String = yyvsp[0].String;
	;
    break;}
case 78:
#line 732 "ftpcmd.y"
{
		register int ret, dec, multby, digit;

		/*
		 * Convert a number that was read as decimal number
		 * to what it would be if it had been read as octal.
		 */
		dec = yyvsp[0].Number;
		multby = 1;
		ret = 0;
		while (dec) {
			digit = dec%10;
			if (digit > 7) {
				ret = -1;
				break;
			}
			ret += digit * multby;
			multby *= 8;
			dec /= 10;
		}
		yyval.Number = ret;
	;
    break;}
case 79:
#line 757 "ftpcmd.y"
{
		if (logged_in)
			yyval.Number = 1;
		else {
			if (cmdlogging) syslog(LOG_INFO, "cmd failure - not logged in");
			reply(530, "Please login with USER and PASS.");
			yyval.Number = 0;
		}
	;
    break;}
}
   /* the action file gets copied in in place of this dollarsign */
#line 465 "/usr/local/lib/bison.simple"

  yyvsp -= yylen;
  yyssp -= yylen;
#ifdef YYLSP_NEEDED
  yylsp -= yylen;
#endif

#if YYDEBUG != 0
  if (yydebug)
    {
      short *ssp1 = yyss - 1;
      fprintf (stderr, "state stack now");
      while (ssp1 != yyssp)
	fprintf (stderr, " %d", *++ssp1);
      fprintf (stderr, "\n");
    }
#endif

  *++yyvsp = yyval;

#ifdef YYLSP_NEEDED
  yylsp++;
  if (yylen == 0)
    {
      yylsp->first_line = yylloc.first_line;
      yylsp->first_column = yylloc.first_column;
      yylsp->last_line = (yylsp-1)->last_line;
      yylsp->last_column = (yylsp-1)->last_column;
      yylsp->text = 0;
    }
  else
    {
      yylsp->last_line = (yylsp+yylen-1)->last_line;
      yylsp->last_column = (yylsp+yylen-1)->last_column;
    }
#endif

  /* Now "shift" the result of the reduction.
     Determine what state that goes to,
     based on the state we popped back to
     and the rule number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTBASE] + *yyssp;
  if (yystate >= 0 && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTBASE];

  goto yynewstate;

yyerrlab:   /* here on detecting error */

  if (! yyerrstatus)
    /* If not already recovering from an error, report this error.  */
    {
      ++yynerrs;

#ifdef YYERROR_VERBOSE
      yyn = yypact[yystate];

      if (yyn > YYFLAG && yyn < YYLAST)
	{
	  int size = 0;
	  char *msg;
	  int x, count;

	  count = 0;
	  /* Start X at -yyn if nec to avoid negative indexes in yycheck.  */
	  for (x = (yyn < 0 ? -yyn : 0);
	       x < (sizeof(yytname) / sizeof(char *)); x++)
	    if (yycheck[x + yyn] == x)
	      size += strlen(yytname[x]) + 15, count++;
	  msg = (char *) malloc(size + 15);
	  if (msg != 0)
	    {
	      strcpy(msg, "parse error");

	      if (count < 5)
		{
		  count = 0;
		  for (x = (yyn < 0 ? -yyn : 0);
		       x < (sizeof(yytname) / sizeof(char *)); x++)
		    if (yycheck[x + yyn] == x)
		      {
			strcat(msg, count == 0 ? ", expecting `" : " or `");
			strcat(msg, yytname[x]);
			strcat(msg, "'");
			count++;
		      }
		}
	      yyerror(msg);
	      free(msg);
	    }
	  else
	    yyerror ("parse error; also virtual memory exceeded");
	}
      else
#endif /* YYERROR_VERBOSE */
	yyerror("parse error");
    }

  goto yyerrlab1;
yyerrlab1:   /* here on error raised explicitly by an action */

  if (yyerrstatus == 3)
    {
      /* if just tried and failed to reuse lookahead token after an error, discard it.  */

      /* return failure if at end of input */
      if (yychar == YYEOF)
	YYABORT;

#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Discarding token %d (%s).\n", yychar, yytname[yychar1]);
#endif

      yychar = YYEMPTY;
    }

  /* Else will try to reuse lookahead token
     after shifting the error token.  */

  yyerrstatus = 3;		/* Each real token shifted decrements this */

  goto yyerrhandle;

yyerrdefault:  /* current state does not do anything special for the error token. */

#if 0
  /* This is wrong; only states that explicitly want error tokens
     should shift them.  */
  yyn = yydefact[yystate];  /* If its default is to accept any token, ok.  Otherwise pop it.*/
  if (yyn) goto yydefault;
#endif

yyerrpop:   /* pop the current state because it cannot handle the error token */

  if (yyssp == yyss) YYABORT;
  yyvsp--;
  yystate = *--yyssp;
#ifdef YYLSP_NEEDED
  yylsp--;
#endif

#if YYDEBUG != 0
  if (yydebug)
    {
      short *ssp1 = yyss - 1;
      fprintf (stderr, "Error: state stack now");
      while (ssp1 != yyssp)
	fprintf (stderr, " %d", *++ssp1);
      fprintf (stderr, "\n");
    }
#endif

yyerrhandle:

  yyn = yypact[yystate];
  if (yyn == YYFLAG)
    goto yyerrdefault;

  yyn += YYTERROR;
  if (yyn < 0 || yyn > YYLAST || yycheck[yyn] != YYTERROR)
    goto yyerrdefault;

  yyn = yytable[yyn];
  if (yyn < 0)
    {
      if (yyn == YYFLAG)
	goto yyerrpop;
      yyn = -yyn;
      goto yyreduce;
    }
  else if (yyn == 0)
    goto yyerrpop;

  if (yyn == YYFINAL)
    YYACCEPT;

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Shifting error token, ");
#endif

  *++yyvsp = yylval;
#ifdef YYLSP_NEEDED
  *++yylsp = yylloc;
#endif

  yystate = yyn;
  goto yynewstate;
}
#line 768 "ftpcmd.y"


extern jmp_buf errcatch;

#define	CMD	0	/* beginning of command */
#define	ARGS	1	/* expect miscellaneous arguments */
#define	STR1	2	/* expect SP followed by STRING */
#define	STR2	3	/* expect STRING */
#define	OSTR	4	/* optional SP then STRING */
#define	ZSTR1	5	/* SP then optional STRING */
#define	ZSTR2	6	/* optional STRING after SP */
#define	SITECMD	7	/* SITE command */
#define	NSTR	8	/* Number followed by a string */
#define	STR3	9	/* expect STRING followed by optional SP then STRING */

struct tab {
	char	*name;
	short	token;
	short	state;
 	short	implemented;	/* 1 if command is implemented */
	char	*help;
};

struct tab cmdtab[] = {		/* In order defined in RFC 765 */
	{ "USER", USER, STR1, 1,	"<sp> username" },
	{ "PASS", PASS, ZSTR1, 1,	"<sp> password" },
	{ "ACCT", ACCT, STR1, 0,	"(specify account)" },
	{ "SMNT", SMNT, ARGS, 0,	"(structure mount)" },
	{ "REIN", REIN, ARGS, 0,	"(reinitialize server state)" },
	{ "QUIT", QUIT, ARGS, 1,	"(terminate service)", },
	{ "PORT", PORT, ARGS, 1,	"<sp> b0, b1, b2, b3, b4" },
	{ "PASV", PASV, ARGS, 1,	"(set server in passive mode)" },
	{ "TYPE", TYPE, ARGS, 1,	"<sp> [ A | E | I | L ]" },
	{ "STRU", STRU, ARGS, 1,	"(specify file structure)" },
	{ "MODE", MODE, ARGS, 1,	"(specify transfer mode)" },
	{ "RETR", RETR, STR1, 1,	"<sp> file-name" },
	{ "STOR", STOR, STR1, 1,	"<sp> file-name" },
	{ "APPE", APPE, STR1, 1,	"<sp> file-name" },
	{ "MLFL", MLFL, OSTR, 0,	"(mail file)" },
	{ "MAIL", MAIL, OSTR, 0,	"(mail to user)" },
	{ "MSND", MSND, OSTR, 0,	"(mail send to terminal)" },
	{ "MSOM", MSOM, OSTR, 0,	"(mail send to terminal or mailbox)" },
	{ "MSAM", MSAM, OSTR, 0,	"(mail send to terminal and mailbox)" },
	{ "MRSQ", MRSQ, OSTR, 0,	"(mail recipient scheme question)" },
	{ "MRCP", MRCP, STR1, 0,	"(mail recipient)" },
	{ "ALLO", ALLO, ARGS, 1,	"allocate storage (vacuously)" },
	{ "REST", REST, ARGS, 1,	"(restart command)" },
	{ "RNFR", RNFR, STR1, 1,	"<sp> file-name" },
	{ "RNTO", RNTO, STR1, 1,	"<sp> file-name" },
	{ "ABOR", ABOR, ARGS, 1,	"(abort operation)" },
	{ "DELE", DELE, STR1, 1,	"<sp> file-name" },
	{ "CWD",  CWD,  OSTR, 1,	"[ <sp> directory-name ]" },
	{ "XCWD", CWD,	OSTR, 1,	"[ <sp> directory-name ]" },
	{ "LIST", LIST, OSTR, 1,	"[ <sp> path-name ]" },
	{ "NLST", NLST, OSTR, 1,	"[ <sp> path-name ]" },
	{ "SITE", SITE, SITECMD, 1,	"site-cmd [ <sp> arguments ]" },
	{ "SYST", SYST, ARGS, 1,	"(get type of operating system)" },
	{ "STAT", STAT, OSTR, 1,	"[ <sp> path-name ]" },
	{ "HELP", HELP, OSTR, 1,	"[ <sp> <string> ]" },
	{ "NOOP", NOOP, ARGS, 1,	"" },
	{ "MKD",  MKD,  STR1, 1,	"<sp> path-name" },
	{ "XMKD", MKD,  STR1, 1,	"<sp> path-name" },
	{ "RMD",  RMD,  STR1, 1,	"<sp> path-name" },
	{ "XRMD", RMD,  STR1, 1,	"<sp> path-name" },
	{ "PWD",  PWD,  ARGS, 1,	"(return current directory)" },
	{ "XPWD", PWD,  ARGS, 1,	"(return current directory)" },
	{ "CDUP", CDUP, ARGS, 1,	"(change to parent directory)" },
	{ "XCUP", CDUP, ARGS, 1,	"(change to parent directory)" },
	{ "STOU", STOU, STR1, 1,	"<sp> file-name" },
	{ "SIZE", SIZE, OSTR, 1,	"<sp> path-name" },
	{ "MDTM", MDTM, OSTR, 1,	"<sp> path-name" },
	{ NULL,   0,    0,    0,	0 }
};

struct tab sitetab[] = {
	{ "UMASK", UMASK, ARGS, 1,	"[ <sp> umask ]" },
	{ "IDLE", IDLE, ARGS, 1,	"[ <sp> maximum-idle-time ]" },
	{ "CHMOD", CHMOD, NSTR, 1,	"<sp> mode <sp> file-name" },
	{ "HELP", HELP, OSTR, 1,	"[ <sp> <string> ]" },
	{ "GROUP", GROUP, STR1, 1,	"<sp> access-group" },
	{ "GPASS", GPASS, STR1, 1,	"<sp> access-password" },
	{ "NEWER", NEWER, STR3, 1,	"<sp> YYYYMMDDHHMMSS [ <sp> path-name ]" },
	{ "MINFO", MINFO, STR3, 1,	"<sp> YYYYMMDDHHMMSS [ <sp> path-name ]" },
	{ NULL,   0,    0,    0,	0 }
};

struct tab *
lookup(p, cmd)
	register struct tab *p;
	char *cmd;
{

	for (; p->name != NULL; p++)
		if (strcmp(cmd, p->name) == 0)
			return (p);
	return (0);
}

#include <arpa/telnet.h>

/*
 * getline - a hacked up version of fgets to ignore TELNET escape codes.
 */
char *
getline(s, n, iop)
	char *s;
	register FILE *iop;
{
	register c;
	register char *cs;

	cs = s;
/* tmpline may contain saved command from urgent mode interruption */
	for (c = 0; tmpline[c] != '\0' && --n > 0; ++c) {
		*cs++ = tmpline[c];
		if (tmpline[c] == '\n') {
			*cs++ = '\0';
			if (debug)
				syslog(LOG_DEBUG, "command: %s", s);
			tmpline[0] = '\0';
			return(s);
		}
		if (c == 0)
			tmpline[0] = '\0';
	}
	while ((c = getc(iop)) != EOF) {
		c &= 0377;
		if (c == IAC) {
		    if ((c = getc(iop)) != EOF) {
			c &= 0377;
			switch (c) {
			case WILL:
			case WONT:
				c = getc(iop);
				printf("%c%c%c", IAC, DONT, 0377&c);
				(void) fflush(stdout);
				continue;
			case DO:
			case DONT:
				c = getc(iop);
				printf("%c%c%c", IAC, WONT, 0377&c);
				(void) fflush(stdout);
				continue;
			case IAC:
				break;
			default:
				continue;	/* ignore command */
			}
		    }
		}
		*cs++ = c;
		if (--n <= 0 || c == '\n')
			break;
	}
	if (c == EOF && cs == s)
		return (NULL);
	*cs++ = '\0';
	if (debug)
		syslog(LOG_DEBUG, "command: %s", s);
	return (s);
}

static int
toolong()
{
	time_t now;
	extern char *ctime();
	extern time_t time();

	reply(421,
	  "Timeout (%d seconds): closing control connection.", timeout);
	(void) time(&now);
	if (logging) {
		syslog(LOG_INFO,
			"User %s timed out after %d seconds at %.24s",
			(pw ? pw -> pw_name : "unknown"), timeout, ctime(&now));
	}
	dologout(1);
}

yylex()
{
	static int cpos, state;
	register char *cp, *cp2;
	register struct tab *p;
	int n;
	char c, *strpbrk();
	char *copy();

	for (;;) {
		switch (state) {

		case CMD:
			(void) signal(SIGALRM, toolong);
			(void) alarm((unsigned) timeout);
			if (is_shutdown(!logged_in) != 0) {
				reply(221, "Server shutting down.");
				dologout(0);
			}
			if (getline(cbuf, sizeof(cbuf)-1, stdin) == NULL) {
				reply(221, "You could at least say goodbye.");
				dologout(0);
			}
			(void) alarm(0);
#ifdef SETPROCTITLE
			if (strncasecmp(cbuf, "PASS", 4) != 0 &&
				strncasecmp(cbuf, "GPASS", 5) != 0)
				setproctitle("%s: %s", proctitle, cbuf);
#endif /* SETPROCTITLE */
			if ((cp = strchr(cbuf, '\r'))) {
				*cp++ = '\n';
				*cp = '\0';
			}
			if ((cp = strpbrk(cbuf, " \n")))
				cpos = cp - cbuf;
			if (cpos == 0)
				cpos = 4;
			c = cbuf[cpos];
			cbuf[cpos] = '\0';
			upper(cbuf);
			p = lookup(cmdtab, cbuf);
			cbuf[cpos] = c;
			if (p != 0) {
				if (p->implemented == 0) {
					nack(p->name);
					longjmp(errcatch,0);
					/* NOTREACHED */
				}
				state = p->state;
				yylval.String = p->name;
				return (p->token);
			}
			break;

		case SITECMD:
			if (cbuf[cpos] == ' ') {
				cpos++;
				return (SP);
			}
			cp = &cbuf[cpos];
			if ((cp2 = strpbrk(cp, " \n")))
				cpos = cp2 - cbuf;
			c = cbuf[cpos];
			cbuf[cpos] = '\0';
			upper(cp);
			p = lookup(sitetab, cp);
			cbuf[cpos] = c;
			if (p != 0) {
				if (p->implemented == 0) {
					state = CMD;
					nack(p->name);
					longjmp(errcatch,0);
					/* NOTREACHED */
				}
				state = p->state;
				yylval.String = p->name;
				return (p->token);
			}
			state = CMD;
			break;

		case OSTR:
			if (cbuf[cpos] == '\n') {
				state = CMD;
				return (CRLF);
			}
			/* FALLTHROUGH */

		case STR1:
		case ZSTR1:
		dostr1:
			if (cbuf[cpos] == ' ') {
				cpos++;
				state = state == OSTR ? STR2 : ++state;
				return (SP);
			}
			break;

		case ZSTR2:
			if (cbuf[cpos] == '\n') {
				state = CMD;
				return (CRLF);
			}
			/* FALLTHROUGH */

		case STR2:
			cp = &cbuf[cpos];
			n = strlen(cp);
			cpos += n - 1;
			/*
			 * Make sure the string is nonempty and \n terminated.
			 */
			if (n > 1 && cbuf[cpos] == '\n') {
				cbuf[cpos] = '\0';
				yylval.String = copy(cp);
				cbuf[cpos] = '\n';
				state = ARGS;
				return (STRING);
			}
			break;

		case NSTR:
			if (cbuf[cpos] == ' ') {
				cpos++;
				return (SP);
			}
			if (isdigit(cbuf[cpos])) {
				cp = &cbuf[cpos];
				while (isdigit(cbuf[++cpos]))
					;
				c = cbuf[cpos];
				cbuf[cpos] = '\0';
				yylval.Number = atoi(cp);
				cbuf[cpos] = c;
				state = STR1;
				return (NUMBER);
			}
			state = STR1;
			goto dostr1;

		case STR3:
			if (cbuf[cpos] == ' ') {
				cpos++;
				return (SP);
			}

			cp = &cbuf[cpos];
			cp2 = strpbrk(cp, " \n");
			if (cp2 != NULL) {
				c = *cp2;
				*cp2 = '\0';
			}
			n = strlen(cp);
			cpos += n;
			/*
			 * Make sure the string is nonempty and SP terminated.
			 */
			if ((cp2 - cp) > 1) {
				yylval.String = copy(cp);
				cbuf[cpos] = c;
				state = OSTR;
				return (STRING);
			}
			break;

		case ARGS:
			if (isdigit(cbuf[cpos])) {
				cp = &cbuf[cpos];
				while (isdigit(cbuf[++cpos]))
					;
				c = cbuf[cpos];
				cbuf[cpos] = '\0';
				yylval.Number = atoi(cp);
				cbuf[cpos] = c;
				return (NUMBER);
			}
			switch (cbuf[cpos++]) {

			case '\n':
				state = CMD;
				return (CRLF);

			case ' ':
				return (SP);

			case ',':
				return (COMMA);

			case 'A':
			case 'a':
				return (A);

			case 'B':
			case 'b':
				return (B);

			case 'C':
			case 'c':
				return (C);

			case 'E':
			case 'e':
				return (E);

			case 'F':
			case 'f':
				return (F);

			case 'I':
			case 'i':
				return (I);

			case 'L':
			case 'l':
				return (L);

			case 'N':
			case 'n':
				return (N);

			case 'P':
			case 'p':
				return (P);

			case 'R':
			case 'r':
				return (R);

			case 'S':
			case 's':
				return (S);

			case 'T':
			case 't':
				return (T);

			}
			break;

		default:
			fatal("Unknown state in scanner.");
		}
		yyerror((char *)NULL);
		state = CMD;
		longjmp(errcatch,0);
	}
}

upper(s)
	register char *s;
{
	while (*s != '\0') {
		if (islower(*s))
			*s = toupper(*s);
		s++;
	}
}

char *
copy(s)
	char *s;
{
	char *p;
/*	extern char *malloc(), *strcpy();*/

	p = malloc((unsigned) strlen(s) + 1);
	if (p == NULL)
		fatal("Ran out of memory.");
	(void) strcpy(p, s);
	return (p);
}

help(ctab, s)
	struct tab *ctab;
	char *s;
{
	register struct tab *c;
	register int width, NCMDS;
	char *type;

	if (ctab == sitetab)
		type = "SITE ";
	else
		type = "";
	width = 0, NCMDS = 0;
	for (c = ctab; c->name != NULL; c++) {
		int len = strlen(c->name);

		if (len > width)
			width = len;
		NCMDS++;
	}
	width = (width + 8) &~ 7;
	if (s == 0) {
		register int i, j, w;
		int columns, lines;

		lreply(214, "The following %scommands are recognized %s.",
		    type, "(* =>'s unimplemented)");
		columns = 76 / width;
		if (columns == 0)
			columns = 1;
		lines = (NCMDS + columns - 1) / columns;
		for (i = 0; i < lines; i++) {
			printf("   ");
			for (j = 0; j < columns; j++) {
				c = ctab + j * lines + i;
				printf("%s%c", c->name,
					c->implemented ? ' ' : '*');
				if (c + lines >= &ctab[NCMDS])
					break;
				w = strlen(c->name) + 1;
				while (w < width) {
					putchar(' ');
					w++;
				}
			}
			printf("\r\n");
		}
		(void) fflush(stdout);
		reply(214, "Direct comments to ftp-bugs@%s.", hostname);
		return;
	}
	upper(s);
	c = lookup(ctab, s);
	if (c == (struct tab *)NULL) {
		reply(502, "Unknown command %s.", s);
		return;
	}
	if (c->implemented)
		reply(214, "Syntax: %s%s %s", type, c->name, c->help);
	else
		reply(214, "%s%-*s\t%s; unimplemented.", type, width,
		    c->name, c->help);
}

sizecmd(filename)
char *filename;
{
	switch (type) {
	case TYPE_L:
	case TYPE_I: {
		struct stat stbuf;
		if (stat(filename, &stbuf) < 0 ||
		    (stbuf.st_mode&S_IFMT) != S_IFREG)
			reply(550, "%s: not a plain file.", filename);
		else
			reply(213, "%lu", stbuf.st_size);
		break;}
	case TYPE_A: {
		FILE *fin;
		register int c;
		register long count;
		struct stat stbuf;
		fin = fopen(filename, "r");
		if (fin == NULL) {
			perror_reply(550, filename);
			return;
		}
		if (fstat(fileno(fin), &stbuf) < 0 ||
		    (stbuf.st_mode&S_IFMT) != S_IFREG) {
			reply(550, "%s: not a plain file.", filename);
			(void) fclose(fin);
			return;
		}

		count = 0;
		while((c=getc(fin)) != EOF) {
			if (c == '\n')	/* will get expanded to \r\n */
				count++;
			count++;
		}
		(void) fclose(fin);

		reply(213, "%ld", count);
		break;}
	default:
		reply(504, "SIZE not implemented for Type %c.", "?AEIL"[type]);
	}
}
