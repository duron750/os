/* 
 * We have now chroot()'ed so stat()'ing / should give us the available
 * space (unless we are mounting directories under ~ftp).
 *
 */

#include <sys/types.h>
#include <sys/vfs.h>

long 
myfree()
{
	struct statfs   buf;

	statfs("/", &buf);
	return buf.f_bavail;
}
