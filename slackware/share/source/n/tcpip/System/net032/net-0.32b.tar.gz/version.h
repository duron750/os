#define RELEASE "NET-2 Base Utilities release 0.32b-2db"
