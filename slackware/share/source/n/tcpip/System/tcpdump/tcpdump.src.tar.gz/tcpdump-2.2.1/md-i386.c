
int
clock_sigfigs()
{
	return(2);
}
