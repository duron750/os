#include <stdio.h>
#include <string.h>

void net_sendline(const char *x)
{
	printf("%s",x);
}

int net_connect(const char *x)
{
	return(0);
}

void net_init()
{
	;
}

int net_getline(char *buf,int size,int tm)
{
	char *t;
	gets(buf);
	if((t=strchr(buf,'\n'))!=NULL)
		*t=0;
	return(0);
}
