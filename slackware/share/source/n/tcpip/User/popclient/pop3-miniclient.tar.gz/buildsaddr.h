/* @(#) $Header: buildsaddr.h,v 1.1 91/04/25 18:28:45 deyke Exp $ */

#ifndef _BUILDSADDR_H
#define _BUILDSADDR_H

/* In buildsaddr.c: */
struct sockaddr *build_sockaddr __ARGS((char *name, int *addrlen));

#endif  /* _BUILDSADDR_H */
