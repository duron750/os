#!/bin/sh
# @(#)samples/bsmtp/rcsmtp.sh	1.4 9/6/92 04:16:11

# Receive compressed batches of SMTP commands and send them
# to smail.

# the following line should be changed to reflect the
# organization of your system.
/usr/local/bin/compress -d | /bin/rsmtp -oMr cbsmtp
exit 0
