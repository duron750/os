/* @(#)src/routers/rtlib.h	1.5 7/11/92 11:50:44 */

/*
 * rtlib.h - interface file for routines in rtlib.c
 */

/* flag values passed from rt[dv]_standard to the driver routines */
#define RT_VERIFY	0x0001		/* Verify only */

/* external functions in the rtlib.c file */
void rtd_standard();
void rtv_standard();
