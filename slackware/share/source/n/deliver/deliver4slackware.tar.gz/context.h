/* $Header: context.h,v 2.1 89/06/09 12:25:15 network Exp $
 *
 * User context, as found in /etc/passwd.
 *
 * $Log:	context.h,v $
 * Revision 2.1  89/06/09  12:25:15  network
 * Update RCS revisions.
 * 
 * Revision 1.3  89/06/09  12:23:40  network
 * Baseline for 2.0 release.
 * 
 */

/*----------------------------------------------------------------------
 * The context structure.
 */

#define CONTEXT struct context
CONTEXT {
	CONTEXT *ct_next;
	int     ct_uid;
	int     ct_gid;
	char    *ct_name;
	char    *ct_home;
};
