
#ifndef LYReadCFG_H
#define LYReadCFG_H

#ifndef LYSTRUCTS_H
#include "LYStructs.h"
#endif

extern void read_cfg PARAMS((char *cfg_filename));

#endif /* LYReadCFG_H */

