
#ifndef LYEdit_H
#define LYEdit_H

extern int edit_current_file PARAMS((char *newfile, int cur, int lineno));

#endif /* LYEdit_H */
