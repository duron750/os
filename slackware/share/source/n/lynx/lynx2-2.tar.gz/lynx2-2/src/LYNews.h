

#ifndef LYNEWSPOST_H
#define LYNEWSPOST_H

#ifndef LYSTRUCTS_H
#include "LYStructs.h"
#endif

extern int LYNewsPost PARAMS((document *newdoc));

#endif /* LYNEWSPOST_H */

