
#ifndef LYrcFile_H
#define LYrcFile_H

#ifndef LYSTRUCTS_H
#include "LYStructs.h"
#endif

extern void read_rc NOPARAMS;
extern int save_rc NOPARAMS;

#endif /* LYrcFile_H */

