
#ifndef LYShowInfo_H
#define LYShowInfo_H

#ifndef LYSTRUCTS_H
#include "LYStructs.h"
#endif

extern int showinfo PARAMS((document *doc, int size_of_file, 
							char *owner_address));


#endif /* LYShowInfo_H */

