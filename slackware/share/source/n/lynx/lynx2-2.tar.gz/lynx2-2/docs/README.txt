
                       HOW TO OBTAIN THE LYNX HELP FILES
                                       
   The Lynx help files that are accessable through the default Lynx help
   menu can be easily download from the Lynx FTP site at
   ftp2.cc.ukans.edu in the pub/lynx directory. All of the files have
   been placed in one archive for easy retrieval as either
   lynx_help_files.tar.Z or lynx_help_files.zip.
   
   Once you have downloaded the files extract them and set HELPFILE in
   the lynx.cfg as:
   file://localhost/FULL_PATH_TO_HELP_FILES/lynx_help_main.html
   
   Additional instructions for HELFILE configuration are in the lynx.cfg
   file.
   
   :lou
