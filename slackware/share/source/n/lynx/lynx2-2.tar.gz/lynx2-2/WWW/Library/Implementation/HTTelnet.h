/*                 /Net/dxcern/userd/timbl/hypertext/WWW/Library/Implementation/HTTelnet.html
                            TELNET AND SIMILAR ACCESS METHODS
                                             
 */

#ifndef HTTELNET_H
#define HTTELNET_H

#include "HTAccess.h"

GLOBALREF HTProtocol HTTelnet;
GLOBALREF HTProtocol HTRlogin;
GLOBALREF HTProtocol HTTn3270;

#endif

/*

   end */
