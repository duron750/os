The files in this directory do not 
represent a test suite.  They are used by
me during program testing to track down
odd and mysterious bugs.

:lou
