i_sgtty=define
i_termios=undef
