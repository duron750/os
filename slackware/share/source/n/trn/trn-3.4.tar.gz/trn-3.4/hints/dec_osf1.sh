libpth="$libpth /usr/shlib" # Use the shared libraries if possible
libc='/usr/shlib/libc.so'   # The archive version is /lib/libc.a
