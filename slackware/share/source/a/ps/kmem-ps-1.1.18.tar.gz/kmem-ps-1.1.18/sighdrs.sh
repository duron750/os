kill -l | awk '
{
	for (i = 1; i < NF; i += 2) {
		num = $i
		num = substr(num, 1, length(num) - 1) + 0
		if ($(i + 1) == "bad") {
			i++
			continue
		}
		sig[num] = $(i + 1)
		if (sig[num] ~ /^SIG/)
			sig[num] = substr(sig[num], 4)
		if (length(sig[num]) > maxlen)
			maxlen = length(sig[num])
	}
}
END {
	spaces = "                                "
	for (i = 1; i <= maxlen; i++)
		str[i] = spaces
	for (i = 1; i <= 32; i++) {
		s = sig[i]
		if (s) {
			while (length(s) < maxlen)
				s = " " s
			for (j = 1; j <= maxlen; j++) {
				str[j] = substr(str[j], 1, i - 1) \
					substr(s, j, 1) \
					substr(str[j], i + 1, 32 - i)
			}
		}
	}
	for (i = 1; i <= maxlen; i++)
		print "\t\"" str[i] "\","
}
'
