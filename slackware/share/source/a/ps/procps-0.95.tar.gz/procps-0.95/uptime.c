#include "whattime.h"

void main (void) {
print_uptime();
exit(0);
}
