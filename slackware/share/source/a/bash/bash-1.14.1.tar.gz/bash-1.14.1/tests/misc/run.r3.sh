#
# the `after exec in ...' should not be echoed
../../bash < redir.t3.sh
