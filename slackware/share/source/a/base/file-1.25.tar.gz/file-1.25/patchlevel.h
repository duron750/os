/*
 * Patchlevel file for Ian Darwin's MAGIC command.
 * $Id: patchlevel.h,v 1.5 92/09/14 14:54:51 ian Exp $
 *
 * $Log:	patchlevel.h,v $
 * Revision 1.5  92/09/14  14:54:51  ian
 * Fix a tiny null-pointer bug in previous fix for tar archive + uncompress.
 * 
 */

#define	FILE_VERSION_MAJOR	3
#define	patchlevel		5
