/*
 * PD KSH
 * $Id: patchlevel.h,v 4.9 93/05/05 21:16:56 sjg Exp $
 */
#define VERSION		4
#define PATCHLEVEL	8
