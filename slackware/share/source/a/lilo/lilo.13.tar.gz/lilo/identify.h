/* identify.h  -  Translate label names to kernel paths */

/* Written 1992,1993 by Werner Almesberger */


#ifndef _IDENTIFY_H_
#define _IDENTIFY_H_

void identify_image(char *label,char *options);

/* Identifies the image which is referenced by the label. Prints the path name
   to standard output. If options is non-NULL, the following characters are
   used to filter the selection: i = traditional image, c = compound image,
   v = verify that the file exists. An error message is printed to standard
   error if no appropriate image can be found. */

#endif
