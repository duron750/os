/* cfg.h  -  Configuration file parser */

/* Written 1992-1994 by Werner Almesberger */


#ifndef _CFG_H_
#define _CFG_H_

typedef enum { cft_strg,cft_flag,cft_link,cft_end } CONFIG_TYPE;

typedef struct {
    CONFIG_TYPE type;
    char *name;
    void *action;
    void *data;
    void *context;
} CONFIG;


extern CONFIG cf_top[],cf_identify[],cf_options[],cf_all[],cf_kernel[],
  cf_image[],cf_other[];


void cfg_open(char *name);

/* Opens the configuration file. */

void cfg_error(char *msg,...);

/* Signals an error while parsing the configuration file and terminates the
   program. */

void cfg_dump(char *name,int indent,char *fmt,...);

/* Dumps the variable name with the printf-style value fmt,... to standard
   output. Special characters are escaped. The entry is indented by two spaces
   if indent is non-zero. Do dump a flag-valued variable, fmt is set to NULL. */

void cfg_init(CONFIG *table);

/* Initializes the specified table. */

void cfg_set(CONFIG *table,char *item,char *value,void *context);

/* Sets the specified variable in table. If the variable has already been set
   since the last call to cfg_init, a warning message is issued if the context
   keys don't match or a fatal error is reported if they do. */

int cfg_parse(CONFIG *table);

/* Parses the configuration file for variables contained in table. A non-zero
   value is returned if a variable not found in table has been met. Zero is
   returned if EOF has been reached. */

int cfg_get_flag(CONFIG *table,char *item);

/* Returns a non-zero value if the specified variable is set, zero if it
   isn't. */

char *cfg_get_strg(CONFIG *table,char *item);

/* Returns the value of the specified variable if it is set, NULL otherwise. */

#endif
