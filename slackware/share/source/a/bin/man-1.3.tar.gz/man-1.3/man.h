/* man.h */
struct dir {
    struct dir *nxt;
    char *dir;
};

struct dirs {
    struct dirs *nxt;
    char mandir[MAXPATHLEN];
    char bindir[MAXPATHLEN];
    int mandatory;
};

extern char *strdup();
