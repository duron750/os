
/* Definitions for button_state bitmasks */
#define BUTTON_MASK	0x03
#define BUTTON_1		0x00
#define BUTTON_2		0x01
#define BUTTON_3		0x02
#define RELEASE		0x03
#define SHIFT			0x04
#define META			0x08
#define CONTROL		0x0F

struct event {
	int happening;
	char button_state;
	unsigned int x;
	unsigned int y;
};
#define BUTTON_ISSET(X, B)	((X.button_state&BUTTON_MASK) == B)
   
extern int  event_init();
extern int  event_getc();
extern void event_quit();

