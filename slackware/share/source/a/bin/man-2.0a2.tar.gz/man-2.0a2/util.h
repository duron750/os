/* util.c */
char *mkprogname(char *s);
void downcase(char *s);
int is_newer(char *fa, char *fb);
int is_directory(char *path);
int do_system_command(char *command);
