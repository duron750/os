/* manp.c */
char *manpath(int perrs);
int get_dirlist(void);
char *def_path(int perrs);
char *get_manpath(int perrs, char *path);
void add_dir_to_list(char **lp, char *dir, int perrs);
char *has_subdirs(char *p);
