/* newman.c */
char *convert_name(char *name);
char *ult_src(char *name, char *path);
void do_extern(char *prog, char *name);
short do_manual(char *nextarg);
short find_manual_page(char *nextarg, short globalman);
