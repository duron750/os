#include <stdio.h>
#include "version.h"

extern char *prognam;

void ver(void)
{
	printf("%s, version %s\n", prognam, version);
}
