/* dbver.c */
int dbver(MYDBM_FILE dbf);
void dbver_wr(MYDBM_FILE dbf);
void dbver_rd(MYDBM_FILE dbf);
