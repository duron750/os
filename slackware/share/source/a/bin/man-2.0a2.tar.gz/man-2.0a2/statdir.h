/* statdir.c */
short testmandirs(char *path, time_t last);
void add_dir_entrys(char *path, char *infile);
int dup_test(char *oldpage, char *manpage);
int is_duplicate(char *oldpage, char *manpage);
short check_mandirs(short globalman);
char *get_userdb_list(void);
