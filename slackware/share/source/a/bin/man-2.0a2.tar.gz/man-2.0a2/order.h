/* order.c */
char *orderthem(char *newpage, char *list);
int compare(char **page1, char **page2);
