/* mandb.c */
int main(int argc, char *argv[]);
void straycats(void);
void compare_dirs(char *path);
void touch_stray_src(char *catdir, char *mandir);
char *convert_name(char *name);
