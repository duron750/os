#define MANPATH_MAIN
#define MAN_MAIN

#include <stdio.h>

#include "config.h"
#include "mydbm.h"
#include "dbver.h"


int main()
{
	datum key, content;
	MYDBM_FILE dbf;

	if ( (dbf = MYDBM_REOPEN(DB)) == NULL) {
		fprintf(stderr, "getmandbver: ");
		perror(DB);
		exit(1);
	}

	key.dptr = VER_KEY;
	key.dsize = sizeof VER_KEY;

	content = MYDBM_FETCH(dbf, key);

	if (content.dptr == NULL)
		puts(DB " has no man version ID");
	else
		printf(DB " is relative to man version %s\n", content.dptr);

	return 0;
}
