#include <stdio.h>

int main()
{
	extern char *gdbm_version;

	printf("%s\n", gdbm_version);
	return 0;
}
