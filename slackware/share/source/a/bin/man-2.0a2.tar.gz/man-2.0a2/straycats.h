/* straycats.c */
void usage(void);
int main(int argc, char *argv[]);
void compare_dirs(char *path);
void touch_stray_src(GDBM_FILE dbf, char *catdir, char *mandir);
char *convert_name_sc(char *name);
char *exists(char *list, char *catname);
