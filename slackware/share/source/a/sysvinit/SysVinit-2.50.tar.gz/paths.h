/*
 * paths.h	Paths of files that init and related utilities need.
 *
 * Version:	@(#) paths.h 1.50 1994-19-01
 *
 * Author:	Miquel van Smoorenburg, <miquels@drinkel.nl.mugnet.org>
 *
 */
#define INITLVL		"/etc/initrunlvl"	/* New runlevel for init */
#define CONSOLE		"/dev/console"		/* Logical system console */
#define SYSTTY		"/dev/systty"		/* Physical system console */
#define SYSDEV		0x0400			/* to mknod() the sysdev */
#define SECURETTY	"/etc/securetty"	/* List of root terminals */
#define SDALLOW		"/etc/shutdown.allow"	/* Users allowed to shutdown */
#define INITTAB		"/etc/inittab"		/* Location of inittab */
#define PWRSTAT		"/etc/powerstatus"	/* SIGPWR reason (OK/BAD) */
#define INIT		"/sbin/init"		/* Location of init itself. */
#define NOLOGIN		"/etc/nologin"		/* Stop user logging in. */
#define FASTBOOT	"/etc/fastboot"		/* Enable fast boot. */
#define SDPID		"/etc/shutdownpid"	/* PID of shutdown program */
#define IOSAVE		"/etc/ioctl.save"	/* termios settings for SU */
#define SHELL		"/bin/sh"		/* Default shell */
