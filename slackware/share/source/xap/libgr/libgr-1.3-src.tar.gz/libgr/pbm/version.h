/* version.h - define the current version of PBM, PGM, PPM, and PNM
*/

#define PBMPLUS_VERSION "10dec91"
