
/*  selectOp.c */
void	SelectSetCutMode(int);

/* circleOp.c */
Boolean	CircleGetStyle(void);
void	CircleSetStyle(Boolean);

/* fontOp.c */
void     FontChanged(Widget);

/* sprayOp.c */
Boolean	SprayGetStyle(void);
void	SpraySetStyle(Boolean);

/* brushOp.c */
Boolean EraseGetMode(void);
void	EraseSetMode(Boolean);

/* fontOp.c */
void	FontChanged(Widget);

/* boxOp.c */
void	BoxSetStyle(Boolean);
Boolean	BoxGetStyle(void);

/* fillOp.c */
void	FillSetMode(int);
int	FillGetMode(void);
