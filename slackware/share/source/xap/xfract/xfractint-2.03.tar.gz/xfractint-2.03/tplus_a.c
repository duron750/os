/* tplus_a.c
 * This file contains routines to replace tplus_a.asm.
 *
 * This file Copyright 1992 Ken Shirriff.  It may be used according to the
 * fractint license conditions, blah blah blah.
 */

#include <fractint.h>

WriteTPlusBankedPixel() {}
ReadTPlusBankedPixel() {}
MatchTPlusMode() {}
