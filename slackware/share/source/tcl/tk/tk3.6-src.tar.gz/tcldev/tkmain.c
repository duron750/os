int main(int argc, char **argv)
{
    int Tk_Main(int, char **);
    return Tk_Main(argc, argv);
}
