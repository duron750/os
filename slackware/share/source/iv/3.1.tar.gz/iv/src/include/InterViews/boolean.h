/* backward compatibility */

#include <InterViews/enter-scope.h>
