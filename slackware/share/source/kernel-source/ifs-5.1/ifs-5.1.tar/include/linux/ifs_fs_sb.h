#ifndef _IFS_FS_SB
#define _IFS_FS_SB

struct ifs_sb_info {
	int layers; /* number of layers */
	struct inode *ifs_inodes; /* private list of inodes */
	ino_t ifs_ino; /* inode number allocation counter */
	struct wait_queue *ino_wait; /* lock inode creation */
	int ino_lock;
	int flags; /* FS flags */
};

#endif
