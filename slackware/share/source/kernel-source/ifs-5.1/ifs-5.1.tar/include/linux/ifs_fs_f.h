#ifndef _IFS_FS_F
#define _IFS_FS_F

/*
 * Inheriting file system file data
 */

struct ifs_file_info {
	int layer; /* readdir */
	struct file *open; /* file access */
};

#endif
