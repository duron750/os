#ifndef _LINUX_IFS_FS_PARAM_H
#define _LINUX_IFS_FS_PARAM_H

/*
 * Global inheriting filesystem parameters
 */

#define IFS_BITS       2
#define IFS_MAX_LAYERS (1 << IFS_BITS)

#endif
