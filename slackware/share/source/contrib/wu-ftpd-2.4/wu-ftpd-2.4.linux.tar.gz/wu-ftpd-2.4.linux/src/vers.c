char version[] = "Version wu-2.4(2) Thu May 26 19:47:47 EDT 1994";
