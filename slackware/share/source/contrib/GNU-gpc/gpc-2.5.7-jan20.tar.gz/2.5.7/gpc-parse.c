
/*  A Bison parser, made from /src/gnu/gpc/2.5.7/gpc-parse.y  */

#define	IDENTIFIER	258
#define	AND	259
#define	ARRAY	260
#define	BEGIN	261
#define	CASE	262
#define	CONST	263
#define	DIV	264
#define	DO	265
#define	DOWNTO	266
#define	ELSE	267
#define	END	268
#define	FILE_	269
#define	FOR	270
#define	FUNCTION	271
#define	GOTO	272
#define	IF	273
#define	IN	274
#define	LABEL	275
#define	MOD	276
#define	NIL	277
#define	NOT	278
#define	OF	279
#define	OR	280
#define	PACKED	281
#define	PROCEDURE	282
#define	PROGRAM	283
#define	RECORD	284
#define	REPEAT	285
#define	SET	286
#define	THEN	287
#define	TO	288
#define	TYPE	289
#define	UNTIL	290
#define	VAR	291
#define	WHILE	292
#define	WITH	293
#define	AND_THEN	294
#define	BINDABLE	295
#define	EXPORT	296
#define	IMPORT	297
#define	MODULE	298
#define	ONLY	299
#define	OR_ELSE	300
#define	OTHERWISE	301
#define	POW	302
#define	RESTRICTED	303
#define	PROTECTED	304
#define	QUALIFIED	305
#define	VALUE	306
#define	OP_ABSTRACT	307
#define	OP_CLASS	308
#define	OP_CONSTRUCTOR	309
#define	OP_DESTRUCTOR	310
#define	OP_INHERITED	311
#define	OP_IS	312
#define	OP_PROPERTY	313
#define	OP_VIEW	314
#define	RENAME	315
#define	SYMMETRIC_DIFF	316
#define	STRING_SCHEMA	317
#define	D_IMPLEMENTATION	318
#define	D_INTERFACE	319
#define	D_FORWARD	320
#define	D_C	321
#define	D_C_LANGUAGE	322
#define	D_EXTERN	323
#define	D_EXTERNAL	324
#define	D_OVERRIDE	325
#define	r_WRITE	326
#define	r_READ	327
#define	r_INITFDR	328
#define	r_LAZYGET	329
#define	r_COLLECT	330
#define	r_POW	331
#define	r_EXPON	332
#define	z_ARCTAN	333
#define	z_COS	334
#define	z_EXP	335
#define	z_LN	336
#define	z_SIN	337
#define	z_SQRT	338
#define	z_POW	339
#define	z_EXPON	340
#define	p_INPUT	341
#define	p_OUTPUT	342
#define	p_REWRITE	343
#define	p_RESET	344
#define	p_PUT	345
#define	p_GET	346
#define	p_WRITE	347
#define	p_READ	348
#define	p_WRITELN	349
#define	p_READLN	350
#define	p_PAGE	351
#define	p_NEW	352
#define	p_DISPOSE	353
#define	p_ABS	354
#define	p_SQR	355
#define	p_SIN	356
#define	p_COS	357
#define	p_EXP	358
#define	p_LN	359
#define	p_SQRT	360
#define	p_ARCTAN	361
#define	p_TRUNC	362
#define	p_ROUND	363
#define	p_PACK	364
#define	p_UNPACK	365
#define	p_ORD	366
#define	p_CHR	367
#define	p_SUCC	368
#define	p_PRED	369
#define	p_ODD	370
#define	p_EOF	371
#define	p_EOLN	372
#define	p_MAXINT	373
#define	p_TRUE	374
#define	p_FALSE	375
#define	p_EXTEND	376
#define	p_UPDATE	377
#define	p_SEEKWRITE	378
#define	p_SEEKREAD	379
#define	p_SEEKUPDATE	380
#define	p_READSTR	381
#define	p_WRITESTR	382
#define	p_BIND	383
#define	p_UNBIND	384
#define	p_HALT	385
#define	p_GETTIMESTAMP	386
#define	p_ARG	387
#define	p_RE	388
#define	p_IM	389
#define	p_CARD	390
#define	p_CMPLX	391
#define	p_POLAR	392
#define	p_EMPTY	393
#define	p_POSITION	394
#define	p_LASTPOSITION	395
#define	p_LENGTH	396
#define	p_INDEX	397
#define	p_SUBSTR	398
#define	p_TRIM	399
#define	p_EQ	400
#define	p_LT	401
#define	p_GT	402
#define	p_NE	403
#define	p_LE	404
#define	p_GE	405
#define	p_BINDING	406
#define	p_DATE	407
#define	p_TIME	408
#define	p_MAXCHAR	409
#define	p_MAXREAL	410
#define	p_MINREAL	411
#define	p_EPSREAL	412
#define	STANDARD_OUTPUT	413
#define	STANDARD_INPUT	414
#define	op_COPY	415
#define	op_NULL	416
#define	op_ROOT	417
#define	op_SELF	418
#define	op_TEXTWRITABLE	419
#define	ASM	420
#define	BREAK	421
#define	CONTINUE	422
#define	p_MARK	423
#define	p_RELEASE	424
#define	RETURN	425
#define	DEFAULT	426
#define	OTHERS	427
#define	p_CLOSE	428
#define	SIZEOF	429
#define	ALIGNOF	430
#define	ANDAND	431
#define	CONJUGATE	432
#define	p_DEFINESIZE	433
#define	INLINE	434
#define	EXTERNAL	435
#define	VOLATILE	436
#define	STATIC	437
#define	G_CONST	438
#define	TQ_BYTE	439
#define	TQ_SHORT	440
#define	TQ_LONG	441
#define	TQ_LONGLONG	442
#define	TQ_UNSIGNED	443
#define	UNSIGNED_INTEGER	444
#define	STRING_LITERAL	445
#define	CHAR_LITERAL	446
#define	UNSIGNED_REAL	447
#define	GTE	448
#define	LTE	449
#define	NEQ	450
#define	EXPON	451
#define	ASSIGN	452
#define	LBRACKET	453
#define	RBRACKET	454
#define	TWODOTS	455
#define	ELLIPSIS	456

#line 56 "/src/gnu/gpc/2.5.7/gpc-parse.y"

#include <stdio.h>
#include <ctype.h>
#include <errno.h>

#include "config.h"
#include "tree.h"
#include "input.h"
#include "c-tree.h"
#include "flags.h"
#include "gpc-defs.h"

#ifndef errno
extern int errno;
#endif

/* Cause the `yydebug' variable to be defined.  */
#define YYDEBUG 1

extern char *token_buffer;	/* Pointer to token buffer.
				   Actual allocated length is maxtoken + 2.  */

extern struct function * maybe_find_function_data PROTO ((tree));

extern void warning ();

void yyerror();

/* Like YYERROR but do call yyerror */
#define YYERROR1 { yyerror ("syntax error"); YYERROR; }

void position_after_white_space ();

/* Since parsers are distinct for each language, put the language string
   definition here.  */
/* rs-6000.c calls abort() if this is "GNU Pascal" :-) */
char *language_string = "GNU PASCAL";

tree main_program_name = NULL_TREE;


#line 103 "/src/gnu/gpc/2.5.7/gpc-parse.y"
typedef union {
    char *filename;
    long  itype;
    int   lineno; 
    enum  tree_code code;
    tree  ttype;
} YYSTYPE;
#line 479 "/src/gnu/gpc/2.5.7/gpc-parse.y"

/* the declaration found for the last IDENTIFIER token read in. */
extern tree lastiddecl;

extern void reinit_parse_for_function ();

extern char *input_filename;		/* file being read */
extern char *main_input_filename;	/* top-level source file */

static char *concat ();

extern int yylex ();

/* Number of statements (loosely speaking) seen so far.  */
static int stmt_count;

static char *if_stmt_file;
static int if_stmt_line;

/* To allow build_enumerator() to set up the correct type for
 * enumerated type elements (In C they are all ints).
 * Think about [ enumtype ] set constructor.
 */
extern tree current_enum_type;

/*
 * Nonzero if the 
 */
int top_level_labels = 0;
tree main_program_labels;

tree check_set_bounds ();

#ifndef YYLTYPE
typedef
  struct yyltype
    {
      int timestamp;
      int first_line;
      int first_column;
      int last_line;
      int last_column;
      char *text;
   }
  yyltype;

#define YYLTYPE yyltype
#endif

#include <stdio.h>

#ifndef __STDC__
#define const
#endif



#define	YYFINAL		1121
#define	YYFLAG		-32768
#define	YYNTBASE	220

#define YYTRANSLATE(x) ((unsigned)(x) <= 456 ? yytranslate[x] : 476)

static const short yytranslate[] = {     0,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,   216,     2,   210,
   212,   208,   206,   211,   205,   209,   207,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,   215,   217,   202,
   203,   204,     2,   214,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
   218,     2,   219,   213,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     1,     2,     3,     4,     5,
     6,     7,     8,     9,    10,    11,    12,    13,    14,    15,
    16,    17,    18,    19,    20,    21,    22,    23,    24,    25,
    26,    27,    28,    29,    30,    31,    32,    33,    34,    35,
    36,    37,    38,    39,    40,    41,    42,    43,    44,    45,
    46,    47,    48,    49,    50,    51,    52,    53,    54,    55,
    56,    57,    58,    59,    60,    61,    62,    63,    64,    65,
    66,    67,    68,    69,    70,    71,    72,    73,    74,    75,
    76,    77,    78,    79,    80,    81,    82,    83,    84,    85,
    86,    87,    88,    89,    90,    91,    92,    93,    94,    95,
    96,    97,    98,    99,   100,   101,   102,   103,   104,   105,
   106,   107,   108,   109,   110,   111,   112,   113,   114,   115,
   116,   117,   118,   119,   120,   121,   122,   123,   124,   125,
   126,   127,   128,   129,   130,   131,   132,   133,   134,   135,
   136,   137,   138,   139,   140,   141,   142,   143,   144,   145,
   146,   147,   148,   149,   150,   151,   152,   153,   154,   155,
   156,   157,   158,   159,   160,   161,   162,   163,   164,   165,
   166,   167,   168,   169,   170,   171,   172,   173,   174,   175,
   176,   177,   178,   179,   180,   181,   182,   183,   184,   185,
   186,   187,   188,   189,   190,   191,   192,   193,   194,   195,
   196,   197,   198,   199,   200,   201
};

static const short yyprhs[] = {     0,
     0,     1,     3,     5,     8,    11,    14,    16,    18,    19,
    20,    21,    22,    33,    37,    38,    43,    44,    46,    50,
    52,    56,    60,    64,    67,    69,    71,    73,    75,    77,
    79,    81,    83,    85,    87,    89,    91,    93,    95,    97,
    99,   101,   103,   105,   107,   109,   111,   113,   115,   117,
   119,   121,   123,   125,   127,   129,   131,   133,   135,   137,
   139,   141,   143,   145,   147,   149,   151,   153,   155,   157,
   159,   161,   163,   165,   167,   169,   171,   173,   175,   177,
   179,   181,   183,   185,   187,   189,   191,   193,   195,   197,
   199,   201,   203,   205,   207,   209,   211,   213,   215,   217,
   219,   221,   223,   225,   227,   229,   231,   233,   235,   237,
   239,   241,   243,   245,   247,   249,   251,   253,   255,   257,
   259,   261,   263,   265,   267,   269,   271,   273,   275,   277,
   279,   281,   283,   285,   287,   289,   291,   293,   295,   297,
   299,   301,   303,   305,   307,   309,   311,   313,   315,   317,
   318,   324,   326,   327,   329,   331,   334,   336,   338,   340,
   342,   344,   346,   350,   353,   355,   359,   361,   365,   369,
   372,   374,   376,   379,   382,   386,   388,   391,   393,   398,
   400,   403,   405,   407,   410,   412,   414,   416,   418,   420,
   422,   424,   426,   428,   430,   432,   434,   436,   438,   440,
   442,   444,   447,   451,   454,   456,   460,   462,   466,   470,
   473,   478,   481,   484,   486,   489,   492,   494,   495,   497,
   499,   501,   503,   505,   507,   509,   511,   513,   515,   517,
   519,   520,   526,   530,   532,   536,   538,   542,   546,   549,
   551,   555,   558,   560,   562,   564,   566,   569,   574,   575,
   579,   585,   589,   591,   595,   598,   600,   602,   605,   607,
   609,   611,   613,   615,   618,   622,   626,   633,   635,   639,
   641,   645,   649,   652,   654,   656,   661,   662,   666,   670,
   674,   678,   682,   683,   686,   690,   692,   694,   698,   702,
   706,   709,   714,   720,   722,   730,   734,   738,   740,   742,
   746,   750,   752,   755,   761,   763,   767,   771,   775,   778,
   780,   784,   788,   792,   796,   800,   803,   805,   809,   811,
   815,   819,   825,   826,   828,   830,   832,   834,   836,   839,
   840,   843,   848,   849,   850,   851,   852,   864,   869,   876,
   877,   879,   881,   883,   885,   887,   889,   891,   893,   894,
   897,   898,   901,   903,   904,   907,   908,   912,   918,   922,
   926,   928,   932,   936,   940,   945,   951,   953,   958,   964,
   965,   967,   969,   971,   973,   975,   977,   985,   992,   998,
  1000,  1004,  1008,  1012,  1014,  1020,  1022,  1026,  1030,  1034,
  1035,  1036,  1040,  1041,  1048,  1050,  1052,  1054,  1061,  1063,
  1065,  1067,  1069,  1071,  1073,  1078,  1080,  1084,  1086,  1090,
  1094,  1096,  1098,  1100,  1101,  1107,  1109,  1111,  1112,  1117,
  1119,  1120,  1128,  1130,  1132,  1134,  1138,  1140,  1144,  1148,
  1149,  1154,  1155,  1160,  1162,  1164,  1166,  1168,  1170,  1172,
  1173,  1174,  1181,  1182,  1183,  1190,  1192,  1194,  1195,  1196,
  1207,  1208,  1209,  1218,  1220,  1222,  1224,  1226,  1228,  1230,
  1232,  1234,  1235,  1238,  1242,  1243,  1244,  1249,  1251,  1253,
  1255,  1259,  1261,  1265,  1267,  1270,  1272,  1274,  1275,  1278,
  1280,  1282,  1285,  1291,  1296,  1301,  1306,  1309,  1312,  1317,
  1322,  1324,  1326,  1328,  1329,  1332,  1333,  1337,  1339,  1343,
  1345,  1349,  1353,  1355,  1359,  1365,  1367,  1369,  1371,  1373,
  1375,  1377,  1379,  1381,  1383,  1385,  1387,  1389,  1391,  1393,
  1395,  1397,  1399,  1401,  1403,  1405,  1407,  1409,  1411,  1413,
  1416,  1418,  1420,  1426,  1434,  1444,  1456,  1457,  1458,  1460,
  1462,  1466,  1471,  1473,  1477,  1479,  1481,  1483,  1487,  1489,
  1493,  1497,  1499,  1501,  1503,  1507,  1511,  1513,  1515,  1519,
  1523,  1527,  1530,  1532,  1535,  1537,  1540,  1542,  1544,  1548,
  1552,  1556,  1560,  1562,  1566,  1570,  1574,  1576,  1578,  1580,
  1582,  1586,  1589,  1591,  1594,  1597,  1602,  1607,  1612,  1614,
  1616,  1618,  1620,  1624,  1628,  1633,  1634,  1640,  1644,  1645,
  1647,  1651,  1653,  1657,  1661,  1663,  1667,  1672,  1679,  1682,
  1687,  1688,  1692,  1694,  1696,  1698,  1700,  1702,  1704,  1706,
  1708,  1710,  1712,  1714,  1716,  1718,  1720,  1722,  1724,  1726,
  1728,  1730,  1732,  1734,  1736,  1738,  1740,  1742,  1744,  1746,
  1748,  1750,  1752,  1754,  1756,  1758,  1760,  1762,  1764,  1766,
  1768,  1770,  1772,  1774,  1776,  1778,  1780,  1782,  1784,  1786,
  1788,  1790,  1792,  1794,  1796,  1797,  1799,  1800,  1802,  1804,
  1806,  1808,  1810,  1811,  1812,  1814,  1815,  1816,  1817,  1822,
  1823,  1829,  1833,  1834,  1839,  1840,  1845,  1848,  1849,  1857,
  1858,  1860,  1862,  1865,  1867,  1869,  1873,  1874,  1877,  1881,
  1882,  1883,  1884,  1896,  1897,  1899,  1900,  1901,  1911,  1912,
  1915,  1917,  1919,  1923,  1925,  1929,  1933,  1939,  1940,  1942,
  1944,  1948,  1950,  1954,  1958,  1961,  1965,  1967,  1970,  1971,
  1974,  1975,  1979,  1981,  1985,  1989,  1993,  1994,  1996,  1997,
  2001,  2006,  2008,  2012,  2014,  2018,  2022
};

static const short yyrhs[] = {    -1,
   221,     0,   222,     0,   221,   222,     0,   224,   223,     0,
   438,   223,     0,   209,     0,     1,     0,     0,     0,     0,
     0,   229,   428,   225,   434,   226,   237,   227,   328,   228,
   436,     0,    28,   236,   231,     0,     0,    28,     1,   230,
   231,     0,     0,   232,     0,   210,   233,   375,     0,   236,
     0,   233,   211,   236,     0,   233,     1,   236,     0,   233,
   211,     1,     0,   233,     1,     0,     3,     0,     3,     0,
     3,     0,   118,     0,   119,     0,   120,     0,   154,     0,
   155,     0,   156,     0,   157,     0,    86,     0,    87,     0,
    88,     0,    89,     0,    90,     0,    91,     0,    92,     0,
    93,     0,    94,     0,    95,     0,    96,     0,   121,     0,
   122,     0,   123,     0,   124,     0,   125,     0,   138,     0,
   139,     0,   140,     0,    97,     0,    98,     0,    99,     0,
   100,     0,   101,     0,   102,     0,   103,     0,   104,     0,
   105,     0,   106,     0,   132,     0,   133,     0,   134,     0,
   107,     0,   108,     0,   109,     0,   110,     0,   135,     0,
   136,     0,   137,     0,   111,     0,   112,     0,   113,     0,
   114,     0,   115,     0,   116,     0,   117,     0,    62,     0,
   126,     0,   127,     0,   141,     0,   142,     0,   143,     0,
   144,     0,   145,     0,   146,     0,   147,     0,   148,     0,
   149,     0,   150,     0,   128,     0,   129,     0,   151,     0,
   130,     0,   131,     0,   152,     0,   153,     0,    63,     0,
    64,     0,    65,     0,    66,     0,    67,     0,    69,     0,
    68,     0,   165,     0,   175,     0,   166,     0,   167,     0,
   173,     0,   171,     0,   168,     0,   172,     0,   169,     0,
   170,     0,   174,     0,   177,     0,   178,     0,   158,     0,
   159,     0,    49,     0,    39,     0,    40,     0,    41,     0,
    42,     0,    43,     0,    44,     0,    45,     0,    46,     0,
    47,     0,    48,     0,    50,     0,    51,     0,    52,     0,
    53,     0,    54,     0,    55,     0,    56,     0,    57,     0,
    58,     0,    59,     0,    70,     0,   160,     0,   161,     0,
   162,     0,   164,     0,   163,     0,     0,    42,   470,   428,
   238,   239,     0,   239,     0,     0,   240,     0,   241,     0,
   240,   241,     0,   242,     0,   305,     0,   243,     0,   246,
     0,   256,     0,   298,     0,    20,   244,   428,     0,    20,
   428,     0,   245,     0,   244,   211,   245,     0,     1,     0,
   244,     1,   245,     0,   244,   211,     1,     0,   244,     1,
     0,   189,     0,   236,     0,     8,   247,     0,     8,   428,
     0,     8,     1,   428,     0,   248,     0,   247,   248,     0,
     1,     0,   236,   203,   402,   428,     0,   235,     0,   252,
   235,     0,   250,     0,   253,     0,   252,   251,     0,   251,
     0,   189,     0,   192,     0,   118,     0,   155,     0,   156,
     0,   157,     0,   154,     0,   206,     0,   205,     0,   255,
     0,   191,     0,   254,     0,    22,     0,   120,     0,   119,
     0,   190,     0,   255,   190,     0,    34,   257,   428,     0,
    34,   428,     0,   258,     0,   257,   428,   258,     0,     1,
     0,   257,     1,   258,     0,   257,   428,     1,     0,   257,
     1,     0,   236,   203,   259,   304,     0,   260,   234,     0,
   260,   262,     0,   261,     0,    40,   261,     0,    40,    48,
     0,    48,     0,     0,   184,     0,   185,     0,   186,     0,
   187,     0,   188,     0,   263,     0,   269,     0,   276,     0,
   278,     0,   297,     0,   264,     0,   268,     0,     0,   210,
   437,   265,   266,   212,     0,   210,     1,   212,     0,   267,
     0,   266,   211,   267,     0,     1,     0,   266,     1,   267,
     0,   266,   211,     1,     0,   266,     1,     0,   236,     0,
   249,   200,   404,     0,   270,   271,     0,   213,     0,   214,
     0,   236,     0,   272,     0,    27,   273,     0,    16,   273,
   215,   234,     0,     0,   210,   201,   212,     0,   210,   274,
   275,   201,   212,     0,   210,   274,   212,     0,   234,     0,
   274,   275,   234,     0,   274,     1,     0,   211,     0,   428,
     0,    26,   277,     0,   277,     0,   280,     0,   283,     0,
   285,     0,   286,     0,    62,   279,     0,   210,   404,   212,
     0,   431,   404,   432,     0,     5,   431,   281,   432,    24,
   259,     0,   282,     0,   281,   211,   282,     0,     1,     0,
   281,     1,   282,     0,   281,   211,     1,     0,   281,     1,
     0,   263,     0,   234,     0,    14,   284,    24,   259,     0,
     0,   431,   282,   432,     0,    31,    24,   282,     0,    31,
    24,     1,     0,    29,   287,    13,     0,    29,     1,    13,
     0,     0,   288,   429,     0,   288,   428,   290,     0,   290,
     0,   289,     0,   288,   428,   289,     0,   288,     1,   289,
     0,   288,   428,     1,     0,   288,     1,     0,   437,   233,
   215,   259,     0,     7,   292,    24,   293,   291,     0,   429,
     0,   428,   355,   430,   210,   287,   212,   429,     0,   236,
   215,   234,     0,   236,     1,   234,     0,   234,     0,   294,
     0,   293,   428,   294,     0,   293,     1,   294,     0,     1,
     0,   293,     1,     0,   295,   215,   210,   287,   212,     0,
   296,     0,   295,   211,   296,     0,   295,   211,     1,     0,
   295,     1,   296,     0,   295,     1,     0,   402,     0,   402,
   200,   402,     0,   402,     1,   402,     0,   402,   200,     1,
     0,    34,    24,   404,     0,    36,   299,   428,     0,    36,
   428,     0,   300,     0,   299,   428,   300,     0,     1,     0,
   299,     1,   300,     0,   299,   428,     1,     0,   233,   215,
   301,   259,   304,     0,     0,   303,     0,   180,     0,   182,
     0,   181,     0,   302,     0,   303,   302,     0,     0,    51,
   404,     0,   310,   428,   312,   428,     0,     0,     0,     0,
     0,   310,   428,   306,   434,   307,   239,   308,   328,   428,
   309,   436,     0,   311,    27,   236,   316,     0,   311,    16,
   236,   316,   314,   315,     0,     0,   179,     0,   313,     0,
     3,     0,    65,     0,    66,     0,    67,     0,    69,     0,
    68,     0,     0,   203,   236,     0,     0,   215,   234,     0,
     1,     0,     0,   317,   318,     0,     0,   210,   319,   212,
     0,   210,   319,   429,   201,   212,     0,   210,   201,   212,
     0,   210,     1,   212,     0,   320,     0,   319,   428,   320,
     0,   319,     1,   320,     0,   319,   428,     1,     0,   321,
   233,   215,   322,     0,   321,    36,   233,   215,   322,     0,
   310,     0,   321,   233,   215,   323,     0,   321,    36,   233,
   215,   323,     0,     0,    49,     0,   234,     0,   297,     0,
    62,     0,   324,     0,   325,     0,    26,     5,   431,   326,
   432,    24,   259,     0,     5,   431,   327,   432,    24,   259,
     0,   236,   200,   236,   215,   234,     0,   326,     0,   327,
   428,   326,     0,   327,     1,   326,     0,   327,   428,     1,
     0,   329,     0,     6,   433,   330,   435,    13,     0,   333,
     0,   330,   428,   333,     0,   330,     1,   333,     0,   330,
   428,     1,     0,     0,     0,   331,   332,   334,     0,     0,
   245,   215,   335,   331,   332,   337,     0,   337,     0,   336,
     0,     1,     0,    36,   233,   215,   301,   259,   304,     0,
   338,     0,   370,     0,   329,     0,   339,     0,   342,     0,
   356,     0,    38,   340,    10,   333,     0,   341,     0,   340,
   211,   341,     0,     1,     0,   340,     1,   341,     0,   340,
   428,     1,     0,   413,     0,   346,     0,   348,     0,     0,
    18,   403,   345,   344,   333,     0,    32,     0,     1,     0,
     0,   343,    12,   347,   333,     0,   343,     0,     0,     7,
   404,   350,   349,   351,   429,    13,     0,    24,     0,     1,
     0,   352,     0,   351,   428,   352,     0,     1,     0,   351,
     1,   352,     0,   351,   428,     1,     0,     0,   295,   215,
   353,   333,     0,     0,   355,   430,   354,   333,     0,   171,
     0,   172,     0,    46,     0,   357,     0,   360,     0,   364,
     0,     0,     0,    30,   358,   330,    35,   359,   403,     0,
     0,     0,    37,   361,   403,   362,   363,   333,     0,    10,
     0,     1,     0,     0,     0,    15,   235,   197,   404,   369,
   404,   365,   363,   366,   333,     0,     0,     0,    15,   235,
    19,   406,   367,   363,   368,   333,     0,    33,     0,    11,
     0,     1,     0,   371,     0,   372,     0,   378,     0,   382,
     0,   390,     0,     0,    17,   245,     0,    17,   208,   404,
     0,     0,     0,   210,   374,   376,   375,     0,   212,     0,
     1,     0,   377,     0,   376,   211,   377,     0,     1,     0,
   376,   211,     1,     0,   404,     0,   379,   380,     0,   235,
     0,   414,     0,     0,   381,   404,     0,   197,     0,   203,
     0,   130,   420,     0,   383,   210,   377,   384,   375,     0,
   388,   210,   377,   375,     0,   389,   210,   376,   375,     0,
    92,   210,   386,   375,     0,    94,   385,     0,    95,   373,
     0,   127,   210,   386,   375,     0,   126,   210,   376,   375,
     0,    88,     0,    89,     0,   121,     0,     0,   211,   377,
     0,     0,   210,   386,   375,     0,   387,     0,   386,   211,
   387,     0,     1,     0,   386,     1,   387,     0,   386,   211,
     1,     0,   377,     0,   377,   215,   404,     0,   377,   215,
   404,   215,   404,     0,    90,     0,    91,     0,    96,     0,
   168,     0,   169,     0,   173,     0,   122,     0,   131,     0,
   129,     0,    93,     0,    97,     0,    98,     0,   109,     0,
   110,     0,   128,     0,   124,     0,   123,     0,   125,     0,
   178,     0,   391,     0,   393,     0,   392,     0,   394,     0,
   170,     0,   170,   404,     0,   166,     0,   167,     0,   165,
   395,   210,   255,   212,     0,   165,   395,   210,   255,   215,
   396,   212,     0,   165,   395,   210,   255,   215,   396,   215,
   396,   212,     0,   165,   395,   210,   255,   215,   396,   215,
   396,   215,   399,   212,     0,     0,     0,   397,     0,   398,
     0,   397,   211,   398,     0,   190,   210,   404,   212,     0,
   255,     0,   399,   211,   255,     0,   414,     0,     3,     0,
   404,     0,   401,   211,   404,     0,     1,     0,   401,     1,
   404,     0,   401,   211,     1,     0,   404,     0,   405,     0,
   405,     0,   406,   425,   406,     0,   406,    19,   406,     0,
   406,     0,   409,     0,   406,   427,   409,     0,   406,    25,
   409,     0,   406,   407,   409,     0,    25,    12,     0,    45,
     0,     4,    32,     0,    39,     0,   252,   410,     0,   410,
     0,   411,     0,   410,   426,   411,     0,   410,    61,   411,
     0,   410,     4,   411,     0,   410,   408,   411,     0,   412,
     0,   412,    47,   412,     0,   412,   196,   412,     0,   412,
    57,   412,     0,   413,     0,   253,     0,   251,     0,   416,
     0,   210,   404,   212,     0,    23,   412,     0,   419,     0,
   216,   235,     0,   176,   245,     0,   177,   210,   404,   212,
     0,   174,   210,   400,   212,     0,   175,   210,   400,   212,
     0,   235,     0,   414,     0,    87,     0,    86,     0,   413,
   209,   236,     0,   413,   270,   373,     0,   413,   431,   401,
   432,     0,     0,   235,   210,   415,   376,   375,     0,   431,
   417,   432,     0,     0,   418,     0,   417,   211,   418,     0,
     1,     0,   417,     1,   418,     0,   417,   211,     1,     0,
   404,     0,   404,   200,   404,     0,   422,   210,   377,   212,
     0,   423,   210,   377,   211,   377,   212,     0,   421,   420,
     0,   424,   210,   376,   212,     0,     0,   210,   377,   212,
     0,   116,     0,   117,     0,    99,     0,   100,     0,   101,
     0,   102,     0,   103,     0,   104,     0,   105,     0,   106,
     0,   132,     0,   133,     0,   134,     0,   107,     0,   108,
     0,   135,     0,   111,     0,   112,     0,   115,     0,   138,
     0,   139,     0,   140,     0,   141,     0,   144,     0,   151,
     0,   152,     0,   153,     0,   136,     0,   137,     0,   142,
     0,   145,     0,   146,     0,   147,     0,   148,     0,   149,
     0,   150,     0,   113,     0,   114,     0,   143,     0,   195,
     0,   194,     0,   193,     0,   203,     0,   202,     0,   204,
     0,     9,     0,    21,     0,   207,     0,   208,     0,   205,
     0,   206,     0,   217,     0,     0,   217,     0,     0,   215,
     0,   218,     0,   198,     0,   219,     0,   199,     0,     0,
     0,   436,     0,     0,     0,     0,    43,   236,   439,   440,
     0,     0,   444,   445,   428,   441,   452,     0,    64,   444,
   445,     0,     0,    63,   428,   442,   452,     0,     0,   444,
   237,   443,    13,     0,   231,   428,     0,     0,    41,   446,
   462,   428,   469,   447,    13,     0,     0,   448,     0,   449,
     0,   448,   449,     0,   242,     0,   450,     0,   310,   428,
   451,     0,     0,   312,   428,     0,   237,   461,    13,     0,
     0,     0,     0,    33,     6,   457,    10,   454,   434,   455,
   334,   428,   456,   436,     0,     0,   251,     0,     0,     0,
    33,    13,    10,   459,   434,   334,   428,   460,   436,     0,
     0,   453,   458,     0,   458,     0,   463,     0,   462,   428,
   463,     0,     1,     0,   462,     1,   463,     0,   462,   428,
     1,     0,   236,   464,   210,   465,   212,     0,     0,   203,
     0,   466,     0,   465,   211,   466,     0,     1,     0,   465,
     1,   466,     0,   465,   211,     1,     0,   236,   467,     0,
    49,   236,   468,     0,   468,     0,   200,   236,     0,     0,
    60,   236,     0,     0,    42,   470,   428,     0,   471,     0,
   470,   428,   471,     0,   470,     1,   471,     0,   236,   472,
   473,     0,     0,    50,     0,     0,   210,   474,   212,     0,
    44,   210,   474,   212,     0,   475,     0,   474,   211,   475,
     0,     1,     0,   474,     1,   475,     0,   474,   211,     1,
     0,   236,   468,     0
};

#if YYDEBUG != 0
static const short yyrline[] = { 0,
   519,   522,   527,   529,   532,   534,   537,   539,   545,   585,
   592,   600,   606,   616,   619,   624,   627,   630,   633,   638,
   641,   643,   648,   652,   657,   701,   708,   711,   713,   714,
   716,   718,   719,   720,   722,   723,   725,   726,   727,   728,
   729,   730,   731,   732,   733,   735,   736,   737,   738,   739,
   740,   741,   742,   744,   745,   747,   748,   749,   750,   751,
   752,   753,   754,   756,   757,   758,   760,   761,   762,   763,
   765,   766,   767,   769,   770,   771,   772,   774,   775,   776,
   778,   780,   781,   782,   783,   784,   785,   786,   787,   788,
   789,   790,   791,   793,   794,   795,   797,   799,   800,   801,
   803,   804,   806,   807,   808,   809,   810,   812,   813,   814,
   815,   816,   817,   818,   819,   820,   821,   822,   823,   824,
   826,   827,   833,   834,   835,   836,   837,   838,   839,   840,
   841,   842,   843,   844,   845,   849,   850,   851,   852,   853,
   854,   855,   856,   857,   858,   859,   860,   861,   862,   866,
   870,   870,   873,   875,   878,   880,   883,   885,   888,   890,
   891,   892,   898,   900,   904,   907,   910,   912,   916,   918,
   925,   935,   945,   947,   949,   952,   954,   955,   958,   971,
   973,   975,   976,   979,   982,   985,   987,   988,   990,   995,
  1000,  1005,  1012,  1015,  1019,  1022,  1023,  1026,  1029,  1031,
  1035,  1037,  1044,  1046,  1050,  1052,  1054,  1055,  1058,  1060,
  1067,  1102,  1122,  1135,  1137,  1139,  1141,  1145,  1148,  1150,
  1152,  1154,  1156,  1160,  1162,  1163,  1164,  1165,  1170,  1172,
  1177,  1183,  1187,  1194,  1196,  1199,  1201,  1205,  1208,  1215,
  1230,  1245,  1250,  1252,  1257,  1266,  1270,  1275,  1281,  1284,
  1286,  1288,  1293,  1296,  1298,  1305,  1307,  1312,  1315,  1318,
  1320,  1321,  1322,  1327,  1337,  1340,  1349,  1354,  1357,  1360,
  1362,  1366,  1369,  1381,  1384,  1389,  1394,  1397,  1403,  1411,
  1421,  1425,  1432,  1437,  1441,  1451,  1465,  1467,  1470,  1474,
  1477,  1484,  1496,  1506,  1509,  1524,  1535,  1545,  1555,  1557,
  1560,  1564,  1566,  1572,  1582,  1584,  1587,  1590,  1594,  1599,
  1602,  1607,  1611,  1617,  1628,  1630,  1634,  1636,  1638,  1639,
  1642,  1645,  1655,  1658,  1661,  1664,  1666,  1670,  1672,  1677,
  1680,  1691,  1701,  1732,  1751,  1754,  1782,  1789,  1798,  1817,
  1820,  1824,  1826,  1829,  1831,  1832,  1833,  1834,  1837,  1840,
  1846,  1850,  1852,  1859,  1864,  1868,  1871,  1873,  1877,  1881,
  1885,  1887,  1891,  1894,  1897,  1900,  1902,  1904,  1906,  1910,
  1913,  1921,  1923,  1924,  1928,  1930,  1934,  1943,  1951,  1956,
  1958,  1963,  1966,  1972,  1977,  1982,  1984,  1986,  1988,  1993,
  1997,  2001,  2006,  2015,  2016,  2017,  2018,  2022,  2034,  2036,
  2040,  2042,  2043,  2044,  2048,  2056,  2058,  2061,  2063,  2067,
  2071,  2087,  2089,  2094,  2105,  2107,  2109,  2113,  2119,  2123,
  2132,  2140,  2145,  2147,  2151,  2153,  2155,  2157,  2161,  2167,
  2216,  2217,  2237,  2241,  2243,  2244,  2249,  2251,  2252,  2256,
  2262,  2265,  2273,  2280,  2282,  2286,  2288,  2308,  2383,  2386,
  2398,  2403,  2405,  2408,  2411,  2413,  2418,  2420,  2422,  2424,
  2426,  2430,  2434,  2443,  2462,  2465,  2467,  2475,  2477,  2481,
  2484,  2487,  2489,  2493,  2504,  2620,  2628,  2631,  2634,  2638,
  2640,  2646,  2651,  2658,  2660,  2662,  2664,  2666,  2669,  2671,
  2675,  2678,  2680,  2684,  2687,  2691,  2694,  2699,  2701,  2704,
  2707,  2711,  2718,  2721,  2723,  2728,  2731,  2733,  2735,  2737,
  2739,  2741,  2743,  2745,  2749,  2752,  2754,  2756,  2758,  2760,
  2762,  2764,  2766,  2769,  2774,  2776,  2777,  2778,  2781,  2787,
  2795,  2804,  2813,  2819,  2825,  2831,  2839,  2847,  2850,  2853,
  2855,  2859,  2864,  2867,  2873,  2875,  2888,  2891,  2894,  2897,
  2901,  2909,  2915,  2920,  2924,  2927,  2929,  2932,  2934,  2936,
  2940,  2946,  2949,  2952,  2955,  2959,  2962,  2966,  2968,  2970,
  2972,  2976,  2986,  2988,  2997,  3006,  3012,  3029,  3030,  3031,
  3032,  3035,  3037,  3038,  3050,  3055,  3057,  3062,  3086,  3100,
  3103,  3106,  3108,  3114,  3145,  3152,  3156,  3180,  3185,  3188,
  3189,  3193,  3196,  3201,  3207,  3210,  3214,  3217,  3222,  3224,
  3229,  3232,  3236,  3239,  3243,  3247,  3249,  3251,  3253,  3255,
  3257,  3259,  3261,  3263,  3265,  3268,  3270,  3272,  3275,  3277,
  3280,  3282,  3285,  3287,  3290,  3292,  3295,  3298,  3300,  3304,
  3308,  3311,  3313,  3315,  3317,  3319,  3321,  3323,  3327,  3330,
  3332,  3338,  3341,  3343,  3345,  3346,  3347,  3350,  3353,  3355,
  3356,  3359,  3361,  3364,  3369,  3372,  3376,  3378,  3381,  3383,
  3386,  3388,  3393,  3403,  3415,  3421,  3435,  3444,  3451,  3453,
  3457,  3457,  3462,  3484,  3484,  3490,  3492,  3500,  3503,  3510,
  3512,  3515,  3517,  3520,  3522,  3530,  3538,  3541,  3550,  3556,
  3571,  3581,  3584,  3589,  3592,  3595,  3610,  3613,  3619,  3621,
  3623,  3627,  3629,  3631,  3633,  3636,  3640,  3645,  3648,  3652,
  3654,  3656,  3658,  3660,  3664,  3674,  3679,  3681,  3685,  3688,
  3692,  3694,  3700,  3702,  3703,  3709,  3722,  3725,  3728,  3731,
  3733,  3737,  3739,  3741,  3743,  3747,  3751
};

static const char * const yytname[] = {   "$",
"error","$illegal.","IDENTIFIER","AND","ARRAY","BEGIN","CASE","CONST","DIV","DO",
"DOWNTO","ELSE","END","FILE_","FOR","FUNCTION","GOTO","IF","IN","LABEL",
"MOD","NIL","NOT","OF","OR","PACKED","PROCEDURE","PROGRAM","RECORD","REPEAT",
"SET","THEN","TO","TYPE","UNTIL","VAR","WHILE","WITH","AND_THEN","BINDABLE",
"EXPORT","IMPORT","MODULE","ONLY","OR_ELSE","OTHERWISE","POW","RESTRICTED","PROTECTED","QUALIFIED",
"VALUE","OP_ABSTRACT","OP_CLASS","OP_CONSTRUCTOR","OP_DESTRUCTOR","OP_INHERITED","OP_IS","OP_PROPERTY","OP_VIEW","RENAME",
"SYMMETRIC_DIFF","STRING_SCHEMA","D_IMPLEMENTATION","D_INTERFACE","D_FORWARD","D_C","D_C_LANGUAGE","D_EXTERN","D_EXTERNAL","D_OVERRIDE",
"r_WRITE","r_READ","r_INITFDR","r_LAZYGET","r_COLLECT","r_POW","r_EXPON","z_ARCTAN","z_COS","z_EXP",
"z_LN","z_SIN","z_SQRT","z_POW","z_EXPON","p_INPUT","p_OUTPUT","p_REWRITE","p_RESET","p_PUT",
"p_GET","p_WRITE","p_READ","p_WRITELN","p_READLN","p_PAGE","p_NEW","p_DISPOSE","p_ABS","p_SQR",
"p_SIN","p_COS","p_EXP","p_LN","p_SQRT","p_ARCTAN","p_TRUNC","p_ROUND","p_PACK","p_UNPACK",
"p_ORD","p_CHR","p_SUCC","p_PRED","p_ODD","p_EOF","p_EOLN","p_MAXINT","p_TRUE","p_FALSE",
"p_EXTEND","p_UPDATE","p_SEEKWRITE","p_SEEKREAD","p_SEEKUPDATE","p_READSTR","p_WRITESTR","p_BIND","p_UNBIND","p_HALT",
"p_GETTIMESTAMP","p_ARG","p_RE","p_IM","p_CARD","p_CMPLX","p_POLAR","p_EMPTY","p_POSITION","p_LASTPOSITION",
"p_LENGTH","p_INDEX","p_SUBSTR","p_TRIM","p_EQ","p_LT","p_GT","p_NE","p_LE","p_GE",
"p_BINDING","p_DATE","p_TIME","p_MAXCHAR","p_MAXREAL","p_MINREAL","p_EPSREAL","STANDARD_OUTPUT","STANDARD_INPUT","op_COPY",
"op_NULL","op_ROOT","op_SELF","op_TEXTWRITABLE","ASM","BREAK","CONTINUE","p_MARK","p_RELEASE","RETURN",
"DEFAULT","OTHERS","p_CLOSE","SIZEOF","ALIGNOF","ANDAND","CONJUGATE","p_DEFINESIZE","INLINE","EXTERNAL",
"VOLATILE","STATIC","G_CONST","TQ_BYTE","TQ_SHORT","TQ_LONG","TQ_LONGLONG","TQ_UNSIGNED","UNSIGNED_INTEGER","STRING_LITERAL",
"CHAR_LITERAL","UNSIGNED_REAL","GTE","LTE","NEQ","EXPON","ASSIGN","LBRACKET","RBRACKET","TWODOTS",
"ELLIPSIS","'<'","'='","'>'","'-'","'+'","'/'","'*'","'.'","'('",
"','","')'","'^'","'@'","':'","'&'","';'","'['","']'","pascal_program",
"program_component_list","program_component","dot_or_error","main_program_declaration","@1","@2","@3","@4","program_heading","@5",
"optional_par_id_list","par_id_list","id_list","typename","identifier","new_identifier","import_or_any_declaration_part","@6","any_declaration_part","any_decl_list",
"any_decl","simple_decl","label_declaration_part","label_list","label","constant_definition_part","constant_definition_list","constant_definition","constant","number",
"unsigned_number","sign","constant_literal","predefined_literal","string","type_definition_part","type_definition_list","type_definition","type_denoter","optional_type_qualifiers",
"optional_gpc_type_qualifiers","type_denoter_1","new_ordinal_type","enumerated_type","@7","enum_list","enumerator","subrange_type","new_pointer_type","pointer_char",
"pointer_domain_type","function_pointer_domain_type","optional_par_type_list","list_of_parameter_types","comma_or_semi","new_structured_type","unpacked_structured_type","new_string_type","capacity_expression","array_type",
"array_index_list","ordinal_index_type","file_type","direct_access_index_type","set_type","record_type","record_field_list","fixed_part","record_section","variant_part",
"rest_of_variant","variant_selector","variant_list","variant","case_constant_list","one_case_constant","type_inquiry","variable_declaration_part","variable_declaration_list","variable_declaration",
"optional_qualifier_list","storage_qualifier","storage_qualifier_list","value_specification","function_declaration","@8","@9","@10","@11","function_heading",
"optional_inline","directive_or_identifier","directive","optional_retval_def","functiontype","optional_par_formal_parameter_list","@12","parmlist1","formal_parameter_list","formal_parameter",
"optional_protected","parameter_form","conformant_array_schema","packed_conformant_array_schema","unpacked_conformant_array_schema","index_type_specification","index_type_specification_list","statement_part","compound_statement","statement_sequence",
"save_filename","save_lineno","lineno_statement","statement","@13","declaring_statement","unlabelled_statement","structured_statement","with_statement","structured_variable_list",
"structured_variable","conditional_statement","simple_if","@14","THEN_or_error","if_statement","@15","case_statement","@16","OF_or_error",
"case_element_list","case_element","@17","@18","case_default","repetitive_statement","repeat_statement","@19","@20","while_statement",
"@21","@22","DO_or_error","for_statement","@23","@24","@25","@26","for_direction","simple_statement",
"empty_statement","goto_statement","optional_par_actual_parameter_list","@27","r_paren_or_error","actual_parameter_list","actual_parameter","assignment_or_call_statement","variable_or_function_access_maybe_assignment","rest_of_statement",
"assign_operator","standard_function_statement","rts_file_open","optional_filename","optional_par_write_parameter_list","write_actual_parameter_list","write_actual_parameter","rts_proc_onepar","rts_proc_parlist","statement_extensions",
"return_statement","break_statement","continue_statement","asm_statement","asm_qualifier","asm_operands","nonnull_asm_operands","asm_operand","asm_clobbers","variable_access_or_typename",
"index_expression_list","static_expression","boolean_expression","expression","expr_1","simple_expression","or_else","and_then","any_term","term",
"primary","factor","variable_or_function_access","variable_or_function_access_no_id","@28","set_constructor","set_constructor_element_list","member_designator","standard_functions","optional_par_actual_parameter",
"rts_fun_optpar","rts_fun_onepar","rts_fun_twopar","rts_fun_parlist","relational_operator","multiplying_operator","adding_operator","semi","optional_semicolon","optional_colon",
"lbracket","rbracket","pushlevel","pushlevel1","poplevel","poplevel1","setspecs","module_declaration","@29","rest_of_module",
"@30","@31","@32","optional_module_parameters","module_interface","@33","any_module_decl_part","any_module_decl_list","any_module_decl","function_interface_decl",
"optional_directive","module_block","module_constructor","@34","@35","@36","optional_initialization_order","module_destructor","@37","@38",
"optional_init_and_final_part","export_part_list","export_part","optional_equal_sign","export_list","export_list_item","rest_of_export_item","optional_rename","import_part","import_specification_list",
"import_specification","optional_access_qualifier","optional_import_qualifier","import_clause_list","import_clause",""
};
#endif

static const short yyr1[] = {     0,
   220,   220,   221,   221,   222,   222,   223,   223,   225,   226,
   227,   228,   224,   229,   230,   229,   231,   231,   232,   233,
   233,   233,   233,   233,   234,   235,   236,   236,   236,   236,
   236,   236,   236,   236,   236,   236,   236,   236,   236,   236,
   236,   236,   236,   236,   236,   236,   236,   236,   236,   236,
   236,   236,   236,   236,   236,   236,   236,   236,   236,   236,
   236,   236,   236,   236,   236,   236,   236,   236,   236,   236,
   236,   236,   236,   236,   236,   236,   236,   236,   236,   236,
   236,   236,   236,   236,   236,   236,   236,   236,   236,   236,
   236,   236,   236,   236,   236,   236,   236,   236,   236,   236,
   236,   236,   236,   236,   236,   236,   236,   236,   236,   236,
   236,   236,   236,   236,   236,   236,   236,   236,   236,   236,
   236,   236,   236,   236,   236,   236,   236,   236,   236,   236,
   236,   236,   236,   236,   236,   236,   236,   236,   236,   236,
   236,   236,   236,   236,   236,   236,   236,   236,   236,   238,
   237,   237,   239,   239,   240,   240,   241,   241,   242,   242,
   242,   242,   243,   243,   244,   244,   244,   244,   244,   244,
   245,   245,   246,   246,   246,   247,   247,   247,   248,   249,
   249,   249,   249,   250,   250,   251,   251,   251,   251,   251,
   251,   251,   252,   252,   253,   253,   253,   254,   254,   254,
   255,   255,   256,   256,   257,   257,   257,   257,   257,   257,
   258,   259,   259,   260,   260,   260,   260,   261,   261,   261,
   261,   261,   261,   262,   262,   262,   262,   262,   263,   263,
   265,   264,   264,   266,   266,   266,   266,   266,   266,   267,
   268,   269,   270,   270,   271,   271,   272,   272,   273,   273,
   273,   273,   274,   274,   274,   275,   275,   276,   276,   277,
   277,   277,   277,   278,   279,   279,   280,   281,   281,   281,
   281,   281,   281,   282,   282,   283,   284,   284,   285,   285,
   286,   286,   287,   287,   287,   287,   288,   288,   288,   288,
   288,   289,   290,   291,   291,   292,   292,   292,   293,   293,
   293,   293,   293,   294,   295,   295,   295,   295,   295,   296,
   296,   296,   296,   297,   298,   298,   299,   299,   299,   299,
   299,   300,   301,   301,   302,   302,   302,   303,   303,   304,
   304,   305,   306,   307,   308,   309,   305,   310,   310,   311,
   311,   312,   312,   313,   313,   313,   313,   313,   314,   314,
   315,   315,   315,   317,   316,   318,   318,   318,   318,   318,
   319,   319,   319,   319,   320,   320,   320,   320,   320,   321,
   321,   322,   322,   322,   323,   323,   324,   325,   326,   327,
   327,   327,   327,   328,   329,   330,   330,   330,   330,   331,
   332,   333,   335,   334,   334,   334,   334,   336,   337,   337,
   338,   338,   338,   338,   339,   340,   340,   340,   340,   340,
   341,   342,   342,   344,   343,   345,   345,   347,   346,   346,
   349,   348,   350,   350,   351,   351,   351,   351,   351,   353,
   352,   354,   352,   355,   355,   355,   356,   356,   356,   358,
   359,   357,   361,   362,   360,   363,   363,   365,   366,   364,
   367,   368,   364,   369,   369,   369,   370,   370,   370,   370,
   370,   371,   372,   372,   373,   374,   373,   375,   375,   376,
   376,   376,   376,   377,   378,   379,   379,   380,   380,   381,
   381,   382,   382,   382,   382,   382,   382,   382,   382,   382,
   383,   383,   383,   384,   384,   385,   385,   386,   386,   386,
   386,   386,   387,   387,   387,   388,   388,   388,   388,   388,
   388,   388,   388,   388,   389,   389,   389,   389,   389,   389,
   389,   389,   389,   389,   390,   390,   390,   390,   391,   391,
   392,   393,   394,   394,   394,   394,   395,   396,   396,   397,
   397,   398,   399,   399,   400,   400,   401,   401,   401,   401,
   401,   402,   403,   404,   405,   405,   405,   406,   406,   406,
   406,   407,   407,   408,   408,   409,   409,   410,   410,   410,
   410,   410,   411,   411,   411,   411,   412,   412,   412,   412,
   412,   412,   412,   412,   412,   412,   412,   412,   413,   413,
   414,   414,   414,   414,   414,   415,   414,   416,   417,   417,
   417,   417,   417,   417,   418,   418,   419,   419,   419,   419,
   420,   420,   421,   421,   422,   422,   422,   422,   422,   422,
   422,   422,   422,   422,   422,   422,   422,   422,   422,   422,
   422,   422,   422,   422,   422,   422,   422,   422,   422,   423,
   423,   423,   423,   423,   423,   423,   423,   423,   424,   424,
   424,   425,   425,   425,   425,   425,   425,   426,   426,   426,
   426,   427,   427,   428,   429,   429,   430,   430,   431,   431,
   432,   432,   433,   434,   435,   436,   437,   439,   438,   441,
   440,   440,   442,   440,   443,   440,   444,   446,   445,   447,
   447,   448,   448,   449,   449,   450,   451,   451,   452,   454,
   455,   456,   453,   457,   457,   459,   460,   458,   461,   461,
   461,   462,   462,   462,   462,   462,   463,   464,   464,   465,
   465,   465,   465,   465,   466,   466,   467,   467,   468,   468,
   469,   469,   470,   470,   470,   471,   472,   472,   473,   473,
   473,   474,   474,   474,   474,   474,   475
};

static const short yyr2[] = {     0,
     0,     1,     1,     2,     2,     2,     1,     1,     0,     0,
     0,     0,    10,     3,     0,     4,     0,     1,     3,     1,
     3,     3,     3,     2,     1,     1,     1,     1,     1,     1,
     1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
     1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
     1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
     1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
     1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
     1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
     1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
     1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
     1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
     1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
     1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
     1,     1,     1,     1,     1,     1,     1,     1,     1,     0,
     5,     1,     0,     1,     1,     2,     1,     1,     1,     1,
     1,     1,     3,     2,     1,     3,     1,     3,     3,     2,
     1,     1,     2,     2,     3,     1,     2,     1,     4,     1,
     2,     1,     1,     2,     1,     1,     1,     1,     1,     1,
     1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
     1,     2,     3,     2,     1,     3,     1,     3,     3,     2,
     4,     2,     2,     1,     2,     2,     1,     0,     1,     1,
     1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
     0,     5,     3,     1,     3,     1,     3,     3,     2,     1,
     3,     2,     1,     1,     1,     1,     2,     4,     0,     3,
     5,     3,     1,     3,     2,     1,     1,     2,     1,     1,
     1,     1,     1,     2,     3,     3,     6,     1,     3,     1,
     3,     3,     2,     1,     1,     4,     0,     3,     3,     3,
     3,     3,     0,     2,     3,     1,     1,     3,     3,     3,
     2,     4,     5,     1,     7,     3,     3,     1,     1,     3,
     3,     1,     2,     5,     1,     3,     3,     3,     2,     1,
     3,     3,     3,     3,     3,     2,     1,     3,     1,     3,
     3,     5,     0,     1,     1,     1,     1,     1,     2,     0,
     2,     4,     0,     0,     0,     0,    11,     4,     6,     0,
     1,     1,     1,     1,     1,     1,     1,     1,     0,     2,
     0,     2,     1,     0,     2,     0,     3,     5,     3,     3,
     1,     3,     3,     3,     4,     5,     1,     4,     5,     0,
     1,     1,     1,     1,     1,     1,     7,     6,     5,     1,
     3,     3,     3,     1,     5,     1,     3,     3,     3,     0,
     0,     3,     0,     6,     1,     1,     1,     6,     1,     1,
     1,     1,     1,     1,     4,     1,     3,     1,     3,     3,
     1,     1,     1,     0,     5,     1,     1,     0,     4,     1,
     0,     7,     1,     1,     1,     3,     1,     3,     3,     0,
     4,     0,     4,     1,     1,     1,     1,     1,     1,     0,
     0,     6,     0,     0,     6,     1,     1,     0,     0,    10,
     0,     0,     8,     1,     1,     1,     1,     1,     1,     1,
     1,     0,     2,     3,     0,     0,     4,     1,     1,     1,
     3,     1,     3,     1,     2,     1,     1,     0,     2,     1,
     1,     2,     5,     4,     4,     4,     2,     2,     4,     4,
     1,     1,     1,     0,     2,     0,     3,     1,     3,     1,
     3,     3,     1,     3,     5,     1,     1,     1,     1,     1,
     1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
     1,     1,     1,     1,     1,     1,     1,     1,     1,     2,
     1,     1,     5,     7,     9,    11,     0,     0,     1,     1,
     3,     4,     1,     3,     1,     1,     1,     3,     1,     3,
     3,     1,     1,     1,     3,     3,     1,     1,     3,     3,
     3,     2,     1,     2,     1,     2,     1,     1,     3,     3,
     3,     3,     1,     3,     3,     3,     1,     1,     1,     1,
     3,     2,     1,     2,     2,     4,     4,     4,     1,     1,
     1,     1,     3,     3,     4,     0,     5,     3,     0,     1,
     3,     1,     3,     3,     1,     3,     4,     6,     2,     4,
     0,     3,     1,     1,     1,     1,     1,     1,     1,     1,
     1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
     1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
     1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
     1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
     1,     1,     1,     1,     0,     1,     0,     1,     1,     1,
     1,     1,     0,     0,     1,     0,     0,     0,     4,     0,
     5,     3,     0,     4,     0,     4,     2,     0,     7,     0,
     1,     1,     2,     1,     1,     3,     0,     2,     3,     0,
     0,     0,    11,     0,     1,     0,     0,     9,     0,     2,
     1,     1,     3,     1,     3,     3,     5,     0,     1,     1,
     3,     1,     3,     3,     2,     3,     1,     2,     0,     2,
     0,     3,     1,     3,     3,     3,     0,     1,     0,     3,
     4,     1,     3,     1,     3,     3,     2
};

static const short yydefact[] = {     1,
     0,     0,     2,     3,     0,     0,     0,    15,    27,   124,
   125,   126,   127,   128,   129,   130,   131,   132,   133,   123,
   134,   135,   136,   137,   138,   139,   140,   141,   142,   143,
    81,   101,   102,   103,   104,   105,   107,   106,   144,    35,
    36,    37,    38,    39,    40,    41,    42,    43,    44,    45,
    54,    55,    56,    57,    58,    59,    60,    61,    62,    63,
    67,    68,    69,    70,    74,    75,    76,    77,    78,    79,
    80,    28,    29,    30,    46,    47,    48,    49,    50,    82,
    83,    94,    95,    97,    98,    64,    65,    66,    71,    72,
    73,    51,    52,    53,    84,    85,    86,    87,    88,    89,
    90,    91,    92,    93,    96,    99,   100,    31,    32,    33,
    34,   121,   122,   145,   146,   147,   149,   148,   108,   110,
   111,   114,   116,   117,   113,   115,   112,   118,   109,   119,
   120,    17,   678,     4,     8,     7,     5,   664,     9,     6,
    17,     0,    14,    18,    17,   674,    16,     0,    20,     0,
    17,     0,   679,   340,    10,    24,     0,   468,    19,   683,
     0,   687,     0,     0,     0,     0,   688,     0,   341,   685,
   152,   154,   155,   157,   159,   160,   161,   162,   158,     0,
     0,     0,   340,    22,    23,    21,   153,   682,   178,     0,
   173,   176,   174,   167,   171,   172,     0,   165,   164,   207,
     0,     0,   205,   204,   319,     0,     0,   317,   316,     0,
   737,     0,   733,     0,   156,   333,     0,     0,   680,    11,
   709,   684,   175,     0,   177,   170,     0,   163,   218,   210,
     0,    24,   323,     0,     0,   714,   718,     0,   712,   738,
   739,     0,   150,   686,   343,   344,   345,   346,   348,   347,
   674,     0,   342,   354,   354,   153,     0,     0,     0,   711,
     0,    26,   198,     0,   592,   591,   615,   616,   617,   618,
   619,   620,   621,   622,   626,   627,   629,   630,   649,   650,
   631,   613,   614,   188,   200,   199,   623,   624,   625,   628,
   640,   641,   632,   633,   634,   635,   642,   651,   636,   643,
   644,   645,   646,   647,   648,   637,   638,   639,   192,   189,
   190,   191,     0,     0,     0,     0,   186,   201,   196,   187,
   670,   194,   193,     0,     0,   669,   589,   579,     0,   578,
   197,   195,     0,   552,   554,   557,   558,   567,   568,   573,
   577,   590,   580,   583,   611,     0,     0,     0,     0,   168,
   169,   166,   218,   217,   219,   220,   221,   222,   223,   330,
     0,   214,   208,   209,   206,   325,   327,   326,   218,   328,
   324,   320,   321,   318,   719,     0,     0,     0,     0,     0,
   736,   735,   153,   734,   334,   332,   349,   356,   338,   681,
   673,    12,   384,   704,     0,     0,   710,   699,   582,     0,
     0,   585,     0,     0,   584,   596,   566,   202,   179,     0,
     0,   563,   654,   653,   652,   656,   655,   657,   662,   663,
     0,     0,     0,     0,   658,   659,   565,     0,   660,   661,
     0,     0,     0,     0,     0,     0,   243,   244,   465,     0,
     0,   609,     0,     0,     0,   602,   605,     0,   600,   216,
   215,     0,   211,    25,     0,   277,     0,     0,     0,     0,
     0,     0,   212,   180,     0,   182,   185,     0,   183,   213,
   224,   229,   230,   225,     0,   226,   259,   227,   260,   261,
   262,   263,   228,   330,   329,     0,   715,   716,   127,   713,
   340,     0,   744,   729,     0,   742,   151,   340,     0,     0,
     0,   355,   390,   676,   705,     0,   706,    26,     0,     0,
   590,     0,     0,   581,     0,   556,   562,   560,   561,   555,
   559,   564,   571,   570,   572,   569,   574,   576,   575,   593,
   466,   594,   549,     0,   547,     0,   474,     0,     0,   472,
     0,   470,     0,     0,   672,     0,   671,   598,   331,     0,
     0,     0,   258,     0,     0,     0,     0,   287,   286,     0,
     0,     0,     0,   264,     0,     0,   231,     0,   181,   184,
   249,   249,   245,   242,   246,   322,   722,   123,   729,     0,
   720,     0,   694,     0,     0,   340,   692,   695,     0,     0,
   747,     0,     0,   740,   335,   350,   353,     0,   339,     0,
   371,     0,   367,     0,   361,     0,     0,   391,   386,    13,
   700,   674,   587,   588,   586,     0,     0,     0,     0,   595,
   612,   607,     0,     0,   610,   606,   603,   604,   601,   270,
   275,   274,     0,   268,   218,     0,   282,    27,   298,     0,
     0,   281,   677,   664,     0,   284,     0,   280,   279,   314,
     0,     0,   233,     0,   241,     0,     0,   247,   729,     0,
   725,   727,     0,     0,   717,   732,   697,   689,   693,   741,
   730,   745,   746,   743,     0,    25,   352,   360,   359,   370,
   357,     0,     0,     0,     0,   390,     0,     0,   675,     0,
   674,     0,   469,   597,     0,   550,   551,   548,     0,   473,
   471,   273,     0,     0,   276,   278,     0,     0,     0,   289,
   290,   288,   285,   218,   265,   266,   236,   240,     0,   234,
     0,   253,     0,     0,   726,   728,   723,   724,   721,     0,
   696,     0,   363,   364,   362,     0,     0,     0,   388,   389,
   387,   385,   397,    26,     0,     0,     0,     0,   440,     0,
   443,     0,   592,   591,    37,    38,    39,    40,    41,    42,
   496,   465,    45,    54,    55,    69,    70,    46,    47,    48,
    49,    50,    82,    83,    94,    95,   611,    98,   108,   531,
   532,   114,   116,   529,   112,   120,   476,     0,   401,   392,
   396,   395,   399,   402,   403,   420,   412,   413,   404,   437,
   438,   439,   400,   457,   458,   459,   478,   460,     0,     0,
     0,   461,   525,   527,   526,   528,   477,   701,     0,   467,
   608,   271,   272,   269,   218,   297,   296,   302,     0,   299,
     0,   305,     0,   292,   239,     0,   232,   250,   255,   256,
   252,     0,   257,   248,   698,   336,   358,     0,     0,     0,
   374,   372,   373,   365,   368,   375,   376,     0,     0,     0,
   463,     0,   553,   390,     0,     0,   408,     0,   406,   411,
     0,     0,   487,   488,     0,     0,   482,     0,   530,   393,
   418,   480,   481,   475,     0,     0,     0,     0,     0,   707,
   267,   303,   293,     0,   294,   309,     0,     0,     0,     0,
   237,   238,   235,     0,   254,   676,   366,   369,     0,     0,
   424,   423,   421,     0,     0,   464,   417,   416,   414,     0,
   323,   444,     0,   390,     0,     0,   500,   503,     0,   498,
     0,     0,     0,     0,   390,   390,   479,   494,     0,     0,
     0,   676,   301,   436,   434,   435,   300,   667,   308,   307,
   306,   677,   312,   313,   311,   251,   337,     0,   380,     0,
     0,     0,   451,     0,   390,   441,   218,     0,   409,   405,
   407,   410,     0,   469,     0,   486,   497,   490,   489,     0,
   391,   419,     0,     0,   484,   485,   702,   708,   668,     0,
     0,     0,     0,     0,     0,     0,   427,     0,     0,   425,
   667,     0,   456,   455,   454,     0,   415,     0,   330,   447,
   446,   390,   504,   501,   502,   499,   533,   538,   462,   495,
   483,   676,   677,   304,     0,   382,   383,   381,   218,     0,
   430,     0,     0,     0,   432,   452,   448,   442,   398,   445,
     0,     0,     0,   539,   540,   491,   492,   506,   507,     0,
   515,   496,   465,   508,   516,   517,   518,   519,   493,   512,
   522,   521,   523,     0,     0,   520,   514,   611,   513,   537,
   531,   532,   509,   510,   529,   511,   524,   394,   703,     0,
     0,   378,   218,   390,   428,   429,   426,   422,   390,   390,
     0,   505,     0,   534,   538,     0,   665,   379,   377,   431,
   433,   453,   449,     0,     0,   541,   666,   295,   390,   542,
   535,     0,   450,   543,     0,     0,   536,   544,     0,     0,
     0
};

static const short yydefgoto[] = {  1119,
     3,     4,   137,     5,   146,   183,   257,   504,     6,   141,
   152,   144,   206,   631,   327,   149,   221,   383,   171,   172,
   173,   174,   175,   197,   788,   176,   191,   192,   465,   466,
   328,   329,   330,   331,   332,   177,   202,   203,   360,   361,
   362,   470,   632,   472,   654,   719,   720,   473,   474,   439,
   574,   575,   657,   723,   842,   476,   477,   478,   564,   479,
   633,   634,   480,   551,   481,   482,   556,   557,   558,   559,
   893,   641,   829,   830,   831,   832,   853,   178,   207,   208,
   369,   370,   371,   453,   179,   251,   498,   675,   906,   180,
   181,   252,   253,   500,   599,   387,   388,   502,   604,   605,
   606,   854,   855,   856,   857,   959,   960,   392,   789,   607,
   608,   690,   609,   790,   935,   791,   792,   793,   794,   868,
   869,   795,   796,   965,   919,   797,   936,   798,   962,   913,
   999,  1000,  1084,  1089,  1001,   799,   800,   864,  1008,   801,
   866,   968,  1012,   802,  1091,  1109,  1002,  1090,  1006,   803,
   804,   805,   874,   617,   159,   541,   542,   806,   807,   884,
   885,   808,   809,   984,   873,   929,   930,   810,   811,   812,
   813,   814,   815,   816,   878,  1043,  1044,  1045,  1115,   509,
   534,   833,   862,   537,   335,   336,   421,   431,   337,   338,
   339,   340,   341,   342,   515,   343,   448,   449,   344,   877,
   345,   346,   347,   348,   422,   432,   423,   687,   646,   990,
   349,   548,   503,   155,   688,   610,   560,     7,   145,   153,
   256,   187,   214,   154,   182,   210,   585,   586,   587,   588,
   731,   222,   259,   691,   889,  1022,   506,   260,   612,   942,
   261,   238,   239,   376,   580,   581,   661,   591,   491,   212,
   213,   241,   381,   495,   496
};

static const short yypact[] = {   161,
  7318,  9617,   161,-32768,    77,  -160,    77,-32768,-32768,-32768,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,  -145,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
  -145,  9617,-32768,-32768,   -14,-32768,-32768,    27,-32768,  -160,
  -145,  -160,-32768,   502,-32768,  5193,  7496,-32768,-32768,-32768,
   107,-32768,  3702,  3523,  3881,  4060,-32768,  9617,-32768,-32768,
-32768,   600,-32768,-32768,-32768,-32768,-32768,-32768,-32768,  -160,
    71,  -160,   445,-32768,-32768,-32768,   533,-32768,  -160,     5,
  9617,-32768,-32768,-32768,-32768,-32768,    95,-32768,-32768,-32768,
    24,    58,-32768,-32768,-32768,   105,    66,-32768,-32768,  7674,
   138,    67,-32768,   206,-32768,   490,  9617,  9617,-32768,-32768,
   166,-32768,-32768,  4701,-32768,  6068,  5895,-32768,   396,  9617,
  6246,  9617,   390,  9617,  6425,-32768,   104,    94,-32768,-32768,
   -10,  9617,  9617,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,  -160,-32768,-32768,-32768,   533,   318,   377,   303,-32768,
   361,-32768,-32768,  5013,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,   168,   187,  6068,   191,-32768,-32768,-32768,-32768,
-32768,-32768,-32768,  4701,   431,-32768,   240,-32768,  5013,-32768,
-32768,   274,  -160,-32768,-32768,   444,-32768,   387,-32768,   -15,
   307,-32768,-32768,-32768,   266,   276,   296,   304,   896,-32768,
-32768,-32768,    -9,-32768,-32768,-32768,-32768,-32768,-32768,   466,
   653,-32768,-32768,-32768,-32768,-32768,-32768,-32768,   396,-32768,
   390,-32768,-32768,-32768,-32768,   329,  9617,  6604,   335,  7852,
-32768,-32768,   600,-32768,-32768,-32768,   345,   351,-32768,-32768,
-32768,-32768,-32768,   515,   556,   555,-32768,-32768,-32768,    52,
    52,-32768,  4701,   364,-32768,-32768,   387,-32768,-32768,  4701,
  4389,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
  4701,  4701,  4701,  4857,-32768,-32768,-32768,  5013,-32768,-32768,
  5013,  5013,  5013,  5013,  5013,  9617,-32768,-32768,   363,  1367,
  4701,-32768,  4701,  4701,  1524,-32768,   379,    25,-32768,-32768,
-32768,  4701,-32768,   385,   -61,   -61,   478,  6962,   564,   569,
   -38,  8030,-32768,-32768,   411,-32768,-32768,   340,-32768,-32768,
-32768,-32768,-32768,-32768,  9271,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,-32768,   466,-32768,  8208,-32768,-32768,  9617,-32768,
   660,  7852,-32768,   536,   106,-32768,-32768,   186,  9617,    36,
  5716,-32768,-32768,-32768,-32768,   607,-32768,   407,   416,   307,
   423,   432,   433,-32768,  1524,     6,-32768,-32768,-32768,     6,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,-32768,    35,-32768,   439,-32768,   440,   412,-32768,
   209,-32768,  4701,  4701,-32768,  1681,-32768,-32768,-32768,   408,
   633,  5366,-32768,   647,  9790,   648,    59,-32768,-32768,  9617,
   758,  4701,  4701,-32768,  4701,   452,-32768,  4701,-32768,-32768,
   464,   464,-32768,-32768,-32768,-32768,-32768,  9617,   -17,   133,
-32768,    67,-32768,  -160,   663,   675,-32768,-32768,   141,  9617,
-32768,  9617,  8386,-32768,-32768,-32768,-32768,   682,-32768,   474,
-32768,   480,-32768,    87,-32768,  9444,    40,-32768,-32768,-32768,
-32768,-32768,-32768,-32768,-32768,   145,  1524,  4701,  1838,-32768,
-32768,-32768,  4701,  1995,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,    70,-32768,   396,   -58,-32768,   669,-32768,    98,
   673,-32768,    78,    20,  7140,-32768,   108,-32768,-32768,-32768,
   486,   -58,-32768,  8564,-32768,    86,   484,-32768,   536,  9617,
-32768,-32768,  9963,  8742,-32768,  9617,   490,-32768,-32768,-32768,
-32768,-32768,-32768,-32768,   318,-32768,-32768,-32768,-32768,   368,
-32768,  6783,   499,  9617,   115,-32768,  3160,   690,-32768,  2976,
-32768,  3344,-32768,-32768,   145,-32768,-32768,-32768,   496,-32768,
-32768,  5366,   766,   689,-32768,-32768,   682,   682,  2152,-32768,
-32768,-32768,-32768,   396,-32768,-32768,-32768,-32768,   148,-32768,
   505,-32768,    80,   682,-32768,-32768,-32768,-32768,-32768,  -160,
-32768,  -160,-32768,-32768,-32768,   507,   117,   420,-32768,-32768,
-32768,-32768,-32768,   509,  4701,   431,  5538,  4701,-32768,  9617,
-32768,    83,   510,   511,   518,   519,   520,   521,   522,   523,
   -63,   183,   525,   527,   530,   535,   537,   538,   539,   540,
   542,   544,   545,   546,   548,   550,   214,   552,   553,   528,
   549,   558,   560,  4545,   565,   566,   257,   551,-32768,-32768,
-32768,-32768,-32768,-32768,-32768,   753,-32768,-32768,-32768,-32768,
-32768,-32768,-32768,-32768,-32768,-32768,   -95,-32768,   567,   568,
   571,-32768,-32768,-32768,-32768,-32768,   492,-32768,  -160,-32768,
-32768,-32768,-32768,-32768,   396,-32768,-32768,-32768,    84,-32768,
   120,-32768,   110,-32768,  9617,  8920,-32768,-32768,-32768,-32768,
-32768,   126,-32768,-32768,-32768,-32768,-32768,   420,   -61,   769,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,    91,    16,  4701,
-32768,    51,-32768,-32768,   123,  4701,-32768,    53,-32768,   307,
  2309,  2309,-32768,-32768,  1524,  2309,-32768,   572,-32768,-32768,
-32768,-32768,-32768,-32768,  4701,  4701,  4701,  1524,  3344,-32768,
-32768,  4701,-32768,  4233,-32768,  4701,  2466,   573,  4701,  2623,
-32768,-32768,-32768,   574,-32768,-32768,-32768,-32768,  9617,   -61,
-32768,-32768,-32768,  4701,  4701,-32768,-32768,-32768,-32768,    45,
   390,-32768,   128,-32768,   128,   783,-32768,   570,   152,-32768,
   152,   145,   152,   597,-32768,-32768,-32768,   578,    81,   145,
  -160,-32768,-32768,-32768,-32768,-32768,-32768,   575,-32768,-32768,
-32768,   103,-32768,-32768,-32768,-32768,-32768,   591,-32768,    61,
  9617,  1053,     6,    89,-32768,-32768,   396,   192,-32768,-32768,
-32768,-32768,  4701,  4701,  2780,-32768,-32768,-32768,-32768,   216,
-32768,-32768,  4701,    81,-32768,-32768,-32768,-32768,-32768,   582,
   581,  9617,  9617,  9098,   770,   -58,-32768,   131,    92,-32768,
   575,   192,-32768,-32768,-32768,  4701,-32768,  4701,   466,-32768,
-32768,-32768,   580,-32768,-32768,-32768,-32768,   606,  5369,-32768,
-32768,-32768,   103,-32768,   583,-32768,-32768,-32768,   396,   773,
-32768,  4233,  1210,   786,-32768,-32768,-32768,-32768,-32768,-32768,
  4701,   590,   160,   592,-32768,-32768,-32768,-32768,-32768,   522,
-32768,   595,   363,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,-32768,   545,   546,-32768,-32768,   266,-32768,-32768,
-32768,-32768,-32768,-32768,  4701,-32768,-32768,-32768,-32768,   589,
   682,-32768,   396,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
   192,-32768,  4701,-32768,   606,   606,   585,-32768,-32768,-32768,
-32768,-32768,-32768,   594,   227,-32768,-32768,-32768,-32768,-32768,
-32768,   597,-32768,   274,   261,   597,-32768,   274,   811,   812,
-32768
};

static const short yypgoto[] = {-32768,
-32768,   810,   807,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
   -28,-32768,  -138,  -358,  -303,    -1,   -53,-32768,  -339,-32768,
   644,  -446,-32768,-32768,  -157,-32768,-32768,   626,-32768,-32768,
  -300,  -287,  -284,-32768,  -783,-32768,-32768,   270,  -363,-32768,
   465,-32768,   458,-32768,-32768,-32768,  -305,-32768,-32768,   459,
-32768,-32768,   249,-32768,-32768,-32768,   365,-32768,-32768,-32768,
-32768,  -179,-32768,-32768,-32768,-32768,  -888,-32768,  -231,   178,
-32768,-32768,-32768,  -447,  -906,  -295,   463,-32768,-32768,   375,
   -96,   455,-32768,  -472,-32768,-32768,-32768,-32768,-32768,  -130,
-32768,   162,-32768,-32768,-32768,   576,-32768,-32768,-32768,  -223,
-32768,   -20,   -18,-32768,-32768,  -849,-32768,   157,  -238,   -37,
  -102,  -144,  -657,  -654,-32768,-32768,  -183,-32768,-32768,-32768,
  -445,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,  -411,-32768,-32768,   -56,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,  -955,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,   402,-32768,  -592,  -494,  -368,-32768,-32768,-32768,
-32768,-32768,-32768,-32768,-32768,  -722,  -344,-32768,-32768,-32768,
-32768,-32768,-32768,-32768,-32768,  -249,-32768,  -247,-32768,   446,
-32768,  -222,  -826,  -158,  -723,  -402,-32768,-32768,  -216,   524,
   290,   -66,  -390,  -387,-32768,-32768,-32768,    -4,-32768,   506,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,    21,  -586,  -149,
  -336,  -519,-32768,  -242,-32768,  -584,   393,-32768,-32768,-32768,
-32768,-32768,-32768,   705,   696,-32768,-32768,-32768,   275,-32768,
-32768,   604,-32768,-32768,-32768,-32768,-32768,   603,-32768,-32768,
-32768,-32768,   263,-32768,-32768,   -21,-32768,  -531,-32768,   376,
  -226,-32768,-32768,   372,    62
};


#define	YYLAST		10141


static const short yytable[] = {   132,
   133,   333,   463,   148,   440,   484,   198,   516,   385,   510,
   510,   576,   511,   511,   620,   382,   384,   683,   393,   520,
   616,   405,   689,   694,   863,   544,   139,   156,   739,   741,
   411,   433,  -666,   379,   914,   618,   597,   819,   450,   922,
   686,   434,   590,   497,   583,   686,  1036,   662,   150,   151,
   412,   917,  -676,   923,   508,   998,   138,   464,   230,   643,
   467,   993,   924,   991,   142,   334,   234,   242,   350,   352,
   702,  -665,   536,   468,   538,   539,   469,   135,  -291,   966,
   839,   693,   918,   867,   892,   262,   217,   680,   676,  1003,
  -291,   911,  1032,   505,   377,   226,  -665,   218,   707,  1004,
   170,   882,   820,   143,  -665,   232,   592,   883,   232,   555,
   899,   996,   147,   704,   912,   232,   706,   232,   550,   552,
   896,  1005,   695,   232,   565,   998,   998,   725,   676,   220,
   262,   896,   716,   663,  1080,  1103,   321,   265,   266,   583,
   545,   592,   863,  1026,  1028,   693,   872,   167,   835,   931,
   980,   -43,   974,   933,   184,   186,   326,   402,   595,   321,
   547,   190,   196,   201,   569,   404,   211,   570,   265,   266,
   160,   563,   162,   440,   355,   356,   357,   358,   359,   326,
   435,  1038,   660,   193,   199,   204,   209,   240,     1,   190,
   447,  -153,  1010,   163,   518,   142,   639,   399,   258,   380,
   216,  1011,   219,     2,   519,   164,   521,   224,   237,   223,
   419,   420,   915,   265,   266,   254,   255,   228,   244,   165,
  -666,   166,   231,   545,   196,   196,   229,   235,   201,   201,
   184,  -666,   243,   545,   941,   546,  -351,   157,   158,   677,
   211,   211,   895,   547,   513,   619,   464,  -351,   464,   467,
   598,   467,  -351,   547,   699,   701,   138,   464,   378,   545,
   467,   138,   468,   925,   468,   469,   970,   469,   545,   138,
  -665,   705,   386,   468,   138,   644,   469,   138,   982,   547,
   703,   535,   138,   138,   863,   136,   721,  -665,   547,  -291,
   840,   841,   158,   549,  -291,  -665,   138,   722,   681,   510,
   644,   510,   817,   644,   817,   227,   375,  1007,   644,   900,
   138,   138,   708,   196,  -283,   157,   593,   594,   157,   233,
  -310,   957,   714,   391,  -310,   157,   904,   157,  1114,   738,
   897,   848,  1118,   157,   898,   396,   976,   921,   977,   978,
   979,   897,   262,   664,   665,  1031,   985,   986,   826,   827,
   834,   593,   670,   409,  1040,   624,   158,   988,   836,   837,
   584,   870,   975,   158,   169,   844,   527,   528,   529,   692,
   603,  1094,   636,   398,  1095,   237,   237,   400,   494,   852,
   932,   649,   394,  -340,   626,   447,   787,   447,   787,   395,
   424,  1021,   531,   940,  -340,   425,   401,   -44,   464,   464,
   403,   467,   467,   650,   651,   408,   652,   426,   630,   655,
   454,   710,  1034,   712,   468,   468,   601,   469,   469,   624,
   625,   647,   676,   441,   849,   427,  1100,  1017,   -97,   263,
  1018,  1101,  1102,   262,   530,   353,   393,  1079,  1111,   384,
   995,  1112,   859,   354,   943,   850,   947,   428,   818,   406,
  -153,  1113,   163,   460,  -589,   584,   733,   284,   735,   696,
   698,   891,   410,   408,   164,  -589,   406,   685,   411,  -589,
  -589,  1116,  1117,   573,  -589,   441,  1030,   969,   165,   971,
   166,   851,   455,   905,   579,   443,   168,   211,   412,   852,
   494,   456,   245,   309,   310,   311,   312,   596,   510,   363,
   365,   817,   928,   928,   321,   444,   458,   928,   459,   163,
  1108,   963,   909,   445,  -153,   436,   452,   938,   939,   437,
   438,   164,   822,   824,   326,   284,   285,   286,   317,   901,
   903,   320,   870,   440,   870,   165,  1039,   166,   486,   627,
   163,   629,   167,   168,   492,   737,   169,   499,  -340,   603,
   334,   603,   164,   640,   246,   247,   248,   249,   250,  -340,
   501,   309,   310,   311,   312,   507,   165,   395,   166,   366,
   367,   368,   531,   961,   168,   514,   659,   645,   543,   355,
   356,   357,   358,   359,   -26,   787,   858,   561,   671,   861,
   494,   494,   562,   429,   430,   590,   317,   318,   319,   320,
   949,   951,   666,  1009,   667,   928,   928,   163,   372,   374,
   568,   865,   322,   323,  1020,  -340,   611,   462,  -546,   164,
  1085,  1087,   623,   169,   682,   879,  -340,   613,   510,  1014,
  1016,   817,   284,   165,  -545,   166,   413,   414,   415,   487,
   490,   727,   729,   614,   615,   416,   417,   418,   419,   420,
   621,   622,   718,   672,   674,   454,   635,   455,   726,   637,
   642,   579,   579,   653,   211,  1082,   456,   163,   309,   310,
   311,   312,  -690,   656,   263,   668,   953,   955,   457,   164,
   169,   458,   163,   459,   676,   678,   460,  -691,   196,  -590,
   196,   679,   -25,   165,   164,   166,   709,   715,   724,   736,
  -590,   916,   742,   317,  -590,  -590,   320,   821,   165,  -590,
   166,   169,   825,   523,   461,   787,   838,   524,   847,  1099,
   525,   526,  1098,   -27,   -35,   -36,   937,  -491,  -492,  -506,
  -507,   871,  -515,   334,  -508,   334,  -516,   334,   334,  -517,
   334,   334,  -110,   843,  -518,   196,  -519,  -493,  -512,  -522,
   845,  -521,   846,  -523,   875,   876,   964,  -520,   648,  -514,
   454,  -513,  -537,  -111,   881,   880,   823,  -509,   454,  -510,
   284,   285,   286,   910,  -511,  -524,   886,   887,   169,   263,
   888,   934,   952,   972,   973,   956,   318,   263,   983,   989,
   992,  1023,  1024,  1029,  1041,  1042,  1083,  1081,  1088,  1093,
  1097,  1107,  1096,   334,   872,  1110,   309,   310,   311,   312,
  1120,  1121,   134,   140,  1013,   215,   225,   451,   471,   475,
   658,   553,   713,   483,   967,   485,   920,   907,   730,   908,
   389,   732,   981,   718,   718,  1078,  1019,   948,   169,   890,
   532,   317,   318,   319,   320,  1105,   512,  1037,  1106,   894,
   442,  1035,   407,   169,   567,   161,   188,   322,   323,   390,
   669,   397,   462,   589,   582,   437,   438,     0,     0,     0,
     0,     0,     0,   334,   334,   284,   285,   286,     0,     0,
     0,     0,  1092,   284,   285,   286,     0,   196,   926,     0,
     0,     0,     0,     0,     0,     0,   446,     0,   262,     0,
     0,     0,     0,     0,     0,     0,     0,   958,     0,     0,
     0,   309,   310,   311,   312,     0,   879,   263,   264,   309,
   310,   311,   312,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,  1104,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,   317,   318,   319,   320,
     0,     0,     0,     0,   317,   318,   319,   320,     0,   958,
     0,   987,   322,   323,     0,     0,     0,   462,     0,     0,
   322,   323,     0,     0,     0,   462,     0,     0,     0,     0,
   994,   265,   266,     0,     0,     0,     0,     0,     0,     0,
  1025,   958,   958,     0,   267,   268,   269,   270,   271,   272,
   273,   274,   275,   276,     0,     0,   277,   278,   279,   280,
   281,   282,   283,   284,   285,   286,     0,     0,     0,  1033,
     0,     0,     0,     0,     0,     0,     0,   287,   288,   289,
   290,   291,   292,   293,   294,   295,   296,   297,   298,   299,
   300,   301,   302,   303,   304,   305,   306,   307,   308,   309,
   310,   311,   312,   997,     0,   262,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,   313,
   314,   315,   316,     0,   263,   264,     0,     0,     0,     0,
     0,     0,     0,     0,   317,   318,   319,   320,     0,     0,
     0,     0,     0,   321,  -599,     0,     0,     0,   944,     0,
   322,   323,     0,     0,     0,   324,  -599,     0,     0,     0,
     0,   325,     0,   326,  -599,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,   265,   266,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,   267,   268,   269,   270,   271,   272,   273,   274,   275,
   276,     0,     0,   277,   278,   279,   280,   281,   282,   283,
   284,   285,   286,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,   287,   288,   289,   290,   291,   292,
   293,   294,   295,   296,   297,   298,   299,   300,   301,   302,
   303,   304,   305,   306,   307,   308,   309,   310,   311,   312,
  1086,     0,   262,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,   945,   946,     0,   313,   314,   315,   316,
     0,   263,   264,     0,     0,     0,     0,     0,     0,     0,
     0,   317,   318,   319,   320,     0,     0,     0,     0,     0,
   321,     0,     0,     0,     0,   944,     0,   322,   323,     0,
     0,     0,   324,     0,     0,     0,     0,     0,   325,     0,
   326,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,   265,   266,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,   267,   268,
   269,   270,   271,   272,   273,   274,   275,   276,     0,     0,
   277,   278,   279,   280,   281,   282,   283,   284,   285,   286,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,   287,   288,   289,   290,   291,   292,   293,   294,   295,
   296,   297,   298,   299,   300,   301,   302,   303,   304,   305,
   306,   307,   308,   309,   310,   311,   312,   533,     0,   262,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
   945,   946,     0,   313,   314,   315,   316,     0,   263,   264,
     0,     0,     0,     0,     0,     0,     0,     0,   317,   318,
   319,   320,     0,     0,     0,     0,     0,   321,     0,     0,
     0,     0,     0,     0,   322,   323,     0,     0,     0,   324,
     0,     0,     0,     0,     0,   325,     0,   326,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,   265,   266,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,   267,   268,   269,   270,   271,
   272,   273,   274,   275,   276,     0,     0,   277,   278,   279,
   280,   281,   282,   283,   284,   285,   286,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,   287,   288,
   289,   290,   291,   292,   293,   294,   295,   296,   297,   298,
   299,   300,   301,   302,   303,   304,   305,   306,   307,   308,
   309,   310,   311,   312,   540,     0,   262,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
   313,   314,   315,   316,     0,   263,   264,     0,     0,     0,
     0,     0,     0,     0,     0,   317,   318,   319,   320,     0,
     0,     0,     0,     0,   321,     0,     0,     0,     0,     0,
     0,   322,   323,     0,     0,     0,   324,     0,     0,     0,
     0,     0,   325,     0,   326,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,   265,
   266,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,   267,   268,   269,   270,   271,   272,   273,   274,
   275,   276,     0,     0,   277,   278,   279,   280,   281,   282,
   283,   284,   285,   286,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,   287,   288,   289,   290,   291,
   292,   293,   294,   295,   296,   297,   298,   299,   300,   301,
   302,   303,   304,   305,   306,   307,   308,   309,   310,   311,
   312,   628,     0,   262,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,   313,   314,   315,
   316,     0,   263,   264,     0,     0,     0,     0,     0,     0,
     0,     0,   317,   318,   319,   320,     0,     0,     0,     0,
     0,   321,     0,     0,     0,     0,     0,     0,   322,   323,
     0,     0,     0,   324,     0,     0,     0,     0,     0,   325,
     0,   326,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,   265,   266,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,   267,
   268,   269,   270,   271,   272,   273,   274,   275,   276,     0,
     0,   277,   278,   279,   280,   281,   282,   283,   284,   285,
   286,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,   287,   288,   289,   290,   291,   292,   293,   294,
   295,   296,   297,   298,   299,   300,   301,   302,   303,   304,
   305,   306,   307,   308,   309,   310,   311,   312,   697,     0,
   262,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,   313,   314,   315,   316,     0,   263,
   264,     0,     0,     0,     0,     0,     0,     0,     0,   317,
   318,   319,   320,     0,     0,     0,     0,     0,   321,     0,
     0,     0,     0,     0,     0,   322,   323,     0,     0,     0,
   324,     0,     0,     0,     0,     0,   325,     0,   326,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,   265,   266,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,   267,   268,   269,   270,
   271,   272,   273,   274,   275,   276,     0,     0,   277,   278,
   279,   280,   281,   282,   283,   284,   285,   286,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,   287,
   288,   289,   290,   291,   292,   293,   294,   295,   296,   297,
   298,   299,   300,   301,   302,   303,   304,   305,   306,   307,
   308,   309,   310,   311,   312,   700,     0,   262,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,   313,   314,   315,   316,     0,   263,   264,     0,     0,
     0,     0,     0,     0,     0,     0,   317,   318,   319,   320,
     0,     0,     0,     0,     0,   321,     0,     0,     0,     0,
     0,     0,   322,   323,     0,     0,     0,   324,     0,     0,
     0,     0,     0,   325,     0,   326,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
   265,   266,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,   267,   268,   269,   270,   271,   272,   273,
   274,   275,   276,     0,     0,   277,   278,   279,   280,   281,
   282,   283,   284,   285,   286,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,   287,   288,   289,   290,
   291,   292,   293,   294,   295,   296,   297,   298,   299,   300,
   301,   302,   303,   304,   305,   306,   307,   308,   309,   310,
   311,   312,   828,     0,   262,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,   313,   314,
   315,   316,     0,   263,   264,     0,     0,     0,     0,     0,
     0,     0,     0,   317,   318,   319,   320,     0,     0,     0,
     0,     0,   321,     0,     0,     0,     0,     0,     0,   322,
   323,     0,     0,     0,   324,     0,     0,     0,     0,     0,
   325,     0,   326,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,   265,   266,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
   267,   268,   269,   270,   271,   272,   273,   274,   275,   276,
     0,     0,   277,   278,   279,   280,   281,   282,   283,   284,
   285,   286,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,   287,   288,   289,   290,   291,   292,   293,
   294,   295,   296,   297,   298,   299,   300,   301,   302,   303,
   304,   305,   306,   307,   308,   309,   310,   311,   312,   927,
     0,   262,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,   313,   314,   315,   316,     0,
   263,   264,     0,     0,     0,     0,     0,     0,     0,     0,
   317,   318,   319,   320,     0,     0,     0,     0,     0,   321,
     0,     0,     0,     0,     0,     0,   322,   323,     0,     0,
     0,   324,     0,     0,     0,     0,     0,   325,     0,   326,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,   265,   266,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,   267,   268,   269,
   270,   271,   272,   273,   274,   275,   276,     0,     0,   277,
   278,   279,   280,   281,   282,   283,   284,   285,   286,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
   287,   288,   289,   290,   291,   292,   293,   294,   295,   296,
   297,   298,   299,   300,   301,   302,   303,   304,   305,   306,
   307,   308,   309,   310,   311,   312,   950,     0,   262,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,   313,   314,   315,   316,     0,   263,   264,     0,
     0,     0,     0,     0,     0,     0,     0,   317,   318,   319,
   320,     0,     0,     0,     0,     0,   321,     0,     0,     0,
     0,     0,     0,   322,   323,     0,     0,     0,   324,     0,
     0,     0,     0,     0,   325,     0,   326,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,   265,   266,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,   267,   268,   269,   270,   271,   272,
   273,   274,   275,   276,     0,     0,   277,   278,   279,   280,
   281,   282,   283,   284,   285,   286,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,   287,   288,   289,
   290,   291,   292,   293,   294,   295,   296,   297,   298,   299,
   300,   301,   302,   303,   304,   305,   306,   307,   308,   309,
   310,   311,   312,   954,     0,   262,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,   313,
   314,   315,   316,     0,   263,   264,     0,     0,     0,     0,
     0,     0,     0,     0,   317,   318,   319,   320,     0,     0,
     0,     0,     0,   321,     0,     0,     0,     0,     0,     0,
   322,   323,     0,     0,     0,   324,     0,     0,     0,     0,
     0,   325,     0,   326,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,   265,   266,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,   267,   268,   269,   270,   271,   272,   273,   274,   275,
   276,     0,     0,   277,   278,   279,   280,   281,   282,   283,
   284,   285,   286,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,   287,   288,   289,   290,   291,   292,
   293,   294,   295,   296,   297,   298,   299,   300,   301,   302,
   303,   304,   305,   306,   307,   308,   309,   310,   311,   312,
  1015,     0,   262,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,   313,   314,   315,   316,
     0,   263,   264,     0,     0,     0,     0,     0,     0,     0,
     0,   317,   318,   319,   320,     0,     0,     0,     0,     0,
   321,     0,     0,     0,     0,     0,     0,   322,   323,     0,
     0,     0,   324,     0,     0,     0,     0,     0,   325,     0,
   326,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,   265,   266,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,   267,   268,
   269,   270,   271,   272,   273,   274,   275,   276,     0,     0,
   277,   278,   279,   280,   281,   282,   283,   284,   285,   286,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,   287,   288,   289,   290,   291,   292,   293,   294,   295,
   296,   297,   298,   299,   300,   301,   302,   303,   304,   305,
   306,   307,   308,   309,   310,   311,   312,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,   313,   314,   315,   316,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,   317,   318,
   319,   320,     0,     0,     0,     0,   743,   321,   744,     0,
     0,   391,   745,     0,   322,   323,     0,  -462,  -462,   324,
   746,     0,   747,   748,     0,   325,     0,   326,     0,     0,
     0,     0,     0,     0,     0,   749,     0,     0,     0,     0,
  -462,   750,   751,   752,    10,    11,    12,    13,    14,    15,
    16,    17,    18,    19,    20,    21,    22,    23,    24,    25,
    26,    27,    28,    29,    30,     0,     0,    31,    32,    33,
    34,    35,    36,    37,    38,    39,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,   753,   754,   755,   756,   757,   758,   759,   760,   761,
   762,   763,   764,   765,    53,    54,    55,    56,    57,    58,
    59,    60,    61,    62,   766,   767,    65,    66,    67,    68,
    69,    70,    71,    72,    73,    74,   768,   769,   770,   771,
   772,   773,   774,   775,   776,   777,   778,    86,    87,    88,
    89,    90,    91,    92,    93,    94,    95,    96,    97,    98,
    99,   100,   101,   102,   103,   104,   105,   106,   107,   108,
   109,   110,   111,   112,   113,   114,   115,   116,   117,   118,
   779,   780,   781,   782,   783,   784,   125,   126,   785,   128,
   129,     0,   130,   786,     0,     0,     0,     0,     0,     0,
   740,     0,  -390,     0,   195,  -390,  -390,     0,     0,     0,
     0,     0,  -390,     0,  -390,     0,  -390,  -390,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,  -390,
     0,     0,  -462,     0,  -390,  -390,  -390,  -390,  -390,  -390,
  -390,  -390,  -390,  -390,  -390,  -390,  -390,  -390,  -390,  -390,
  -390,  -390,  -390,  -390,  -390,  -390,  -390,  -390,  -390,     0,
     0,  -390,  -390,  -390,  -390,  -390,  -390,  -390,  -390,  -390,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,  -390,  -390,  -390,  -390,  -390,
  -390,  -390,  -390,  -390,  -390,  -390,  -390,  -390,  -390,  -390,
  -390,  -390,  -390,  -390,  -390,  -390,  -390,  -390,  -390,  -390,
  -390,  -390,  -390,  -390,  -390,  -390,  -390,  -390,  -390,  -390,
  -390,  -390,  -390,  -390,  -390,  -390,  -390,  -390,  -390,  -390,
  -390,  -390,  -390,  -390,  -390,  -390,  -390,  -390,  -390,  -390,
  -390,  -390,  -390,  -390,  -390,  -390,  -390,  -390,  -390,  -390,
  -390,  -390,  -390,  -390,  -390,  -390,  -390,  -390,  -390,  -390,
  -390,  -390,  -390,  -390,  -390,  -390,  -390,  -390,  -390,  -390,
  -390,  -390,  -390,  -390,  -390,     0,  -390,  -390,     0,     0,
     0,     0,     0,     0,   743,     0,   744,     0,  -390,   391,
   745,     0,     0,     0,     0,     0,     0,     0,   746,     0,
   747,   748,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,   749,     0,     0,  -390,     0,     0,   750,
   751,   752,    10,    11,    12,    13,    14,    15,    16,    17,
    18,    19,    20,    21,    22,    23,    24,    25,    26,    27,
    28,    29,    30,     0,     0,    31,    32,    33,    34,    35,
    36,    37,    38,    39,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,   753,
   754,   755,   756,   757,   758,   759,   760,   761,   762,   763,
   764,   765,    53,    54,    55,    56,    57,    58,    59,    60,
    61,    62,   766,   767,    65,    66,    67,    68,    69,    70,
    71,    72,    73,    74,   768,   769,   770,   771,   772,   773,
   774,   775,   776,   777,   778,    86,    87,    88,    89,    90,
    91,    92,    93,    94,    95,    96,    97,    98,    99,   100,
   101,   102,   103,   104,   105,   106,   107,   108,   109,   110,
   111,   112,   113,   114,   115,   116,   117,   118,   779,   780,
   781,   782,   783,   784,   125,   126,   785,   128,   129,     0,
   130,   786,     0,   194,     0,     9,     0,     0,     0,     0,
     0,     0,   195,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
  -462,    10,    11,    12,    13,    14,    15,    16,    17,    18,
    19,    20,    21,    22,    23,    24,    25,    26,    27,    28,
    29,    30,     0,     0,    31,    32,    33,    34,    35,    36,
    37,    38,    39,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,    40,    41,
    42,    43,    44,    45,    46,    47,    48,    49,    50,    51,
    52,    53,    54,    55,    56,    57,    58,    59,    60,    61,
    62,    63,    64,    65,    66,    67,    68,    69,    70,    71,
    72,    73,    74,    75,    76,    77,    78,    79,    80,    81,
    82,    83,    84,    85,    86,    87,    88,    89,    90,    91,
    92,    93,    94,    95,    96,    97,    98,    99,   100,   101,
   102,   103,   104,   105,   106,   107,   108,   109,   110,   111,
   112,   113,   114,   115,   116,   117,   118,   119,   120,   121,
   122,   123,   124,   125,   126,   127,   128,   129,     0,   130,
   131,     0,   189,     0,     9,     0,     0,     0,     0,     0,
     0,   195,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,   138,
    10,    11,    12,    13,    14,    15,    16,    17,    18,    19,
    20,    21,    22,    23,    24,    25,    26,    27,    28,    29,
    30,     0,     0,    31,    32,    33,    34,    35,    36,    37,
    38,    39,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,    40,    41,    42,
    43,    44,    45,    46,    47,    48,    49,    50,    51,    52,
    53,    54,    55,    56,    57,    58,    59,    60,    61,    62,
    63,    64,    65,    66,    67,    68,    69,    70,    71,    72,
    73,    74,    75,    76,    77,    78,    79,    80,    81,    82,
    83,    84,    85,    86,    87,    88,    89,    90,    91,    92,
    93,    94,    95,    96,    97,    98,    99,   100,   101,   102,
   103,   104,   105,   106,   107,   108,   109,   110,   111,   112,
   113,   114,   115,   116,   117,   118,   119,   120,   121,   122,
   123,   124,   125,   126,   127,   128,   129,     0,   130,   131,
     0,   200,     0,     9,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,   138,    10,
    11,    12,    13,    14,    15,    16,    17,    18,    19,    20,
    21,    22,    23,    24,    25,    26,    27,    28,    29,    30,
     0,     0,    31,    32,    33,    34,    35,    36,    37,    38,
    39,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,    40,    41,    42,    43,
    44,    45,    46,    47,    48,    49,    50,    51,    52,    53,
    54,    55,    56,    57,    58,    59,    60,    61,    62,    63,
    64,    65,    66,    67,    68,    69,    70,    71,    72,    73,
    74,    75,    76,    77,    78,    79,    80,    81,    82,    83,
    84,    85,    86,    87,    88,    89,    90,    91,    92,    93,
    94,    95,    96,    97,    98,    99,   100,   101,   102,   103,
   104,   105,   106,   107,   108,   109,   110,   111,   112,   113,
   114,   115,   116,   117,   118,   119,   120,   121,   122,   123,
   124,   125,   126,   127,   128,   129,     0,   130,   131,     0,
   205,     0,     9,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,   138,    10,    11,
    12,    13,    14,    15,    16,    17,    18,    19,    20,    21,
    22,    23,    24,    25,    26,    27,    28,    29,    30,     0,
     0,    31,    32,    33,    34,    35,    36,    37,    38,    39,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,    40,    41,    42,    43,    44,
    45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
    55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
    65,    66,    67,    68,    69,    70,    71,    72,    73,    74,
    75,    76,    77,    78,    79,    80,    81,    82,    83,    84,
    85,    86,    87,    88,    89,    90,    91,    92,    93,    94,
    95,    96,    97,    98,    99,   100,   101,   102,   103,   104,
   105,   106,   107,   108,   109,   110,   111,   112,   113,   114,
   115,   116,   117,   118,   119,   120,   121,   122,   123,   124,
   125,   126,   127,   128,   129,   262,   130,   131,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,   263,   264,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,   138,     0,   944,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,   265,   266,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,   267,   268,   269,   270,   271,   272,   273,   274,   275,
   276,     0,     0,   277,   278,   279,   280,   281,   282,   283,
   284,   285,   286,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,   287,   288,   289,   290,   291,   292,
   293,   294,   295,   296,   297,   298,   299,   300,   301,   302,
   303,   304,   305,   306,   307,   308,   309,   310,   311,   312,
     0,   262,     0,     0,     0,     0,     0,     0,     0,     0,
   517,     0,     0,   945,   946,     0,   313,   314,   315,   316,
   263,   264,     0,     0,     0,     0,     0,     0,     0,     0,
     0,   317,   318,   319,   320,     0,     0,     0,     0,     0,
   321,     0,     0,     0,     0,     0,     0,   322,   323,     0,
     0,     0,   324,     0,     0,     0,     0,     0,   325,     0,
   326,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,   265,   266,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,   267,   268,   269,
   270,   271,   272,   273,   274,   275,   276,     0,     0,   277,
   278,   279,   280,   281,   282,   283,   284,   285,   286,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
   287,   288,   289,   290,   291,   292,   293,   294,   295,   296,
   297,   298,   299,   300,   301,   302,   303,   304,   305,   306,
   307,   308,   309,   310,   311,   312,     0,   262,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,   313,   314,   315,   316,   263,   264,     0,     0,
     0,     0,     0,     0,     0,     0,     0,   317,   318,   319,
   320,     0,     0,     0,     0,     0,   321,     0,     0,     0,
     0,     0,     0,   322,   323,     0,     0,     0,   324,     0,
     0,     0,     0,     0,   325,     0,   326,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
   265,   266,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,   267,   268,   269,   270,   271,   272,   273,
   274,   275,   276,     0,     0,   277,   278,   279,   280,   281,
   282,   283,   284,   285,   286,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,   287,   288,   289,   290,
   291,   292,   293,   294,   295,   296,   297,   298,   299,   300,
   301,   302,   303,   304,   305,   306,   307,   308,   309,   310,
   311,   312,     0,   262,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,   313,   314,
   315,   316,   263,   264,     0,     0,     0,     0,     0,     0,
     0,     0,     0,   317,   318,   319,   320,     0,     0,     0,
     0,     0,   321,     0,     0,     0,     0,     0,     0,   322,
   323,     0,     0,     0,   324,     0,     0,     0,     0,  -117,
   325,     0,   326,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,   265,   266,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,   267,
   268,   269,   270,   271,   272,   273,   274,   275,   276,     0,
     0,   277,   278,   279,   280,   281,   282,   283,   284,   285,
   286,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,   287,   288,   289,   290,   291,   292,   293,   294,
   295,   296,   297,   298,   299,   300,   301,   302,   303,   304,
   305,   306,   307,   308,   309,   310,   311,   312,     0,   262,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,   313,   314,   315,   316,   263,   264,
     0,     0,     0,     0,     0,     0,     0,     0,   522,   317,
   318,   319,   320,     0,     0,     0,     0,     0,   321,     0,
     0,     0,     0,     0,     0,   322,   323,     0,     0,     0,
   324,     0,     0,     0,     0,     0,   325,     0,   326,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,   265,   266,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,   267,   268,   269,   270,   271,
   272,   273,   274,   275,   276,     0,     0,   277,   278,   279,
   280,   281,   282,   283,   284,   285,   286,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,   287,   288,
   289,   290,   291,   292,   293,   294,   295,   296,   297,   298,
   299,   300,   301,   302,   303,   304,   305,   306,   307,   308,
   309,   310,   311,   312,     0,   262,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
   313,   314,   315,   316,   263,   264,     0,     0,     0,     0,
     0,     0,     0,     0,     0,   317,   318,   319,   320,     0,
     0,     0,     0,     0,   321,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,   324,     0,     0,     0,
     0,     0,   325,     0,   326,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,   265,   266,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,   267,   268,   269,   270,   271,   272,   273,   274,   275,
   276,     0,     0,   277,   278,   279,   280,   281,   282,   283,
   284,   285,   286,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,   287,   288,   289,   290,   291,   292,
   293,   294,   295,   296,   297,   298,   299,   300,   301,   302,
   303,   304,   305,   306,   307,   308,   309,   310,   311,   312,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,   313,   314,   315,   316,
     0,     0,     0,     0,     0,     9,     0,     0,     0,     0,
     0,   317,   318,   319,   320,     0,     0,     0,     0,     0,
   321,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,   324,     0,     0,     0,     0,     0,   325,     0,
   326,    10,    11,    12,    13,    14,    15,    16,    17,    18,
    19,    20,    21,    22,    23,    24,    25,    26,    27,    28,
    29,    30,     0,     0,    31,    32,    33,    34,    35,    36,
    37,    38,    39,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,    40,    41,
    42,    43,    44,    45,    46,    47,    48,    49,    50,    51,
    52,    53,    54,    55,    56,    57,    58,    59,    60,    61,
    62,    63,    64,    65,    66,    67,    68,    69,    70,    71,
    72,    73,    74,    75,    76,    77,    78,    79,    80,    81,
    82,    83,    84,    85,    86,    87,    88,    89,    90,    91,
    92,    93,    94,    95,    96,    97,    98,    99,   100,   101,
   102,   103,   104,   105,   106,   107,   108,   109,   110,   111,
   112,   113,   114,   115,   116,   117,   118,   119,   120,   121,
   122,   123,   124,   125,   126,   127,   128,   129,   454,   130,
   131,   262,     0,     0,   391,   745,     0,     0,     0,     0,
     0,     0,     0,   746,     0,   747,   748,   263,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,   749,     0,
     0,     0,     0,     0,     0,   751,   752,     0,     0,  -469,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,   265,   266,  1046,  1047,  1048,  1049,
  1050,  1051,  1052,  1053,  1054,  1055,  1056,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,  1057,  1058,     0,
     0,     0,     0,   284,   285,   286,     0,     0,     0,  1059,
  1060,  1061,  1062,  1063,  1064,  1065,  1066,  1067,  1068,  1069,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,   309,
   310,   311,   312,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,  1070,  1071,  1072,  1073,  1074,  1075,     0,
     9,  1076,     0,     0,     0,     0,  1077,     0,     0,     0,
     0,     0,     0,     0,   317,   318,   319,   320,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
   322,   323,     0,     0,     0,   462,    10,    11,    12,    13,
    14,    15,    16,    17,    18,    19,    20,    21,    22,    23,
    24,    25,    26,    27,    28,    29,    30,     0,     0,    31,
    32,    33,    34,    35,    36,    37,    38,    39,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,    40,    41,    42,    43,    44,    45,    46,
    47,    48,    49,    50,    51,    52,    53,    54,    55,    56,
    57,    58,    59,    60,    61,    62,    63,    64,    65,    66,
    67,    68,    69,    70,    71,    72,    73,    74,    75,    76,
    77,    78,    79,    80,    81,    82,    83,    84,    85,    86,
    87,    88,    89,    90,    91,    92,    93,    94,    95,    96,
    97,    98,    99,   100,   101,   102,   103,   104,   105,   106,
   107,   108,   109,   110,   111,   112,   113,   114,   115,   116,
   117,   118,   119,   120,   121,   122,   123,   124,   125,   126,
   127,   128,   129,     0,   130,   131,   600,     0,  -370,     0,
     0,     0,     0,     0,     0,     0,   195,     0,     0,     0,
     0,  -340,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,  -340,     0,     0,   860,     0,     0,     0,     0,
     0,  -370,     0,     0,  -370,  -370,  -370,  -370,  -370,  -370,
  -370,  -370,  -370,  -370,   601,  -370,  -370,  -370,  -370,  -370,
  -370,  -370,  -370,  -370,  -370,     0,     0,  -370,  -370,  -370,
  -370,  -370,  -370,  -370,  -370,  -370,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,  -370,  -370,  -370,  -370,  -370,  -370,  -370,  -370,  -370,
  -370,  -370,  -370,  -370,  -370,  -370,  -370,  -370,  -370,  -370,
  -370,  -370,  -370,  -370,  -370,  -370,  -370,  -370,  -370,  -370,
  -370,  -370,  -370,  -370,  -370,  -370,  -370,  -370,  -370,  -370,
  -370,  -370,  -370,  -370,  -370,  -370,  -370,  -370,  -370,  -370,
  -370,  -370,  -370,  -370,  -370,  -370,  -370,  -370,  -370,  -370,
  -370,  -370,  -370,  -370,  -370,  -370,  -370,  -370,  -370,  -370,
  -370,  -370,  -370,  -370,  -370,  -370,  -370,  -370,  -370,  -370,
  -370,  -370,  -370,  -370,  -370,  -370,  -370,  -370,  -370,  -370,
  -370,     0,  -370,  -370,   169,   351,     0,     9,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,   602,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,    10,    11,    12,    13,    14,    15,    16,
    17,    18,    19,    20,    21,    22,    23,    24,    25,    26,
    27,    28,    29,    30,     0,     0,    31,    32,    33,    34,
    35,    36,    37,    38,    39,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
    40,    41,    42,    43,    44,    45,    46,    47,    48,    49,
    50,    51,    52,    53,    54,    55,    56,    57,    58,    59,
    60,    61,    62,    63,    64,    65,    66,    67,    68,    69,
    70,    71,    72,    73,    74,    75,    76,    77,    78,    79,
    80,    81,    82,    83,    84,    85,    86,    87,    88,    89,
    90,    91,    92,    93,    94,    95,    96,    97,    98,    99,
   100,   101,   102,   103,   104,   105,   106,   107,   108,   109,
   110,   111,   112,   113,   114,   115,   116,   117,   118,   119,
   120,   121,   122,   123,   124,   125,   126,   127,   128,   129,
     9,   130,   131,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,   195,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,    10,    11,    12,    13,
    14,    15,    16,    17,    18,    19,    20,    21,    22,    23,
    24,    25,    26,    27,    28,    29,    30,     0,     0,    31,
    32,    33,    34,    35,    36,    37,    38,    39,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,    40,    41,    42,    43,    44,    45,    46,
    47,    48,    49,    50,    51,    52,    53,    54,    55,    56,
    57,    58,    59,    60,    61,    62,    63,    64,    65,    66,
    67,    68,    69,    70,    71,    72,    73,    74,    75,    76,
    77,    78,    79,    80,    81,    82,    83,    84,    85,    86,
    87,    88,    89,    90,    91,    92,    93,    94,    95,    96,
    97,    98,    99,   100,   101,   102,   103,   104,   105,   106,
   107,   108,   109,   110,   111,   112,   113,   114,   115,   116,
   117,   118,   119,   120,   121,   122,   123,   124,   125,   126,
   127,   128,   129,     0,   130,   131,   364,     0,     9,     0,
     0,  -203,     0,  -203,     0,     0,   195,     0,  -203,     0,
     0,  -203,     0,     0,     0,  -203,     0,     0,     0,     0,
     0,     0,  -203,     0,     0,     0,     0,     0,  -203,  -203,
     0,  -203,     0,     0,    10,    11,    12,    13,    14,    15,
    16,    17,    18,    19,    20,    21,    22,    23,    24,    25,
    26,    27,    28,    29,    30,     0,     0,    31,    32,    33,
    34,    35,    36,    37,    38,    39,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,    40,    41,    42,    43,    44,    45,    46,    47,    48,
    49,    50,    51,    52,    53,    54,    55,    56,    57,    58,
    59,    60,    61,    62,    63,    64,    65,    66,    67,    68,
    69,    70,    71,    72,    73,    74,    75,    76,    77,    78,
    79,    80,    81,    82,    83,    84,    85,    86,    87,    88,
    89,    90,    91,    92,    93,    94,    95,    96,    97,    98,
    99,   100,   101,   102,   103,   104,   105,   106,   107,   108,
   109,   110,   111,   112,   113,   114,   115,   116,   117,   118,
   119,   120,   121,   122,   123,   124,   125,   126,   127,   128,
   129,     0,   130,   131,  -203,   373,     0,     9,     0,     0,
  -315,     0,  -315,     0,     0,     0,     0,  -315,     0,     0,
  -315,     0,     0,     0,  -315,     0,     0,     0,     0,     0,
     0,  -315,     0,     0,     0,     0,     0,  -315,  -315,     0,
  -315,     0,     0,    10,    11,    12,    13,    14,    15,    16,
    17,    18,    19,    20,    21,    22,    23,    24,    25,    26,
    27,    28,    29,    30,     0,     0,    31,    32,    33,    34,
    35,    36,    37,    38,    39,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
    40,    41,    42,    43,    44,    45,    46,    47,    48,    49,
    50,    51,    52,    53,    54,    55,    56,    57,    58,    59,
    60,    61,    62,    63,    64,    65,    66,    67,    68,    69,
    70,    71,    72,    73,    74,    75,    76,    77,    78,    79,
    80,    81,    82,    83,    84,    85,    86,    87,    88,    89,
    90,    91,    92,    93,    94,    95,    96,    97,    98,    99,
   100,   101,   102,   103,   104,   105,   106,   107,   108,   109,
   110,   111,   112,   113,   114,   115,   116,   117,   118,   119,
   120,   121,   122,   123,   124,   125,   126,   127,   128,   129,
     0,   130,   131,  -315,   488,     0,     9,     0,     0,     0,
     0,  -731,     0,     0,     0,     0,  -731,     0,     0,  -731,
     0,     0,     0,  -731,     0,     0,     0,     0,     0,     0,
  -731,     0,     0,     0,     0,     0,     0,  -731,     0,  -731,
     0,     0,    10,    11,    12,   489,    14,    15,    16,    17,
    18,    19,    20,    21,    22,    23,    24,    25,    26,    27,
    28,    29,    30,     0,     0,    31,    32,    33,    34,    35,
    36,    37,    38,    39,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,    40,
    41,    42,    43,    44,    45,    46,    47,    48,    49,    50,
    51,    52,    53,    54,    55,    56,    57,    58,    59,    60,
    61,    62,    63,    64,    65,    66,    67,    68,    69,    70,
    71,    72,    73,    74,    75,    76,    77,    78,    79,    80,
    81,    82,    83,    84,    85,    86,    87,    88,    89,    90,
    91,    92,    93,    94,    95,    96,    97,    98,    99,   100,
   101,   102,   103,   104,   105,   106,   107,   108,   109,   110,
   111,   112,   113,   114,   115,   116,   117,   118,   119,   120,
   121,   122,   123,   124,   125,   126,   127,   128,   129,     0,
   130,   131,  -731,   734,     0,  -370,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,  -340,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,  -340,
     0,     0,     0,     0,     0,     0,     0,     0,  -370,     0,
     0,  -370,  -370,  -370,  -370,  -370,  -370,  -370,  -370,  -370,
  -370,   601,  -370,  -370,  -370,  -370,  -370,  -370,  -370,  -370,
  -370,  -370,     0,     0,  -370,  -370,  -370,  -370,  -370,  -370,
  -370,  -370,  -370,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,  -370,  -370,
  -370,  -370,  -370,  -370,  -370,  -370,  -370,  -370,  -370,  -370,
  -370,  -370,  -370,  -370,  -370,  -370,  -370,  -370,  -370,  -370,
  -370,  -370,  -370,  -370,  -370,  -370,  -370,  -370,  -370,  -370,
  -370,  -370,  -370,  -370,  -370,  -370,  -370,  -370,  -370,  -370,
  -370,  -370,  -370,  -370,  -370,  -370,  -370,  -370,  -370,  -370,
  -370,  -370,  -370,  -370,  -370,  -370,  -370,  -370,  -370,  -370,
  -370,  -370,  -370,  -370,  -370,  -370,  -370,  -370,  -370,  -370,
  -370,  -370,  -370,  -370,  -370,  -370,  -370,  -370,  -370,  -370,
  -370,  -370,  -370,  -370,  -370,  -370,  -370,  -370,     0,  -370,
  -370,   169,   554,     0,  -677,     0,     0,     0,   555,     0,
     0,     0,     0,     0,  -283,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,
  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,
  -677,     0,     0,  -677,  -677,  -677,  -677,  -677,  -677,  -677,
  -677,  -677,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,  -677,  -677,  -677,
  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,
  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,
  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,
  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,
  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,
  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,
  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,
  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,
  -677,  -677,  -677,  -677,  -677,  -677,  -677,     0,  -677,  -677,
   711,     0,  -677,     0,     0,     0,   555,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,  -677,  -677,
  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,
  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,     0,
     0,  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,  -677,  -677,  -677,  -677,  -677,
  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,
  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,
  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,
  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,
  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,
  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,
  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,
  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,
  -677,  -677,  -677,  -677,  -677,     0,  -677,  -677,     8,     0,
     9,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,    10,    11,    12,    13,
    14,    15,    16,    17,    18,    19,    20,    21,    22,    23,
    24,    25,    26,    27,    28,    29,    30,     0,     0,    31,
    32,    33,    34,    35,    36,    37,    38,    39,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,    40,    41,    42,    43,    44,    45,    46,
    47,    48,    49,    50,    51,    52,    53,    54,    55,    56,
    57,    58,    59,    60,    61,    62,    63,    64,    65,    66,
    67,    68,    69,    70,    71,    72,    73,    74,    75,    76,
    77,    78,    79,    80,    81,    82,    83,    84,    85,    86,
    87,    88,    89,    90,    91,    92,    93,    94,    95,    96,
    97,    98,    99,   100,   101,   102,   103,   104,   105,   106,
   107,   108,   109,   110,   111,   112,   113,   114,   115,   116,
   117,   118,   119,   120,   121,   122,   123,   124,   125,   126,
   127,   128,   129,     0,   130,   131,   185,     0,     9,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,    10,    11,    12,    13,    14,    15,
    16,    17,    18,    19,    20,    21,    22,    23,    24,    25,
    26,    27,    28,    29,    30,     0,     0,    31,    32,    33,
    34,    35,    36,    37,    38,    39,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,    40,    41,    42,    43,    44,    45,    46,    47,    48,
    49,    50,    51,    52,    53,    54,    55,    56,    57,    58,
    59,    60,    61,    62,    63,    64,    65,    66,    67,    68,
    69,    70,    71,    72,    73,    74,    75,    76,    77,    78,
    79,    80,    81,    82,    83,    84,    85,    86,    87,    88,
    89,    90,    91,    92,    93,    94,    95,    96,    97,    98,
    99,   100,   101,   102,   103,   104,   105,   106,   107,   108,
   109,   110,   111,   112,   113,   114,   115,   116,   117,   118,
   119,   120,   121,   122,   123,   124,   125,   126,   127,   128,
   129,     0,   130,   131,   236,     0,     9,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,    10,    11,    12,    13,    14,    15,    16,    17,
    18,    19,    20,    21,    22,    23,    24,    25,    26,    27,
    28,    29,    30,     0,     0,    31,    32,    33,    34,    35,
    36,    37,    38,    39,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,    40,
    41,    42,    43,    44,    45,    46,    47,    48,    49,    50,
    51,    52,    53,    54,    55,    56,    57,    58,    59,    60,
    61,    62,    63,    64,    65,    66,    67,    68,    69,    70,
    71,    72,    73,    74,    75,    76,    77,    78,    79,    80,
    81,    82,    83,    84,    85,    86,    87,    88,    89,    90,
    91,    92,    93,    94,    95,    96,    97,    98,    99,   100,
   101,   102,   103,   104,   105,   106,   107,   108,   109,   110,
   111,   112,   113,   114,   115,   116,   117,   118,   119,   120,
   121,   122,   123,   124,   125,   126,   127,   128,   129,     0,
   130,   131,   493,     0,     9,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
    10,    11,    12,    13,    14,    15,    16,    17,    18,    19,
    20,    21,    22,    23,    24,    25,    26,    27,    28,    29,
    30,     0,     0,    31,    32,    33,    34,    35,    36,    37,
    38,    39,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,    40,    41,    42,
    43,    44,    45,    46,    47,    48,    49,    50,    51,    52,
    53,    54,    55,    56,    57,    58,    59,    60,    61,    62,
    63,    64,    65,    66,    67,    68,    69,    70,    71,    72,
    73,    74,    75,    76,    77,    78,    79,    80,    81,    82,
    83,    84,    85,    86,    87,    88,    89,    90,    91,    92,
    93,    94,    95,    96,    97,    98,    99,   100,   101,   102,
   103,   104,   105,   106,   107,   108,   109,   110,   111,   112,
   113,   114,   115,   116,   117,   118,   119,   120,   121,   122,
   123,   124,   125,   126,   127,   128,   129,     0,   130,   131,
   566,     0,  -677,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,  -677,  -677,
  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,
  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,     0,
     0,  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,  -677,  -677,  -677,  -677,  -677,
  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,
  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,
  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,
  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,
  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,
  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,
  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,
  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,  -677,
  -677,  -677,  -677,  -677,  -677,     0,  -677,  -677,   577,     0,
     9,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,    10,    11,    12,    13,
    14,    15,    16,    17,    18,    19,   578,    21,    22,    23,
    24,    25,    26,    27,    28,    29,    30,     0,     0,    31,
    32,    33,    34,    35,    36,    37,    38,    39,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,    40,    41,    42,    43,    44,    45,    46,
    47,    48,    49,    50,    51,    52,    53,    54,    55,    56,
    57,    58,    59,    60,    61,    62,    63,    64,    65,    66,
    67,    68,    69,    70,    71,    72,    73,    74,    75,    76,
    77,    78,    79,    80,    81,    82,    83,    84,    85,    86,
    87,    88,    89,    90,    91,    92,    93,    94,    95,    96,
    97,    98,    99,   100,   101,   102,   103,   104,   105,   106,
   107,   108,   109,   110,   111,   112,   113,   114,   115,   116,
   117,   118,   119,   120,   121,   122,   123,   124,   125,   126,
   127,   128,   129,     0,   130,   131,   673,     0,     9,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,    10,    11,    12,    13,    14,    15,
    16,    17,    18,    19,    20,    21,    22,    23,    24,    25,
    26,    27,    28,    29,    30,     0,     0,    31,    32,    33,
    34,    35,    36,    37,    38,    39,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,    40,    41,    42,    43,    44,    45,    46,    47,    48,
    49,    50,    51,    52,    53,    54,    55,    56,    57,    58,
    59,    60,    61,    62,    63,    64,    65,    66,    67,    68,
    69,    70,    71,    72,    73,    74,    75,    76,    77,    78,
    79,    80,    81,    82,    83,    84,    85,    86,    87,    88,
    89,    90,    91,    92,    93,    94,    95,    96,    97,    98,
    99,   100,   101,   102,   103,   104,   105,   106,   107,   108,
   109,   110,   111,   112,   113,   114,   115,   116,   117,   118,
   119,   120,   121,   122,   123,   124,   125,   126,   127,   128,
   129,     0,   130,   131,   717,     0,     9,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,    10,    11,    12,    13,    14,    15,    16,    17,
    18,    19,    20,    21,    22,    23,    24,    25,    26,    27,
    28,    29,    30,     0,     0,    31,    32,    33,    34,    35,
    36,    37,    38,    39,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,    40,
    41,    42,    43,    44,    45,    46,    47,    48,    49,    50,
    51,    52,    53,    54,    55,    56,    57,    58,    59,    60,
    61,    62,    63,    64,    65,    66,    67,    68,    69,    70,
    71,    72,    73,    74,    75,    76,    77,    78,    79,    80,
    81,    82,    83,    84,    85,    86,    87,    88,    89,    90,
    91,    92,    93,    94,    95,    96,    97,    98,    99,   100,
   101,   102,   103,   104,   105,   106,   107,   108,   109,   110,
   111,   112,   113,   114,   115,   116,   117,   118,   119,   120,
   121,   122,   123,   124,   125,   126,   127,   128,   129,     0,
   130,   131,   728,     0,     9,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
    10,    11,    12,    13,    14,    15,    16,    17,    18,    19,
   578,    21,    22,    23,    24,    25,    26,    27,    28,    29,
    30,     0,     0,    31,    32,    33,    34,    35,    36,    37,
    38,    39,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,    40,    41,    42,
    43,    44,    45,    46,    47,    48,    49,    50,    51,    52,
    53,    54,    55,    56,    57,    58,    59,    60,    61,    62,
    63,    64,    65,    66,    67,    68,    69,    70,    71,    72,
    73,    74,    75,    76,    77,    78,    79,    80,    81,    82,
    83,    84,    85,    86,    87,    88,    89,    90,    91,    92,
    93,    94,    95,    96,    97,    98,    99,   100,   101,   102,
   103,   104,   105,   106,   107,   108,   109,   110,   111,   112,
   113,   114,   115,   116,   117,   118,   119,   120,   121,   122,
   123,   124,   125,   126,   127,   128,   129,     0,   130,   131,
   902,     0,     9,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,    10,    11,
    12,    13,    14,    15,    16,    17,    18,    19,    20,    21,
    22,    23,    24,    25,    26,    27,    28,    29,    30,     0,
     0,    31,    32,    33,    34,    35,    36,    37,    38,    39,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,    40,    41,    42,    43,    44,
    45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
    55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
    65,    66,    67,    68,    69,    70,    71,    72,    73,    74,
    75,    76,    77,    78,    79,    80,    81,    82,    83,    84,
    85,    86,    87,    88,    89,    90,    91,    92,    93,    94,
    95,    96,    97,    98,    99,   100,   101,   102,   103,   104,
   105,   106,   107,   108,   109,   110,   111,   112,   113,   114,
   115,   116,   117,   118,   119,   120,   121,   122,   123,   124,
   125,   126,   127,   128,   129,     0,   130,   131,  1027,     0,
     9,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,    10,    11,    12,    13,
    14,    15,    16,    17,    18,    19,    20,    21,    22,    23,
    24,    25,    26,    27,    28,    29,    30,     0,     0,    31,
    32,    33,    34,    35,    36,    37,    38,    39,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,    40,    41,    42,    43,    44,    45,    46,
    47,    48,    49,    50,    51,    52,    53,    54,    55,    56,
    57,    58,    59,    60,    61,    62,    63,    64,    65,    66,
    67,    68,    69,    70,    71,    72,    73,    74,    75,    76,
    77,    78,    79,    80,    81,    82,    83,    84,    85,    86,
    87,    88,    89,    90,    91,    92,    93,    94,    95,    96,
    97,    98,    99,   100,   101,   102,   103,   104,   105,   106,
   107,   108,   109,   110,   111,   112,   113,   114,   115,   116,
   117,   118,   119,   120,   121,   122,   123,   124,   125,   126,
   127,   128,   129,     9,   130,   131,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,   571,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,   572,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,    10,
    11,    12,    13,    14,    15,    16,    17,    18,    19,    20,
    21,    22,    23,    24,    25,    26,    27,    28,    29,    30,
     0,     0,    31,    32,    33,    34,    35,    36,    37,    38,
    39,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,    40,    41,    42,    43,
    44,    45,    46,    47,    48,    49,    50,    51,    52,    53,
    54,    55,    56,    57,    58,    59,    60,    61,    62,    63,
    64,    65,    66,    67,    68,    69,    70,    71,    72,    73,
    74,    75,    76,    77,    78,    79,    80,    81,    82,    83,
    84,    85,    86,    87,    88,    89,    90,    91,    92,    93,
    94,    95,    96,    97,    98,    99,   100,   101,   102,   103,
   104,   105,   106,   107,   108,   109,   110,   111,   112,   113,
   114,   115,   116,   117,   118,   119,   120,   121,   122,   123,
   124,   125,   126,   127,   128,   129,     9,   130,   131,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,   684,
     0,     0,    10,    11,    12,    13,    14,    15,    16,    17,
    18,    19,    20,    21,    22,    23,    24,    25,    26,    27,
    28,    29,    30,     0,     0,    31,    32,    33,    34,    35,
    36,    37,    38,    39,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,    40,
    41,    42,    43,    44,    45,    46,    47,    48,    49,    50,
    51,    52,    53,    54,    55,    56,    57,    58,    59,    60,
    61,    62,    63,    64,    65,    66,    67,    68,    69,    70,
    71,    72,    73,    74,    75,    76,    77,    78,    79,    80,
    81,    82,    83,    84,    85,    86,    87,    88,    89,    90,
    91,    92,    93,    94,    95,    96,    97,    98,    99,   100,
   101,   102,   103,   104,   105,   106,   107,   108,   109,   110,
   111,   112,   113,   114,   115,   116,   117,   118,   119,   120,
   121,   122,   123,   124,   125,   126,   127,   128,   129,     9,
   130,   131,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,    10,    11,    12,    13,    14,
    15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
    25,    26,    27,    28,    29,    30,     0,     0,    31,    32,
    33,    34,    35,    36,    37,    38,    39,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,    40,    41,    42,    43,    44,    45,    46,    47,
    48,    49,    50,    51,    52,    53,    54,    55,    56,    57,
    58,    59,    60,    61,    62,    63,    64,    65,    66,    67,
    68,    69,    70,    71,    72,    73,    74,    75,    76,    77,
    78,    79,    80,    81,    82,    83,    84,    85,    86,    87,
    88,    89,    90,    91,    92,    93,    94,    95,    96,    97,
    98,    99,   100,   101,   102,   103,   104,   105,   106,   107,
   108,   109,   110,   111,   112,   113,   114,   115,   116,   117,
   118,   119,   120,   121,   122,   123,   124,   125,   126,   127,
   128,   129,   638,   130,   131,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,    10,    11,
    12,    13,    14,    15,    16,    17,    18,    19,    20,    21,
    22,    23,    24,    25,    26,    27,    28,    29,    30,     0,
     0,    31,    32,    33,    34,    35,    36,    37,    38,    39,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,    40,    41,    42,    43,    44,
    45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
    55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
    65,    66,    67,    68,    69,    70,    71,    72,    73,    74,
    75,    76,    77,    78,    79,    80,    81,    82,    83,    84,
    85,    86,    87,    88,    89,    90,    91,    92,    93,    94,
    95,    96,    97,    98,    99,   100,   101,   102,   103,   104,
   105,   106,   107,   108,   109,   110,   111,   112,   113,   114,
   115,   116,   117,   118,   119,   120,   121,   122,   123,   124,
   125,   126,   127,   128,   129,     9,   130,   131,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,    10,    11,    12,    13,    14,    15,    16,    17,    18,
    19,   578,    21,    22,    23,    24,    25,    26,    27,    28,
    29,    30,     0,     0,    31,    32,    33,    34,    35,    36,
    37,    38,    39,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,    40,    41,
    42,    43,    44,    45,    46,    47,    48,    49,    50,    51,
    52,    53,    54,    55,    56,    57,    58,    59,    60,    61,
    62,    63,    64,    65,    66,    67,    68,    69,    70,    71,
    72,    73,    74,    75,    76,    77,    78,    79,    80,    81,
    82,    83,    84,    85,    86,    87,    88,    89,    90,    91,
    92,    93,    94,    95,    96,    97,    98,    99,   100,   101,
   102,   103,   104,   105,   106,   107,   108,   109,   110,   111,
   112,   113,   114,   115,   116,   117,   118,   119,   120,   121,
   122,   123,   124,   125,   126,   127,   128,   129,     0,   130,
   131
};

static const short yycheck[] = {     1,
     2,   224,   361,   142,   341,   369,   164,   410,   251,   400,
   401,   484,   400,   401,   534,   242,   243,   604,   257,   422,
   515,   325,   607,   616,   748,     1,     6,     1,   686,   687,
    25,    47,    13,    44,    19,     1,     1,   692,    48,   866,
     1,    57,    60,   383,   491,     1,  1002,   579,    63,    64,
    45,     1,    13,     1,     3,   962,   217,   361,     1,     1,
   361,     1,    10,   952,   210,   224,     1,     1,   226,   227,
     1,    13,   441,   361,   443,   444,   361,     1,     1,    35,
     1,     1,    32,     1,     1,     3,    16,     1,     3,     1,
    13,     1,     1,   394,     1,     1,    13,    27,     1,    11,
   154,   197,   695,   132,    13,     1,     1,   203,     1,     7,
     1,   961,   141,   633,    24,     1,   636,     1,   455,   456,
     1,    33,   617,     1,   461,  1032,  1033,   659,     3,   183,
     3,     1,   652,     1,  1023,  1091,   198,    86,    87,   586,
   199,     1,   866,   993,   994,     1,   210,    41,     1,   872,
   934,   215,     1,   876,   156,   157,   218,   315,   498,   198,
   219,   163,   164,   165,   468,   324,   168,   468,    86,    87,
   150,   210,   152,   510,   184,   185,   186,   187,   188,   218,
   196,  1008,   200,   163,   164,   165,   166,    50,    28,   191,
   349,     6,     1,     8,   411,   210,   555,   264,    33,   210,
   180,    10,   182,    43,   421,    20,   423,   203,   210,   189,
   205,   206,   197,    86,    87,   217,   218,   197,    13,    34,
   201,    36,   202,   199,   226,   227,   203,   207,   230,   231,
   232,   212,   212,   199,   889,   211,   201,   211,   212,   598,
   242,   243,   829,   219,   403,   211,   550,   212,   552,   550,
   215,   552,   217,   219,   623,   624,   217,   561,   238,   199,
   561,   217,   550,   211,   552,   550,   924,   552,   199,   217,
   212,   635,   252,   561,   217,   217,   561,   217,   936,   219,
   211,   440,   217,   217,  1008,   209,   201,   201,   219,   212,
   211,   212,   212,   452,   217,   212,   217,   656,   212,   690,
   217,   692,   690,   217,   692,   211,   203,   965,   217,   200,
   217,   217,   215,   315,   212,   211,   211,   212,   211,   215,
   211,   906,   215,     6,   215,   211,   201,   211,  1112,   215,
   211,   215,  1116,   211,   215,    33,   929,   215,   931,   932,
   933,   211,     3,   211,   212,   215,   939,   940,   707,   708,
   714,   211,   212,   333,  1012,   211,   212,   942,   211,   212,
   491,   752,   211,   212,   179,   724,   433,   434,   435,   612,
   501,   212,   552,    13,   215,   377,   378,   210,   380,   738,
   875,   561,     6,    16,   543,   544,   690,   546,   692,    13,
     4,   984,   210,   888,    27,     9,   210,   215,   702,   703,
   210,   702,   703,   562,   563,   190,   565,    21,     1,   568,
     3,   643,   999,   645,   702,   703,    49,   702,   703,   211,
   212,   560,     3,   210,     5,    39,  1084,   212,   215,    22,
   215,  1089,  1090,     3,   436,    40,   675,  1022,   212,   666,
   960,   215,   746,    48,   892,    26,   894,    61,   691,   210,
     6,  1109,     8,    34,   198,   586,   680,   118,   682,   618,
   619,   825,    19,   190,    20,   209,   210,   606,    25,   213,
   214,   211,   212,   475,   218,   210,   996,   923,    34,   925,
    36,    62,     5,   842,   486,   210,    42,   489,    45,   848,
   492,    14,     3,   154,   155,   156,   157,   499,   889,   230,
   231,   889,   871,   872,   198,   210,    29,   876,    31,     8,
  1097,   914,   849,   210,    13,   209,    51,   886,   887,   213,
   214,    20,   702,   703,   218,   118,   119,   120,   189,   835,
   836,   192,   923,   870,   925,    34,  1009,    36,   210,   544,
     8,   546,    41,    42,   210,   684,   179,   203,    16,   680,
   709,   682,    20,   555,    65,    66,    67,    68,    69,    27,
   210,   154,   155,   156,   157,    10,    34,    13,    36,   180,
   181,   182,   210,   910,    42,   212,   578,   557,   200,   184,
   185,   186,   187,   188,   200,   889,   745,    24,   590,   747,
   592,   593,    24,   207,   208,    60,   189,   190,   191,   192,
   896,   897,   582,   967,   584,   974,   975,     8,   234,   235,
   200,   750,   205,   206,   983,    16,    10,   210,   212,    20,
  1032,  1033,   211,   179,   604,   784,    27,   212,  1019,   974,
   975,  1019,   118,    34,   212,    36,   193,   194,   195,   377,
   378,   663,   664,   212,   212,   202,   203,   204,   205,   206,
   212,   212,   654,   592,   593,     3,    24,     5,   660,    13,
    13,   663,   664,   212,   666,  1029,    14,     8,   154,   155,
   156,   157,    13,   210,    22,    13,   899,   900,    26,    20,
   179,    29,     8,    31,     3,   212,    34,    13,   690,   198,
   692,   212,    24,    34,    20,    36,    24,   212,   215,   201,
   209,   860,    13,   189,   213,   214,   192,   212,    34,   218,
    36,   179,    24,   424,    62,  1019,   212,   428,   212,  1083,
   431,   432,  1081,   215,   215,   215,   885,   210,   210,   210,
   210,   210,   210,   892,   210,   894,   210,   896,   897,   210,
   899,   900,   215,   723,   210,   747,   210,   210,   210,   210,
   730,   210,   732,   210,   210,   210,   915,   210,     1,   210,
     3,   210,   210,   215,    12,   215,     1,   210,     3,   210,
   118,   119,   120,     5,   210,   210,   210,   210,   179,    22,
   210,   210,   210,     1,   215,   212,   190,    22,   211,   215,
   200,   210,   212,    24,   215,   190,    24,   215,    13,   210,
   212,   217,   211,   962,   210,   212,   154,   155,   156,   157,
     0,     0,     3,     7,   973,   172,   191,   353,   361,   361,
   572,   457,   645,   361,   921,   371,   864,   848,   667,   848,
   255,   675,   935,   835,   836,  1019,   981,   894,   179,   819,
   439,   189,   190,   191,   192,  1095,   401,  1006,  1096,   829,
   345,  1001,   329,   179,   462,   151,   161,   205,   206,   256,
   586,   259,   210,   492,   489,   213,   214,    -1,    -1,    -1,
    -1,    -1,    -1,  1032,  1033,   118,   119,   120,    -1,    -1,
    -1,    -1,  1041,   118,   119,   120,    -1,   889,   868,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,     1,    -1,     3,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,   909,    -1,    -1,
    -1,   154,   155,   156,   157,    -1,  1075,    22,    23,   154,
   155,   156,   157,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,  1093,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,   189,   190,   191,   192,
    -1,    -1,    -1,    -1,   189,   190,   191,   192,    -1,   961,
    -1,   941,   205,   206,    -1,    -1,    -1,   210,    -1,    -1,
   205,   206,    -1,    -1,    -1,   210,    -1,    -1,    -1,    -1,
   960,    86,    87,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
   992,   993,   994,    -1,    99,   100,   101,   102,   103,   104,
   105,   106,   107,   108,    -1,    -1,   111,   112,   113,   114,
   115,   116,   117,   118,   119,   120,    -1,    -1,    -1,   999,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,   132,   133,   134,
   135,   136,   137,   138,   139,   140,   141,   142,   143,   144,
   145,   146,   147,   148,   149,   150,   151,   152,   153,   154,
   155,   156,   157,     1,    -1,     3,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   174,
   175,   176,   177,    -1,    22,    23,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,   189,   190,   191,   192,    -1,    -1,
    -1,    -1,    -1,   198,   199,    -1,    -1,    -1,    46,    -1,
   205,   206,    -1,    -1,    -1,   210,   211,    -1,    -1,    -1,
    -1,   216,    -1,   218,   219,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    86,    87,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    99,   100,   101,   102,   103,   104,   105,   106,   107,
   108,    -1,    -1,   111,   112,   113,   114,   115,   116,   117,
   118,   119,   120,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,   132,   133,   134,   135,   136,   137,
   138,   139,   140,   141,   142,   143,   144,   145,   146,   147,
   148,   149,   150,   151,   152,   153,   154,   155,   156,   157,
     1,    -1,     3,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,   171,   172,    -1,   174,   175,   176,   177,
    -1,    22,    23,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,   189,   190,   191,   192,    -1,    -1,    -1,    -1,    -1,
   198,    -1,    -1,    -1,    -1,    46,    -1,   205,   206,    -1,
    -1,    -1,   210,    -1,    -1,    -1,    -1,    -1,   216,    -1,
   218,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    86,    87,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    99,   100,
   101,   102,   103,   104,   105,   106,   107,   108,    -1,    -1,
   111,   112,   113,   114,   115,   116,   117,   118,   119,   120,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,   132,   133,   134,   135,   136,   137,   138,   139,   140,
   141,   142,   143,   144,   145,   146,   147,   148,   149,   150,
   151,   152,   153,   154,   155,   156,   157,     1,    -1,     3,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
   171,   172,    -1,   174,   175,   176,   177,    -1,    22,    23,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   189,   190,
   191,   192,    -1,    -1,    -1,    -1,    -1,   198,    -1,    -1,
    -1,    -1,    -1,    -1,   205,   206,    -1,    -1,    -1,   210,
    -1,    -1,    -1,    -1,    -1,   216,    -1,   218,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    86,    87,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    99,   100,   101,   102,   103,
   104,   105,   106,   107,   108,    -1,    -1,   111,   112,   113,
   114,   115,   116,   117,   118,   119,   120,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   132,   133,
   134,   135,   136,   137,   138,   139,   140,   141,   142,   143,
   144,   145,   146,   147,   148,   149,   150,   151,   152,   153,
   154,   155,   156,   157,     1,    -1,     3,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
   174,   175,   176,   177,    -1,    22,    23,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,   189,   190,   191,   192,    -1,
    -1,    -1,    -1,    -1,   198,    -1,    -1,    -1,    -1,    -1,
    -1,   205,   206,    -1,    -1,    -1,   210,    -1,    -1,    -1,
    -1,    -1,   216,    -1,   218,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    86,
    87,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    99,   100,   101,   102,   103,   104,   105,   106,
   107,   108,    -1,    -1,   111,   112,   113,   114,   115,   116,
   117,   118,   119,   120,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,   132,   133,   134,   135,   136,
   137,   138,   139,   140,   141,   142,   143,   144,   145,   146,
   147,   148,   149,   150,   151,   152,   153,   154,   155,   156,
   157,     1,    -1,     3,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,   174,   175,   176,
   177,    -1,    22,    23,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,   189,   190,   191,   192,    -1,    -1,    -1,    -1,
    -1,   198,    -1,    -1,    -1,    -1,    -1,    -1,   205,   206,
    -1,    -1,    -1,   210,    -1,    -1,    -1,    -1,    -1,   216,
    -1,   218,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    86,    87,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    99,
   100,   101,   102,   103,   104,   105,   106,   107,   108,    -1,
    -1,   111,   112,   113,   114,   115,   116,   117,   118,   119,
   120,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,   132,   133,   134,   135,   136,   137,   138,   139,
   140,   141,   142,   143,   144,   145,   146,   147,   148,   149,
   150,   151,   152,   153,   154,   155,   156,   157,     1,    -1,
     3,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,   174,   175,   176,   177,    -1,    22,
    23,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   189,
   190,   191,   192,    -1,    -1,    -1,    -1,    -1,   198,    -1,
    -1,    -1,    -1,    -1,    -1,   205,   206,    -1,    -1,    -1,
   210,    -1,    -1,    -1,    -1,    -1,   216,    -1,   218,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    86,    87,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    99,   100,   101,   102,
   103,   104,   105,   106,   107,   108,    -1,    -1,   111,   112,
   113,   114,   115,   116,   117,   118,   119,   120,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   132,
   133,   134,   135,   136,   137,   138,   139,   140,   141,   142,
   143,   144,   145,   146,   147,   148,   149,   150,   151,   152,
   153,   154,   155,   156,   157,     1,    -1,     3,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,   174,   175,   176,   177,    -1,    22,    23,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,   189,   190,   191,   192,
    -1,    -1,    -1,    -1,    -1,   198,    -1,    -1,    -1,    -1,
    -1,    -1,   205,   206,    -1,    -1,    -1,   210,    -1,    -1,
    -1,    -1,    -1,   216,    -1,   218,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    86,    87,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    99,   100,   101,   102,   103,   104,   105,
   106,   107,   108,    -1,    -1,   111,   112,   113,   114,   115,
   116,   117,   118,   119,   120,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,   132,   133,   134,   135,
   136,   137,   138,   139,   140,   141,   142,   143,   144,   145,
   146,   147,   148,   149,   150,   151,   152,   153,   154,   155,
   156,   157,     1,    -1,     3,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   174,   175,
   176,   177,    -1,    22,    23,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,   189,   190,   191,   192,    -1,    -1,    -1,
    -1,    -1,   198,    -1,    -1,    -1,    -1,    -1,    -1,   205,
   206,    -1,    -1,    -1,   210,    -1,    -1,    -1,    -1,    -1,
   216,    -1,   218,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    86,    87,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    99,   100,   101,   102,   103,   104,   105,   106,   107,   108,
    -1,    -1,   111,   112,   113,   114,   115,   116,   117,   118,
   119,   120,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,   132,   133,   134,   135,   136,   137,   138,
   139,   140,   141,   142,   143,   144,   145,   146,   147,   148,
   149,   150,   151,   152,   153,   154,   155,   156,   157,     1,
    -1,     3,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,   174,   175,   176,   177,    -1,
    22,    23,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
   189,   190,   191,   192,    -1,    -1,    -1,    -1,    -1,   198,
    -1,    -1,    -1,    -1,    -1,    -1,   205,   206,    -1,    -1,
    -1,   210,    -1,    -1,    -1,    -1,    -1,   216,    -1,   218,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    86,    87,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    99,   100,   101,
   102,   103,   104,   105,   106,   107,   108,    -1,    -1,   111,
   112,   113,   114,   115,   116,   117,   118,   119,   120,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
   132,   133,   134,   135,   136,   137,   138,   139,   140,   141,
   142,   143,   144,   145,   146,   147,   148,   149,   150,   151,
   152,   153,   154,   155,   156,   157,     1,    -1,     3,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,   174,   175,   176,   177,    -1,    22,    23,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,   189,   190,   191,
   192,    -1,    -1,    -1,    -1,    -1,   198,    -1,    -1,    -1,
    -1,    -1,    -1,   205,   206,    -1,    -1,    -1,   210,    -1,
    -1,    -1,    -1,    -1,   216,    -1,   218,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    86,    87,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    99,   100,   101,   102,   103,   104,
   105,   106,   107,   108,    -1,    -1,   111,   112,   113,   114,
   115,   116,   117,   118,   119,   120,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,   132,   133,   134,
   135,   136,   137,   138,   139,   140,   141,   142,   143,   144,
   145,   146,   147,   148,   149,   150,   151,   152,   153,   154,
   155,   156,   157,     1,    -1,     3,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   174,
   175,   176,   177,    -1,    22,    23,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,   189,   190,   191,   192,    -1,    -1,
    -1,    -1,    -1,   198,    -1,    -1,    -1,    -1,    -1,    -1,
   205,   206,    -1,    -1,    -1,   210,    -1,    -1,    -1,    -1,
    -1,   216,    -1,   218,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    86,    87,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    99,   100,   101,   102,   103,   104,   105,   106,   107,
   108,    -1,    -1,   111,   112,   113,   114,   115,   116,   117,
   118,   119,   120,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,   132,   133,   134,   135,   136,   137,
   138,   139,   140,   141,   142,   143,   144,   145,   146,   147,
   148,   149,   150,   151,   152,   153,   154,   155,   156,   157,
     1,    -1,     3,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,   174,   175,   176,   177,
    -1,    22,    23,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,   189,   190,   191,   192,    -1,    -1,    -1,    -1,    -1,
   198,    -1,    -1,    -1,    -1,    -1,    -1,   205,   206,    -1,
    -1,    -1,   210,    -1,    -1,    -1,    -1,    -1,   216,    -1,
   218,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    86,    87,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    99,   100,
   101,   102,   103,   104,   105,   106,   107,   108,    -1,    -1,
   111,   112,   113,   114,   115,   116,   117,   118,   119,   120,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,   132,   133,   134,   135,   136,   137,   138,   139,   140,
   141,   142,   143,   144,   145,   146,   147,   148,   149,   150,
   151,   152,   153,   154,   155,   156,   157,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,   174,   175,   176,   177,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   189,   190,
   191,   192,    -1,    -1,    -1,    -1,     1,   198,     3,    -1,
    -1,     6,     7,    -1,   205,   206,    -1,    12,    13,   210,
    15,    -1,    17,    18,    -1,   216,    -1,   218,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    30,    -1,    -1,    -1,    -1,
    35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
    45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
    55,    56,    57,    58,    59,    -1,    -1,    62,    63,    64,
    65,    66,    67,    68,    69,    70,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    86,    87,    88,    89,    90,    91,    92,    93,    94,
    95,    96,    97,    98,    99,   100,   101,   102,   103,   104,
   105,   106,   107,   108,   109,   110,   111,   112,   113,   114,
   115,   116,   117,   118,   119,   120,   121,   122,   123,   124,
   125,   126,   127,   128,   129,   130,   131,   132,   133,   134,
   135,   136,   137,   138,   139,   140,   141,   142,   143,   144,
   145,   146,   147,   148,   149,   150,   151,   152,   153,   154,
   155,   156,   157,   158,   159,   160,   161,   162,   163,   164,
   165,   166,   167,   168,   169,   170,   171,   172,   173,   174,
   175,    -1,   177,   178,    -1,    -1,    -1,    -1,    -1,    -1,
     1,    -1,     3,    -1,   189,     6,     7,    -1,    -1,    -1,
    -1,    -1,    13,    -1,    15,    -1,    17,    18,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    30,
    -1,    -1,   217,    -1,    35,    36,    37,    38,    39,    40,
    41,    42,    43,    44,    45,    46,    47,    48,    49,    50,
    51,    52,    53,    54,    55,    56,    57,    58,    59,    -1,
    -1,    62,    63,    64,    65,    66,    67,    68,    69,    70,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    86,    87,    88,    89,    90,
    91,    92,    93,    94,    95,    96,    97,    98,    99,   100,
   101,   102,   103,   104,   105,   106,   107,   108,   109,   110,
   111,   112,   113,   114,   115,   116,   117,   118,   119,   120,
   121,   122,   123,   124,   125,   126,   127,   128,   129,   130,
   131,   132,   133,   134,   135,   136,   137,   138,   139,   140,
   141,   142,   143,   144,   145,   146,   147,   148,   149,   150,
   151,   152,   153,   154,   155,   156,   157,   158,   159,   160,
   161,   162,   163,   164,   165,   166,   167,   168,   169,   170,
   171,   172,   173,   174,   175,    -1,   177,   178,    -1,    -1,
    -1,    -1,    -1,    -1,     1,    -1,     3,    -1,   189,     6,
     7,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    15,    -1,
    17,    18,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    30,    -1,    -1,   217,    -1,    -1,    36,
    37,    38,    39,    40,    41,    42,    43,    44,    45,    46,
    47,    48,    49,    50,    51,    52,    53,    54,    55,    56,
    57,    58,    59,    -1,    -1,    62,    63,    64,    65,    66,
    67,    68,    69,    70,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    86,
    87,    88,    89,    90,    91,    92,    93,    94,    95,    96,
    97,    98,    99,   100,   101,   102,   103,   104,   105,   106,
   107,   108,   109,   110,   111,   112,   113,   114,   115,   116,
   117,   118,   119,   120,   121,   122,   123,   124,   125,   126,
   127,   128,   129,   130,   131,   132,   133,   134,   135,   136,
   137,   138,   139,   140,   141,   142,   143,   144,   145,   146,
   147,   148,   149,   150,   151,   152,   153,   154,   155,   156,
   157,   158,   159,   160,   161,   162,   163,   164,   165,   166,
   167,   168,   169,   170,   171,   172,   173,   174,   175,    -1,
   177,   178,    -1,     1,    -1,     3,    -1,    -1,    -1,    -1,
    -1,    -1,   189,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
   217,    39,    40,    41,    42,    43,    44,    45,    46,    47,
    48,    49,    50,    51,    52,    53,    54,    55,    56,    57,
    58,    59,    -1,    -1,    62,    63,    64,    65,    66,    67,
    68,    69,    70,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    86,    87,
    88,    89,    90,    91,    92,    93,    94,    95,    96,    97,
    98,    99,   100,   101,   102,   103,   104,   105,   106,   107,
   108,   109,   110,   111,   112,   113,   114,   115,   116,   117,
   118,   119,   120,   121,   122,   123,   124,   125,   126,   127,
   128,   129,   130,   131,   132,   133,   134,   135,   136,   137,
   138,   139,   140,   141,   142,   143,   144,   145,   146,   147,
   148,   149,   150,   151,   152,   153,   154,   155,   156,   157,
   158,   159,   160,   161,   162,   163,   164,   165,   166,   167,
   168,   169,   170,   171,   172,   173,   174,   175,    -1,   177,
   178,    -1,     1,    -1,     3,    -1,    -1,    -1,    -1,    -1,
    -1,   189,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   217,
    39,    40,    41,    42,    43,    44,    45,    46,    47,    48,
    49,    50,    51,    52,    53,    54,    55,    56,    57,    58,
    59,    -1,    -1,    62,    63,    64,    65,    66,    67,    68,
    69,    70,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    86,    87,    88,
    89,    90,    91,    92,    93,    94,    95,    96,    97,    98,
    99,   100,   101,   102,   103,   104,   105,   106,   107,   108,
   109,   110,   111,   112,   113,   114,   115,   116,   117,   118,
   119,   120,   121,   122,   123,   124,   125,   126,   127,   128,
   129,   130,   131,   132,   133,   134,   135,   136,   137,   138,
   139,   140,   141,   142,   143,   144,   145,   146,   147,   148,
   149,   150,   151,   152,   153,   154,   155,   156,   157,   158,
   159,   160,   161,   162,   163,   164,   165,   166,   167,   168,
   169,   170,   171,   172,   173,   174,   175,    -1,   177,   178,
    -1,     1,    -1,     3,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   217,    39,
    40,    41,    42,    43,    44,    45,    46,    47,    48,    49,
    50,    51,    52,    53,    54,    55,    56,    57,    58,    59,
    -1,    -1,    62,    63,    64,    65,    66,    67,    68,    69,
    70,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    86,    87,    88,    89,
    90,    91,    92,    93,    94,    95,    96,    97,    98,    99,
   100,   101,   102,   103,   104,   105,   106,   107,   108,   109,
   110,   111,   112,   113,   114,   115,   116,   117,   118,   119,
   120,   121,   122,   123,   124,   125,   126,   127,   128,   129,
   130,   131,   132,   133,   134,   135,   136,   137,   138,   139,
   140,   141,   142,   143,   144,   145,   146,   147,   148,   149,
   150,   151,   152,   153,   154,   155,   156,   157,   158,   159,
   160,   161,   162,   163,   164,   165,   166,   167,   168,   169,
   170,   171,   172,   173,   174,   175,    -1,   177,   178,    -1,
     1,    -1,     3,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,   217,    39,    40,
    41,    42,    43,    44,    45,    46,    47,    48,    49,    50,
    51,    52,    53,    54,    55,    56,    57,    58,    59,    -1,
    -1,    62,    63,    64,    65,    66,    67,    68,    69,    70,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    86,    87,    88,    89,    90,
    91,    92,    93,    94,    95,    96,    97,    98,    99,   100,
   101,   102,   103,   104,   105,   106,   107,   108,   109,   110,
   111,   112,   113,   114,   115,   116,   117,   118,   119,   120,
   121,   122,   123,   124,   125,   126,   127,   128,   129,   130,
   131,   132,   133,   134,   135,   136,   137,   138,   139,   140,
   141,   142,   143,   144,   145,   146,   147,   148,   149,   150,
   151,   152,   153,   154,   155,   156,   157,   158,   159,   160,
   161,   162,   163,   164,   165,   166,   167,   168,   169,   170,
   171,   172,   173,   174,   175,     3,   177,   178,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    22,    23,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,   217,    -1,    46,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    86,    87,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    99,   100,   101,   102,   103,   104,   105,   106,   107,
   108,    -1,    -1,   111,   112,   113,   114,   115,   116,   117,
   118,   119,   120,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,   132,   133,   134,   135,   136,   137,
   138,   139,   140,   141,   142,   143,   144,   145,   146,   147,
   148,   149,   150,   151,   152,   153,   154,   155,   156,   157,
    -1,     3,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    12,    -1,    -1,   171,   172,    -1,   174,   175,   176,   177,
    22,    23,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,   189,   190,   191,   192,    -1,    -1,    -1,    -1,    -1,
   198,    -1,    -1,    -1,    -1,    -1,    -1,   205,   206,    -1,
    -1,    -1,   210,    -1,    -1,    -1,    -1,    -1,   216,    -1,
   218,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    86,    87,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    99,   100,   101,
   102,   103,   104,   105,   106,   107,   108,    -1,    -1,   111,
   112,   113,   114,   115,   116,   117,   118,   119,   120,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
   132,   133,   134,   135,   136,   137,   138,   139,   140,   141,
   142,   143,   144,   145,   146,   147,   148,   149,   150,   151,
   152,   153,   154,   155,   156,   157,    -1,     3,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,   174,   175,   176,   177,    22,    23,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,   189,   190,   191,
   192,    -1,    -1,    -1,    -1,    -1,   198,    -1,    -1,    -1,
    -1,    -1,    -1,   205,   206,    -1,    -1,    -1,   210,    -1,
    -1,    -1,    -1,    -1,   216,    -1,   218,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    86,    87,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    99,   100,   101,   102,   103,   104,   105,
   106,   107,   108,    -1,    -1,   111,   112,   113,   114,   115,
   116,   117,   118,   119,   120,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,   132,   133,   134,   135,
   136,   137,   138,   139,   140,   141,   142,   143,   144,   145,
   146,   147,   148,   149,   150,   151,   152,   153,   154,   155,
   156,   157,    -1,     3,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   174,   175,
   176,   177,    22,    23,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,   189,   190,   191,   192,    -1,    -1,    -1,
    -1,    -1,   198,    -1,    -1,    -1,    -1,    -1,    -1,   205,
   206,    -1,    -1,    -1,   210,    -1,    -1,    -1,    -1,   215,
   216,    -1,   218,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    86,    87,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    99,
   100,   101,   102,   103,   104,   105,   106,   107,   108,    -1,
    -1,   111,   112,   113,   114,   115,   116,   117,   118,   119,
   120,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,   132,   133,   134,   135,   136,   137,   138,   139,
   140,   141,   142,   143,   144,   145,   146,   147,   148,   149,
   150,   151,   152,   153,   154,   155,   156,   157,    -1,     3,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,   174,   175,   176,   177,    22,    23,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    32,   189,
   190,   191,   192,    -1,    -1,    -1,    -1,    -1,   198,    -1,
    -1,    -1,    -1,    -1,    -1,   205,   206,    -1,    -1,    -1,
   210,    -1,    -1,    -1,    -1,    -1,   216,    -1,   218,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    86,    87,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    99,   100,   101,   102,   103,
   104,   105,   106,   107,   108,    -1,    -1,   111,   112,   113,
   114,   115,   116,   117,   118,   119,   120,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   132,   133,
   134,   135,   136,   137,   138,   139,   140,   141,   142,   143,
   144,   145,   146,   147,   148,   149,   150,   151,   152,   153,
   154,   155,   156,   157,    -1,     3,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
   174,   175,   176,   177,    22,    23,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,   189,   190,   191,   192,    -1,
    -1,    -1,    -1,    -1,   198,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,   210,    -1,    -1,    -1,
    -1,    -1,   216,    -1,   218,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    86,    87,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    99,   100,   101,   102,   103,   104,   105,   106,   107,
   108,    -1,    -1,   111,   112,   113,   114,   115,   116,   117,
   118,   119,   120,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,   132,   133,   134,   135,   136,   137,
   138,   139,   140,   141,   142,   143,   144,   145,   146,   147,
   148,   149,   150,   151,   152,   153,   154,   155,   156,   157,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,   174,   175,   176,   177,
    -1,    -1,    -1,    -1,    -1,     3,    -1,    -1,    -1,    -1,
    -1,   189,   190,   191,   192,    -1,    -1,    -1,    -1,    -1,
   198,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,   210,    -1,    -1,    -1,    -1,    -1,   216,    -1,
   218,    39,    40,    41,    42,    43,    44,    45,    46,    47,
    48,    49,    50,    51,    52,    53,    54,    55,    56,    57,
    58,    59,    -1,    -1,    62,    63,    64,    65,    66,    67,
    68,    69,    70,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    86,    87,
    88,    89,    90,    91,    92,    93,    94,    95,    96,    97,
    98,    99,   100,   101,   102,   103,   104,   105,   106,   107,
   108,   109,   110,   111,   112,   113,   114,   115,   116,   117,
   118,   119,   120,   121,   122,   123,   124,   125,   126,   127,
   128,   129,   130,   131,   132,   133,   134,   135,   136,   137,
   138,   139,   140,   141,   142,   143,   144,   145,   146,   147,
   148,   149,   150,   151,   152,   153,   154,   155,   156,   157,
   158,   159,   160,   161,   162,   163,   164,   165,   166,   167,
   168,   169,   170,   171,   172,   173,   174,   175,     3,   177,
   178,     3,    -1,    -1,     6,     7,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    15,    -1,    17,    18,    22,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    30,    -1,
    -1,    -1,    -1,    -1,    -1,    37,    38,    -1,    -1,   217,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    86,    87,    88,    89,    90,    91,
    92,    93,    94,    95,    96,    97,    98,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,   109,   110,    -1,
    -1,    -1,    -1,   118,   119,   120,    -1,    -1,    -1,   121,
   122,   123,   124,   125,   126,   127,   128,   129,   130,   131,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   154,
   155,   156,   157,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,   165,   166,   167,   168,   169,   170,    -1,
     3,   173,    -1,    -1,    -1,    -1,   178,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,   189,   190,   191,   192,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
   205,   206,    -1,    -1,    -1,   210,    39,    40,    41,    42,
    43,    44,    45,    46,    47,    48,    49,    50,    51,    52,
    53,    54,    55,    56,    57,    58,    59,    -1,    -1,    62,
    63,    64,    65,    66,    67,    68,    69,    70,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    86,    87,    88,    89,    90,    91,    92,
    93,    94,    95,    96,    97,    98,    99,   100,   101,   102,
   103,   104,   105,   106,   107,   108,   109,   110,   111,   112,
   113,   114,   115,   116,   117,   118,   119,   120,   121,   122,
   123,   124,   125,   126,   127,   128,   129,   130,   131,   132,
   133,   134,   135,   136,   137,   138,   139,   140,   141,   142,
   143,   144,   145,   146,   147,   148,   149,   150,   151,   152,
   153,   154,   155,   156,   157,   158,   159,   160,   161,   162,
   163,   164,   165,   166,   167,   168,   169,   170,   171,   172,
   173,   174,   175,    -1,   177,   178,     1,    -1,     3,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,   189,    -1,    -1,    -1,
    -1,    16,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    27,    -1,    -1,   208,    -1,    -1,    -1,    -1,
    -1,    36,    -1,    -1,    39,    40,    41,    42,    43,    44,
    45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
    55,    56,    57,    58,    59,    -1,    -1,    62,    63,    64,
    65,    66,    67,    68,    69,    70,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    86,    87,    88,    89,    90,    91,    92,    93,    94,
    95,    96,    97,    98,    99,   100,   101,   102,   103,   104,
   105,   106,   107,   108,   109,   110,   111,   112,   113,   114,
   115,   116,   117,   118,   119,   120,   121,   122,   123,   124,
   125,   126,   127,   128,   129,   130,   131,   132,   133,   134,
   135,   136,   137,   138,   139,   140,   141,   142,   143,   144,
   145,   146,   147,   148,   149,   150,   151,   152,   153,   154,
   155,   156,   157,   158,   159,   160,   161,   162,   163,   164,
   165,   166,   167,   168,   169,   170,   171,   172,   173,   174,
   175,    -1,   177,   178,   179,     1,    -1,     3,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,   201,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    39,    40,    41,    42,    43,    44,    45,
    46,    47,    48,    49,    50,    51,    52,    53,    54,    55,
    56,    57,    58,    59,    -1,    -1,    62,    63,    64,    65,
    66,    67,    68,    69,    70,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    86,    87,    88,    89,    90,    91,    92,    93,    94,    95,
    96,    97,    98,    99,   100,   101,   102,   103,   104,   105,
   106,   107,   108,   109,   110,   111,   112,   113,   114,   115,
   116,   117,   118,   119,   120,   121,   122,   123,   124,   125,
   126,   127,   128,   129,   130,   131,   132,   133,   134,   135,
   136,   137,   138,   139,   140,   141,   142,   143,   144,   145,
   146,   147,   148,   149,   150,   151,   152,   153,   154,   155,
   156,   157,   158,   159,   160,   161,   162,   163,   164,   165,
   166,   167,   168,   169,   170,   171,   172,   173,   174,   175,
     3,   177,   178,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,   189,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    39,    40,    41,    42,
    43,    44,    45,    46,    47,    48,    49,    50,    51,    52,
    53,    54,    55,    56,    57,    58,    59,    -1,    -1,    62,
    63,    64,    65,    66,    67,    68,    69,    70,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    86,    87,    88,    89,    90,    91,    92,
    93,    94,    95,    96,    97,    98,    99,   100,   101,   102,
   103,   104,   105,   106,   107,   108,   109,   110,   111,   112,
   113,   114,   115,   116,   117,   118,   119,   120,   121,   122,
   123,   124,   125,   126,   127,   128,   129,   130,   131,   132,
   133,   134,   135,   136,   137,   138,   139,   140,   141,   142,
   143,   144,   145,   146,   147,   148,   149,   150,   151,   152,
   153,   154,   155,   156,   157,   158,   159,   160,   161,   162,
   163,   164,   165,   166,   167,   168,   169,   170,   171,   172,
   173,   174,   175,    -1,   177,   178,     1,    -1,     3,    -1,
    -1,     6,    -1,     8,    -1,    -1,   189,    -1,    13,    -1,
    -1,    16,    -1,    -1,    -1,    20,    -1,    -1,    -1,    -1,
    -1,    -1,    27,    -1,    -1,    -1,    -1,    -1,    33,    34,
    -1,    36,    -1,    -1,    39,    40,    41,    42,    43,    44,
    45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
    55,    56,    57,    58,    59,    -1,    -1,    62,    63,    64,
    65,    66,    67,    68,    69,    70,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    86,    87,    88,    89,    90,    91,    92,    93,    94,
    95,    96,    97,    98,    99,   100,   101,   102,   103,   104,
   105,   106,   107,   108,   109,   110,   111,   112,   113,   114,
   115,   116,   117,   118,   119,   120,   121,   122,   123,   124,
   125,   126,   127,   128,   129,   130,   131,   132,   133,   134,
   135,   136,   137,   138,   139,   140,   141,   142,   143,   144,
   145,   146,   147,   148,   149,   150,   151,   152,   153,   154,
   155,   156,   157,   158,   159,   160,   161,   162,   163,   164,
   165,   166,   167,   168,   169,   170,   171,   172,   173,   174,
   175,    -1,   177,   178,   179,     1,    -1,     3,    -1,    -1,
     6,    -1,     8,    -1,    -1,    -1,    -1,    13,    -1,    -1,
    16,    -1,    -1,    -1,    20,    -1,    -1,    -1,    -1,    -1,
    -1,    27,    -1,    -1,    -1,    -1,    -1,    33,    34,    -1,
    36,    -1,    -1,    39,    40,    41,    42,    43,    44,    45,
    46,    47,    48,    49,    50,    51,    52,    53,    54,    55,
    56,    57,    58,    59,    -1,    -1,    62,    63,    64,    65,
    66,    67,    68,    69,    70,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    86,    87,    88,    89,    90,    91,    92,    93,    94,    95,
    96,    97,    98,    99,   100,   101,   102,   103,   104,   105,
   106,   107,   108,   109,   110,   111,   112,   113,   114,   115,
   116,   117,   118,   119,   120,   121,   122,   123,   124,   125,
   126,   127,   128,   129,   130,   131,   132,   133,   134,   135,
   136,   137,   138,   139,   140,   141,   142,   143,   144,   145,
   146,   147,   148,   149,   150,   151,   152,   153,   154,   155,
   156,   157,   158,   159,   160,   161,   162,   163,   164,   165,
   166,   167,   168,   169,   170,   171,   172,   173,   174,   175,
    -1,   177,   178,   179,     1,    -1,     3,    -1,    -1,    -1,
    -1,     8,    -1,    -1,    -1,    -1,    13,    -1,    -1,    16,
    -1,    -1,    -1,    20,    -1,    -1,    -1,    -1,    -1,    -1,
    27,    -1,    -1,    -1,    -1,    -1,    -1,    34,    -1,    36,
    -1,    -1,    39,    40,    41,    42,    43,    44,    45,    46,
    47,    48,    49,    50,    51,    52,    53,    54,    55,    56,
    57,    58,    59,    -1,    -1,    62,    63,    64,    65,    66,
    67,    68,    69,    70,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    86,
    87,    88,    89,    90,    91,    92,    93,    94,    95,    96,
    97,    98,    99,   100,   101,   102,   103,   104,   105,   106,
   107,   108,   109,   110,   111,   112,   113,   114,   115,   116,
   117,   118,   119,   120,   121,   122,   123,   124,   125,   126,
   127,   128,   129,   130,   131,   132,   133,   134,   135,   136,
   137,   138,   139,   140,   141,   142,   143,   144,   145,   146,
   147,   148,   149,   150,   151,   152,   153,   154,   155,   156,
   157,   158,   159,   160,   161,   162,   163,   164,   165,   166,
   167,   168,   169,   170,   171,   172,   173,   174,   175,    -1,
   177,   178,   179,     1,    -1,     3,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    16,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    27,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    36,    -1,
    -1,    39,    40,    41,    42,    43,    44,    45,    46,    47,
    48,    49,    50,    51,    52,    53,    54,    55,    56,    57,
    58,    59,    -1,    -1,    62,    63,    64,    65,    66,    67,
    68,    69,    70,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    86,    87,
    88,    89,    90,    91,    92,    93,    94,    95,    96,    97,
    98,    99,   100,   101,   102,   103,   104,   105,   106,   107,
   108,   109,   110,   111,   112,   113,   114,   115,   116,   117,
   118,   119,   120,   121,   122,   123,   124,   125,   126,   127,
   128,   129,   130,   131,   132,   133,   134,   135,   136,   137,
   138,   139,   140,   141,   142,   143,   144,   145,   146,   147,
   148,   149,   150,   151,   152,   153,   154,   155,   156,   157,
   158,   159,   160,   161,   162,   163,   164,   165,   166,   167,
   168,   169,   170,   171,   172,   173,   174,   175,    -1,   177,
   178,   179,     1,    -1,     3,    -1,    -1,    -1,     7,    -1,
    -1,    -1,    -1,    -1,    13,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    39,    40,    41,    42,    43,    44,    45,    46,    47,    48,
    49,    50,    51,    52,    53,    54,    55,    56,    57,    58,
    59,    -1,    -1,    62,    63,    64,    65,    66,    67,    68,
    69,    70,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    86,    87,    88,
    89,    90,    91,    92,    93,    94,    95,    96,    97,    98,
    99,   100,   101,   102,   103,   104,   105,   106,   107,   108,
   109,   110,   111,   112,   113,   114,   115,   116,   117,   118,
   119,   120,   121,   122,   123,   124,   125,   126,   127,   128,
   129,   130,   131,   132,   133,   134,   135,   136,   137,   138,
   139,   140,   141,   142,   143,   144,   145,   146,   147,   148,
   149,   150,   151,   152,   153,   154,   155,   156,   157,   158,
   159,   160,   161,   162,   163,   164,   165,   166,   167,   168,
   169,   170,   171,   172,   173,   174,   175,    -1,   177,   178,
     1,    -1,     3,    -1,    -1,    -1,     7,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    39,    40,
    41,    42,    43,    44,    45,    46,    47,    48,    49,    50,
    51,    52,    53,    54,    55,    56,    57,    58,    59,    -1,
    -1,    62,    63,    64,    65,    66,    67,    68,    69,    70,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    86,    87,    88,    89,    90,
    91,    92,    93,    94,    95,    96,    97,    98,    99,   100,
   101,   102,   103,   104,   105,   106,   107,   108,   109,   110,
   111,   112,   113,   114,   115,   116,   117,   118,   119,   120,
   121,   122,   123,   124,   125,   126,   127,   128,   129,   130,
   131,   132,   133,   134,   135,   136,   137,   138,   139,   140,
   141,   142,   143,   144,   145,   146,   147,   148,   149,   150,
   151,   152,   153,   154,   155,   156,   157,   158,   159,   160,
   161,   162,   163,   164,   165,   166,   167,   168,   169,   170,
   171,   172,   173,   174,   175,    -1,   177,   178,     1,    -1,
     3,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    39,    40,    41,    42,
    43,    44,    45,    46,    47,    48,    49,    50,    51,    52,
    53,    54,    55,    56,    57,    58,    59,    -1,    -1,    62,
    63,    64,    65,    66,    67,    68,    69,    70,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    86,    87,    88,    89,    90,    91,    92,
    93,    94,    95,    96,    97,    98,    99,   100,   101,   102,
   103,   104,   105,   106,   107,   108,   109,   110,   111,   112,
   113,   114,   115,   116,   117,   118,   119,   120,   121,   122,
   123,   124,   125,   126,   127,   128,   129,   130,   131,   132,
   133,   134,   135,   136,   137,   138,   139,   140,   141,   142,
   143,   144,   145,   146,   147,   148,   149,   150,   151,   152,
   153,   154,   155,   156,   157,   158,   159,   160,   161,   162,
   163,   164,   165,   166,   167,   168,   169,   170,   171,   172,
   173,   174,   175,    -1,   177,   178,     1,    -1,     3,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    39,    40,    41,    42,    43,    44,
    45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
    55,    56,    57,    58,    59,    -1,    -1,    62,    63,    64,
    65,    66,    67,    68,    69,    70,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    86,    87,    88,    89,    90,    91,    92,    93,    94,
    95,    96,    97,    98,    99,   100,   101,   102,   103,   104,
   105,   106,   107,   108,   109,   110,   111,   112,   113,   114,
   115,   116,   117,   118,   119,   120,   121,   122,   123,   124,
   125,   126,   127,   128,   129,   130,   131,   132,   133,   134,
   135,   136,   137,   138,   139,   140,   141,   142,   143,   144,
   145,   146,   147,   148,   149,   150,   151,   152,   153,   154,
   155,   156,   157,   158,   159,   160,   161,   162,   163,   164,
   165,   166,   167,   168,   169,   170,   171,   172,   173,   174,
   175,    -1,   177,   178,     1,    -1,     3,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    39,    40,    41,    42,    43,    44,    45,    46,
    47,    48,    49,    50,    51,    52,    53,    54,    55,    56,
    57,    58,    59,    -1,    -1,    62,    63,    64,    65,    66,
    67,    68,    69,    70,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    86,
    87,    88,    89,    90,    91,    92,    93,    94,    95,    96,
    97,    98,    99,   100,   101,   102,   103,   104,   105,   106,
   107,   108,   109,   110,   111,   112,   113,   114,   115,   116,
   117,   118,   119,   120,   121,   122,   123,   124,   125,   126,
   127,   128,   129,   130,   131,   132,   133,   134,   135,   136,
   137,   138,   139,   140,   141,   142,   143,   144,   145,   146,
   147,   148,   149,   150,   151,   152,   153,   154,   155,   156,
   157,   158,   159,   160,   161,   162,   163,   164,   165,   166,
   167,   168,   169,   170,   171,   172,   173,   174,   175,    -1,
   177,   178,     1,    -1,     3,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    39,    40,    41,    42,    43,    44,    45,    46,    47,    48,
    49,    50,    51,    52,    53,    54,    55,    56,    57,    58,
    59,    -1,    -1,    62,    63,    64,    65,    66,    67,    68,
    69,    70,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    86,    87,    88,
    89,    90,    91,    92,    93,    94,    95,    96,    97,    98,
    99,   100,   101,   102,   103,   104,   105,   106,   107,   108,
   109,   110,   111,   112,   113,   114,   115,   116,   117,   118,
   119,   120,   121,   122,   123,   124,   125,   126,   127,   128,
   129,   130,   131,   132,   133,   134,   135,   136,   137,   138,
   139,   140,   141,   142,   143,   144,   145,   146,   147,   148,
   149,   150,   151,   152,   153,   154,   155,   156,   157,   158,
   159,   160,   161,   162,   163,   164,   165,   166,   167,   168,
   169,   170,   171,   172,   173,   174,   175,    -1,   177,   178,
     1,    -1,     3,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    39,    40,
    41,    42,    43,    44,    45,    46,    47,    48,    49,    50,
    51,    52,    53,    54,    55,    56,    57,    58,    59,    -1,
    -1,    62,    63,    64,    65,    66,    67,    68,    69,    70,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    86,    87,    88,    89,    90,
    91,    92,    93,    94,    95,    96,    97,    98,    99,   100,
   101,   102,   103,   104,   105,   106,   107,   108,   109,   110,
   111,   112,   113,   114,   115,   116,   117,   118,   119,   120,
   121,   122,   123,   124,   125,   126,   127,   128,   129,   130,
   131,   132,   133,   134,   135,   136,   137,   138,   139,   140,
   141,   142,   143,   144,   145,   146,   147,   148,   149,   150,
   151,   152,   153,   154,   155,   156,   157,   158,   159,   160,
   161,   162,   163,   164,   165,   166,   167,   168,   169,   170,
   171,   172,   173,   174,   175,    -1,   177,   178,     1,    -1,
     3,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    39,    40,    41,    42,
    43,    44,    45,    46,    47,    48,    49,    50,    51,    52,
    53,    54,    55,    56,    57,    58,    59,    -1,    -1,    62,
    63,    64,    65,    66,    67,    68,    69,    70,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    86,    87,    88,    89,    90,    91,    92,
    93,    94,    95,    96,    97,    98,    99,   100,   101,   102,
   103,   104,   105,   106,   107,   108,   109,   110,   111,   112,
   113,   114,   115,   116,   117,   118,   119,   120,   121,   122,
   123,   124,   125,   126,   127,   128,   129,   130,   131,   132,
   133,   134,   135,   136,   137,   138,   139,   140,   141,   142,
   143,   144,   145,   146,   147,   148,   149,   150,   151,   152,
   153,   154,   155,   156,   157,   158,   159,   160,   161,   162,
   163,   164,   165,   166,   167,   168,   169,   170,   171,   172,
   173,   174,   175,    -1,   177,   178,     1,    -1,     3,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    39,    40,    41,    42,    43,    44,
    45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
    55,    56,    57,    58,    59,    -1,    -1,    62,    63,    64,
    65,    66,    67,    68,    69,    70,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    86,    87,    88,    89,    90,    91,    92,    93,    94,
    95,    96,    97,    98,    99,   100,   101,   102,   103,   104,
   105,   106,   107,   108,   109,   110,   111,   112,   113,   114,
   115,   116,   117,   118,   119,   120,   121,   122,   123,   124,
   125,   126,   127,   128,   129,   130,   131,   132,   133,   134,
   135,   136,   137,   138,   139,   140,   141,   142,   143,   144,
   145,   146,   147,   148,   149,   150,   151,   152,   153,   154,
   155,   156,   157,   158,   159,   160,   161,   162,   163,   164,
   165,   166,   167,   168,   169,   170,   171,   172,   173,   174,
   175,    -1,   177,   178,     1,    -1,     3,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    39,    40,    41,    42,    43,    44,    45,    46,
    47,    48,    49,    50,    51,    52,    53,    54,    55,    56,
    57,    58,    59,    -1,    -1,    62,    63,    64,    65,    66,
    67,    68,    69,    70,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    86,
    87,    88,    89,    90,    91,    92,    93,    94,    95,    96,
    97,    98,    99,   100,   101,   102,   103,   104,   105,   106,
   107,   108,   109,   110,   111,   112,   113,   114,   115,   116,
   117,   118,   119,   120,   121,   122,   123,   124,   125,   126,
   127,   128,   129,   130,   131,   132,   133,   134,   135,   136,
   137,   138,   139,   140,   141,   142,   143,   144,   145,   146,
   147,   148,   149,   150,   151,   152,   153,   154,   155,   156,
   157,   158,   159,   160,   161,   162,   163,   164,   165,   166,
   167,   168,   169,   170,   171,   172,   173,   174,   175,    -1,
   177,   178,     1,    -1,     3,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    39,    40,    41,    42,    43,    44,    45,    46,    47,    48,
    49,    50,    51,    52,    53,    54,    55,    56,    57,    58,
    59,    -1,    -1,    62,    63,    64,    65,    66,    67,    68,
    69,    70,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    86,    87,    88,
    89,    90,    91,    92,    93,    94,    95,    96,    97,    98,
    99,   100,   101,   102,   103,   104,   105,   106,   107,   108,
   109,   110,   111,   112,   113,   114,   115,   116,   117,   118,
   119,   120,   121,   122,   123,   124,   125,   126,   127,   128,
   129,   130,   131,   132,   133,   134,   135,   136,   137,   138,
   139,   140,   141,   142,   143,   144,   145,   146,   147,   148,
   149,   150,   151,   152,   153,   154,   155,   156,   157,   158,
   159,   160,   161,   162,   163,   164,   165,   166,   167,   168,
   169,   170,   171,   172,   173,   174,   175,    -1,   177,   178,
     1,    -1,     3,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    39,    40,
    41,    42,    43,    44,    45,    46,    47,    48,    49,    50,
    51,    52,    53,    54,    55,    56,    57,    58,    59,    -1,
    -1,    62,    63,    64,    65,    66,    67,    68,    69,    70,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    86,    87,    88,    89,    90,
    91,    92,    93,    94,    95,    96,    97,    98,    99,   100,
   101,   102,   103,   104,   105,   106,   107,   108,   109,   110,
   111,   112,   113,   114,   115,   116,   117,   118,   119,   120,
   121,   122,   123,   124,   125,   126,   127,   128,   129,   130,
   131,   132,   133,   134,   135,   136,   137,   138,   139,   140,
   141,   142,   143,   144,   145,   146,   147,   148,   149,   150,
   151,   152,   153,   154,   155,   156,   157,   158,   159,   160,
   161,   162,   163,   164,   165,   166,   167,   168,   169,   170,
   171,   172,   173,   174,   175,    -1,   177,   178,     1,    -1,
     3,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    39,    40,    41,    42,
    43,    44,    45,    46,    47,    48,    49,    50,    51,    52,
    53,    54,    55,    56,    57,    58,    59,    -1,    -1,    62,
    63,    64,    65,    66,    67,    68,    69,    70,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    86,    87,    88,    89,    90,    91,    92,
    93,    94,    95,    96,    97,    98,    99,   100,   101,   102,
   103,   104,   105,   106,   107,   108,   109,   110,   111,   112,
   113,   114,   115,   116,   117,   118,   119,   120,   121,   122,
   123,   124,   125,   126,   127,   128,   129,   130,   131,   132,
   133,   134,   135,   136,   137,   138,   139,   140,   141,   142,
   143,   144,   145,   146,   147,   148,   149,   150,   151,   152,
   153,   154,   155,   156,   157,   158,   159,   160,   161,   162,
   163,   164,   165,   166,   167,   168,   169,   170,   171,   172,
   173,   174,   175,     3,   177,   178,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    16,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    27,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    39,
    40,    41,    42,    43,    44,    45,    46,    47,    48,    49,
    50,    51,    52,    53,    54,    55,    56,    57,    58,    59,
    -1,    -1,    62,    63,    64,    65,    66,    67,    68,    69,
    70,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    86,    87,    88,    89,
    90,    91,    92,    93,    94,    95,    96,    97,    98,    99,
   100,   101,   102,   103,   104,   105,   106,   107,   108,   109,
   110,   111,   112,   113,   114,   115,   116,   117,   118,   119,
   120,   121,   122,   123,   124,   125,   126,   127,   128,   129,
   130,   131,   132,   133,   134,   135,   136,   137,   138,   139,
   140,   141,   142,   143,   144,   145,   146,   147,   148,   149,
   150,   151,   152,   153,   154,   155,   156,   157,   158,   159,
   160,   161,   162,   163,   164,   165,   166,   167,   168,   169,
   170,   171,   172,   173,   174,   175,     3,   177,   178,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    36,
    -1,    -1,    39,    40,    41,    42,    43,    44,    45,    46,
    47,    48,    49,    50,    51,    52,    53,    54,    55,    56,
    57,    58,    59,    -1,    -1,    62,    63,    64,    65,    66,
    67,    68,    69,    70,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    86,
    87,    88,    89,    90,    91,    92,    93,    94,    95,    96,
    97,    98,    99,   100,   101,   102,   103,   104,   105,   106,
   107,   108,   109,   110,   111,   112,   113,   114,   115,   116,
   117,   118,   119,   120,   121,   122,   123,   124,   125,   126,
   127,   128,   129,   130,   131,   132,   133,   134,   135,   136,
   137,   138,   139,   140,   141,   142,   143,   144,   145,   146,
   147,   148,   149,   150,   151,   152,   153,   154,   155,   156,
   157,   158,   159,   160,   161,   162,   163,   164,   165,   166,
   167,   168,   169,   170,   171,   172,   173,   174,   175,     3,
   177,   178,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    39,    40,    41,    42,    43,
    44,    45,    46,    47,    48,    49,    50,    51,    52,    53,
    54,    55,    56,    57,    58,    59,    -1,    -1,    62,    63,
    64,    65,    66,    67,    68,    69,    70,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    86,    87,    88,    89,    90,    91,    92,    93,
    94,    95,    96,    97,    98,    99,   100,   101,   102,   103,
   104,   105,   106,   107,   108,   109,   110,   111,   112,   113,
   114,   115,   116,   117,   118,   119,   120,   121,   122,   123,
   124,   125,   126,   127,   128,   129,   130,   131,   132,   133,
   134,   135,   136,   137,   138,   139,   140,   141,   142,   143,
   144,   145,   146,   147,   148,   149,   150,   151,   152,   153,
   154,   155,   156,   157,   158,   159,   160,   161,   162,   163,
   164,   165,   166,   167,   168,   169,   170,   171,   172,   173,
   174,   175,     3,   177,   178,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    39,    40,
    41,    42,    43,    44,    45,    46,    47,    48,    49,    50,
    51,    52,    53,    54,    55,    56,    57,    58,    59,    -1,
    -1,    62,    63,    64,    65,    66,    67,    68,    69,    70,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    86,    87,    88,    89,    90,
    91,    92,    93,    94,    95,    96,    97,    98,    99,   100,
   101,   102,   103,   104,   105,   106,   107,   108,   109,   110,
   111,   112,   113,   114,   115,   116,   117,   118,   119,   120,
   121,   122,   123,   124,   125,   126,   127,   128,   129,   130,
   131,   132,   133,   134,   135,   136,   137,   138,   139,   140,
   141,   142,   143,   144,   145,   146,   147,   148,   149,   150,
   151,   152,   153,   154,   155,   156,   157,   158,   159,   160,
   161,   162,   163,   164,   165,   166,   167,   168,   169,   170,
   171,   172,   173,   174,   175,     3,   177,   178,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    39,    40,    41,    42,    43,    44,    45,    46,    47,
    48,    49,    50,    51,    52,    53,    54,    55,    56,    57,
    58,    59,    -1,    -1,    62,    63,    64,    65,    66,    67,
    68,    69,    70,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    86,    87,
    88,    89,    90,    91,    92,    93,    94,    95,    96,    97,
    98,    99,   100,   101,   102,   103,   104,   105,   106,   107,
   108,   109,   110,   111,   112,   113,   114,   115,   116,   117,
   118,   119,   120,   121,   122,   123,   124,   125,   126,   127,
   128,   129,   130,   131,   132,   133,   134,   135,   136,   137,
   138,   139,   140,   141,   142,   143,   144,   145,   146,   147,
   148,   149,   150,   151,   152,   153,   154,   155,   156,   157,
   158,   159,   160,   161,   162,   163,   164,   165,   166,   167,
   168,   169,   170,   171,   172,   173,   174,   175,    -1,   177,
   178
};
/* -*-C-*-  Note some compilers choke on comments on `#line' lines.  */
#line 3 "/usr/local/lib/bison.simple"

/* Skeleton output parser for bison,
   Copyright (C) 1984, 1989, 1990 Bob Corbett and Richard Stallman

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 1, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.  */


#ifndef alloca
#ifdef __GNUC__
#define alloca __builtin_alloca
#else /* Not GNU C.  */
#if (!defined (__STDC__) && defined (sparc)) || defined (__sparc__)
#include <alloca.h>
#else /* Not sparc */
#ifdef MSDOS
#include <malloc.h>
#endif /* MSDOS */
#endif /* Not sparc.  */
#endif /* Not GNU C.  */
#endif /* alloca not defined.  */

/* This is the parser code that is written into each bison parser
  when the %semantic_parser declaration is not specified in the grammar.
  It was written by Richard Stallman by simplifying the hairy parser
  used when %semantic_parser is specified.  */

/* Note: there must be only one dollar sign in this file.
   It is replaced by the list of actions, each action
   as one case of the switch.  */

#define yyerrok		(yyerrstatus = 0)
#define yyclearin	(yychar = YYEMPTY)
#define YYEMPTY		-2
#define YYEOF		0
#define YYACCEPT	return(0)
#define YYABORT 	return(1)
#define YYERROR		goto yyerrlab1
/* Like YYERROR except do call yyerror.
   This remains here temporarily to ease the
   transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  */
#define YYFAIL		goto yyerrlab
#define YYRECOVERING()  (!!yyerrstatus)
#define YYBACKUP(token, value) \
do								\
  if (yychar == YYEMPTY && yylen == 1)				\
    { yychar = (token), yylval = (value);			\
      yychar1 = YYTRANSLATE (yychar);				\
      YYPOPSTACK;						\
      goto yybackup;						\
    }								\
  else								\
    { yyerror ("syntax error: cannot back up"); YYERROR; }	\
while (0)

#define YYTERROR	1
#define YYERRCODE	256

#ifndef YYPURE
#define YYLEX		yylex()
#endif

#ifdef YYPURE
#ifdef YYLSP_NEEDED
#define YYLEX		yylex(&yylval, &yylloc)
#else
#define YYLEX		yylex(&yylval)
#endif
#endif

/* If nonreentrant, generate the variables here */

#ifndef YYPURE

int	yychar;			/*  the lookahead symbol		*/
YYSTYPE	yylval;			/*  the semantic value of the		*/
				/*  lookahead symbol			*/

#ifdef YYLSP_NEEDED
YYLTYPE yylloc;			/*  location data for the lookahead	*/
				/*  symbol				*/
#endif

int yynerrs;			/*  number of parse errors so far       */
#endif  /* not YYPURE */

#if YYDEBUG != 0
int yydebug;			/*  nonzero means print parse trace	*/
/* Since this is uninitialized, it does not stop multiple parsers
   from coexisting.  */
#endif

/*  YYINITDEPTH indicates the initial size of the parser's stacks	*/

#ifndef	YYINITDEPTH
#define YYINITDEPTH 200
#endif

/*  YYMAXDEPTH is the maximum size the stacks can grow to
    (effective only if the built-in stack extension method is used).  */

#if YYMAXDEPTH == 0
#undef YYMAXDEPTH
#endif

#ifndef YYMAXDEPTH
#define YYMAXDEPTH 10000
#endif

#ifndef __cplusplus

/* This is the most reliable way to avoid incompatibilities
   in available built-in functions on various systems.  */
static void
__yy_bcopy (from, to, count)
     char *from;
     char *to;
     int count;
{
  register char *f = from;
  register char *t = to;
  register int i = count;

  while (i-- > 0)
    *t++ = *f++;
}

#else /* __cplusplus */

/* This is the most reliable way to avoid incompatibilities
   in available built-in functions on various systems.  */
static void
__yy_bcopy (char *from, char *to, int count)
{
  register char *f = from;
  register char *t = to;
  register int i = count;

  while (i-- > 0)
    *t++ = *f++;
}

#endif

#line 160 "/usr/local/lib/bison.simple"
int
yyparse()
{
  register int yystate;
  register int yyn;
  register short *yyssp;
  register YYSTYPE *yyvsp;
  int yyerrstatus;	/*  number of tokens to shift before error messages enabled */
  int yychar1;		/*  lookahead token as an internal (translated) token number */

  short	yyssa[YYINITDEPTH];	/*  the state stack			*/
  YYSTYPE yyvsa[YYINITDEPTH];	/*  the semantic value stack		*/

  short *yyss = yyssa;		/*  refer to the stacks thru separate pointers */
  YYSTYPE *yyvs = yyvsa;	/*  to allow yyoverflow to reallocate them elsewhere */

#ifdef YYLSP_NEEDED
  YYLTYPE *yyls = yylsa;
  YYLTYPE *yylsp;
  YYLTYPE yylsa[YYINITDEPTH];	/*  the location stack			*/

#define YYPOPSTACK   (yyvsp--, yysp--, yylsp--)
#else
#define YYPOPSTACK   (yyvsp--, yysp--)
#endif

  int yystacksize = YYINITDEPTH;

#ifdef YYPURE
  int yychar;
  YYSTYPE yylval;
  int yynerrs;
#ifdef YYLSP_NEEDED
  YYLTYPE yylloc;
#endif
#endif

  YYSTYPE yyval;		/*  the variable used to return		*/
				/*  semantic values from the action	*/
				/*  routines				*/

  int yylen;

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Starting parse\n");
#endif

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY;		/* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.  */

  yyssp = yyss - 1;
  yyvsp = yyvs;
#ifdef YYLSP_NEEDED
  yylsp = yyls;
#endif

/* Push a new state, which is found in  yystate  .  */
/* In all cases, when you get here, the value and location stacks
   have just been pushed. so pushing a state here evens the stacks.  */
yynewstate:

  *++yyssp = yystate;

  if (yyssp >= yyss + yystacksize - 1)
    {
      /* Give user a chance to reallocate the stack */
      /* Use copies of these so that the &'s don't force the real ones into memory. */
      YYSTYPE *yyvs1 = yyvs;
      short *yyss1 = yyss;
#ifdef YYLSP_NEEDED
      YYLTYPE *yyls1 = yyls;
#endif

      /* Get the current used size of the three stacks, in elements.  */
      int size = yyssp - yyss + 1;

#ifdef yyoverflow
      /* Each stack pointer address is followed by the size of
	 the data in use in that stack, in bytes.  */
      yyoverflow("parser stack overflow",
		 &yyss1, size * sizeof (*yyssp),
		 &yyvs1, size * sizeof (*yyvsp),
#ifdef YYLSP_NEEDED
		 &yyls1, size * sizeof (*yylsp),
#endif
		 &yystacksize);

      yyss = yyss1; yyvs = yyvs1;
#ifdef YYLSP_NEEDED
      yyls = yyls1;
#endif
#else /* no yyoverflow */
      /* Extend the stack our own way.  */
      if (yystacksize >= YYMAXDEPTH)
	{
	  yyerror("parser stack overflow");
	  return 2;
	}
      yystacksize *= 2;
      if (yystacksize > YYMAXDEPTH)
	yystacksize = YYMAXDEPTH;
      yyss = (short *) alloca (yystacksize * sizeof (*yyssp));
      __yy_bcopy ((char *)yyss1, (char *)yyss, size * sizeof (*yyssp));
      yyvs = (YYSTYPE *) alloca (yystacksize * sizeof (*yyvsp));
      __yy_bcopy ((char *)yyvs1, (char *)yyvs, size * sizeof (*yyvsp));
#ifdef YYLSP_NEEDED
      yyls = (YYLTYPE *) alloca (yystacksize * sizeof (*yylsp));
      __yy_bcopy ((char *)yyls1, (char *)yyls, size * sizeof (*yylsp));
#endif
#endif /* no yyoverflow */

      yyssp = yyss + size - 1;
      yyvsp = yyvs + size - 1;
#ifdef YYLSP_NEEDED
      yylsp = yyls + size - 1;
#endif

#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Stack size increased to %d\n", yystacksize);
#endif

      if (yyssp >= yyss + yystacksize - 1)
	YYABORT;
    }

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Entering state %d\n", yystate);
#endif

 yybackup:

/* Do appropriate processing given the current state.  */
/* Read a lookahead token if we need one and don't already have one.  */
/* yyresume: */

  /* First try to decide what to do without reference to lookahead token.  */

  yyn = yypact[yystate];
  if (yyn == YYFLAG)
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* yychar is either YYEMPTY or YYEOF
     or a valid token in external form.  */

  if (yychar == YYEMPTY)
    {
#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Reading a token: ");
#endif
      yychar = YYLEX;
    }

  /* Convert token to internal form (in yychar1) for indexing tables with */

  if (yychar <= 0)		/* This means end of input. */
    {
      yychar1 = 0;
      yychar = YYEOF;		/* Don't call YYLEX any more */

#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Now at end of input.\n");
#endif
    }
  else
    {
      yychar1 = YYTRANSLATE(yychar);

#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Next token is %d (%s)\n", yychar, yytname[yychar1]);
#endif
    }

  yyn += yychar1;
  if (yyn < 0 || yyn > YYLAST || yycheck[yyn] != yychar1)
    goto yydefault;

  yyn = yytable[yyn];

  /* yyn is what to do for this token type in this state.
     Negative => reduce, -yyn is rule number.
     Positive => shift, yyn is new state.
       New state is final state => don't bother to shift,
       just return success.
     0, or most negative number => error.  */

  if (yyn < 0)
    {
      if (yyn == YYFLAG)
	goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }
  else if (yyn == 0)
    goto yyerrlab;

  if (yyn == YYFINAL)
    YYACCEPT;

  /* Shift the lookahead token.  */

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Shifting token %d (%s), ", yychar, yytname[yychar1]);
#endif

  /* Discard the token being shifted unless it is eof.  */
  if (yychar != YYEOF)
    yychar = YYEMPTY;

  *++yyvsp = yylval;
#ifdef YYLSP_NEEDED
  *++yylsp = yylloc;
#endif

  /* count tokens shifted since error; after three, turn off error status.  */
  if (yyerrstatus) yyerrstatus--;

  yystate = yyn;
  goto yynewstate;

/* Do the default action for the current state.  */
yydefault:

  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;

/* Do a reduction.  yyn is the number of a rule to reduce with.  */
yyreduce:
  yylen = yyr2[yyn];
  yyval = yyvsp[1-yylen]; /* implement default value of the action */

#if YYDEBUG != 0
  if (yydebug)
    {
      int i;

      fprintf (stderr, "Reducing via rule %d (line %d), ",
	       yyn, yyrline[yyn]);

      /* Print the symboles being reduced, and their result.  */
      for (i = yyprhs[yyn]; yyrhs[i] > 0; i++)
	fprintf (stderr, "%s ", yytname[yyrhs[i]]);
      fprintf (stderr, " -> %s\n", yytname[yyr1[yyn]]);
    }
#endif


  switch (yyn) {

case 1:
#line 521 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ warning ("Empty input file"); ;
    break;}
case 8:
#line 540 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ warning ("Missing `.' at the end of program"); ;
    break;}
case 9:
#line 547 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ 
		  tree parms;

		  current_module_name = NULL_TREE;
		  if (main_program_name)
		    {
		      error ("Only one program declaration allowed");
		      YYERROR1;
		    }

		  main_program_name = get_main_program_name (TREE_VALUE (yyvsp[-1].ttype));

		  if (pedantic && TREE_PURPOSE (yyvsp[-1].ttype) == NULL_TREE)
		    warning ("No program parameters specified");

		  /* handle parameter list here */
		  pushlevel (0);
		  clear_parm_order ();
	          declare_parm_level (1);
		  parms = get_parm_info (1);
		  poplevel (0, 0, 0);

		  main_program_context = build_nt (CALL_EXPR, main_program_name,
						   parms, NULL_TREE);

		  if (! start_function (build_tree_list (NULL_TREE, void_type_node),
					main_program_context, 0))
		    YYERROR1;

		  reinit_parse_for_function ();
		  store_parm_decls ();

		  /* All labels get defined as possible targets to a
		   * non-local goto.
		   */
		  top_level_labels = 0;
		;
    break;}
case 10:
#line 585 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ 
		  push_label_level ();

		  current_module_parms = TREE_PURPOSE (yyvsp[-3].ttype);
		  associate_external_objects (current_module_parms);
		;
    break;}
case 11:
#line 592 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{
		  associate_external_objects (current_module_parms);
		  /* Now we know if program parameters are undefined */
		  check_external_objects (TREE_PURPOSE (yyvsp[-5].ttype), 1);

		  un_initialize_block (getdecls (), 0);
		;
    break;}
case 12:
#line 600 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{
		  yyerrok;
		  un_initialize_block (getdecls (), 1);
		  pop_label_level ();
		;
    break;}
case 13:
#line 606 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{
		  finish_function (0);
		  /* Generate main() that calls the user main program.
		   * To create external pascal routines use "module foo"
		   * instead of "program foo";
		   */
		  output_real_main_program (main_program_name);
		;
    break;}
case 14:
#line 618 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = build_tree_list (yyvsp[0].ttype, yyvsp[-1].ttype); ;
    break;}
case 15:
#line 620 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ error ("missing program name");
		  yyerrok;
		;
    break;}
case 16:
#line 624 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = build_tree_list (yyvsp[0].ttype, get_identifier ("noname")); ;
    break;}
case 17:
#line 629 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = NULL_TREE; ;
    break;}
case 19:
#line 635 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = yyvsp[-1].ttype; ;
    break;}
case 20:
#line 640 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = build_tree_list (NULL_TREE, yyvsp[0].ttype); ;
    break;}
case 21:
#line 642 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = chainon (yyvsp[-2].ttype, build_tree_list (NULL_TREE, yyvsp[0].ttype)); ;
    break;}
case 22:
#line 644 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ error ("comma missing after identifier `%s'", 
			   IDENTIFIER_POINTER (TREE_VALUE(yyvsp[-2].ttype)));
                  yyval.ttype = chainon (yyvsp[-2].ttype, build_tree_list (NULL_TREE, yyvsp[0].ttype)); 
                  yyerrok; ;
    break;}
case 23:
#line 649 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ error ("extra comma following id_list");
                  yyval.ttype = yyvsp[-2].ttype; ;
    break;}
case 24:
#line 653 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ /* error ("improperly terminated id_list"); */
                  yyval.ttype = yyvsp[-1].ttype; ;
    break;}
case 25:
#line 659 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{
		  /* This happens when VALUE initializer is appended to
		     variable declaration: The parser finds that out only
		     after reading the "VALUE", and backtracs, but then
		     lastiddecl is gone already. No big deal, recheck it now.
		   */
		  if (! lastiddecl)
		    lastiddecl = check_if_predefined_type (yyvsp[0].ttype);
		      
		  if (lastiddecl != 0 && TREE_CODE (lastiddecl) == TYPE_DECL)
		    {
		      yyval.ttype = TREE_TYPE (lastiddecl);

		      if (TREE_CODE (yyval.ttype) == POINTER_TYPE)
			{
			  /* If this type name refers to a pointer
			   * that was forward defined return the type
			   * it points to instead of the name
			   *
			   * This solves the following problem:
			   *
			   * foo = ^bar;
			   * bar = record
			   *          z: foo;
			   *       end;
			   */

			  tree fptr = lookup_forward_pointer
			    		(DECL_NAME (lastiddecl), 0);
			  if (fptr)
			    yyval.ttype = fptr;
			}
		    }
		  else
		    {
		      error ("type name expected -- identifier `%s' given", 
			     IDENTIFIER_POINTER (yyvsp[0].ttype));
		      yyval.ttype = error_mark_node;
		    }
		;
    break;}
case 26:
#line 703 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{
		    yyval.ttype = check_identifier (lastiddecl, yyvsp[0].ttype);
		;
    break;}
case 150:
#line 868 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ ;
    break;}
case 164:
#line 901 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ error ("missing label declaration"); ;
    break;}
case 165:
#line 906 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ declare_label (yyvsp[0].ttype, top_level_labels); ;
    break;}
case 166:
#line 908 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ declare_label (yyvsp[0].ttype, top_level_labels);
		  yyerrok; ;
    break;}
case 167:
#line 911 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ error ("non-label in label_list"); ;
    break;}
case 168:
#line 913 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ error ("missing comma");
                  declare_label (yyvsp[0].ttype, top_level_labels); 
                  yyerrok; ;
    break;}
case 169:
#line 917 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ error ("extra comma"); ;
    break;}
case 170:
#line 919 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ /* error ("improperly terminated label_list"); */ ;
    break;}
case 171:
#line 927 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ char *ptr;
		if (pedantic &&
		    ((TREE_INT_CST_HIGH (yyvsp[0].ttype) != 0) ||
		     (TREE_INT_CST_LOW  (yyvsp[0].ttype) > 9999)))
		  warning("ISO Pascal does not allow label values greater than 9999");
		for (ptr = token_buffer; *ptr == '0'; ptr++);
		if (*ptr == '\0') --ptr;
		yyval.ttype = get_identifier (ptr); ;
    break;}
case 172:
#line 936 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ if (pedantic)
		  warning("ISO Pascal does not allow non-numeric labels");
		yyval.ttype = yyvsp[0].ttype;
	      ;
    break;}
case 174:
#line 948 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ error ("missing constant definition"); ;
    break;}
case 179:
#line 960 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ tree d = start_decl (yyvsp[-3].ttype, tree_cons (NULL_TREE, TREE_TYPE (yyvsp[-1].ttype),
				             build_tree_list (NULL_TREE,
							      const_id)),
				       1);
		  TREE_CONSTANT (d) = TREE_CONSTANT (yyvsp[-1].ttype);
		  finish_decl (d, yyvsp[-1].ttype, NULL_TREE);
		  if (pedantic && TREE_CONSTANT (d) == 0)
		     warning ("constant declared as a read-only variable");
		;
    break;}
case 181:
#line 974 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = build_pascal_unary_op (yyvsp[-1].code, yyvsp[0].ttype, 0); ;
    break;}
case 184:
#line 981 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = build_pascal_unary_op (yyvsp[-1].code, yyvsp[0].ttype, 0); ;
    break;}
case 188:
#line 989 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = copy_node (integer_maxint_node); ;
    break;}
case 189:
#line 991 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ if (pedantic)
		    warning ("ISO Pascal does not define MAXREAL");
		  yyval.ttype = copy_node (real_max_node);
		;
    break;}
case 190:
#line 996 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ if (pedantic)
		    warning ("ISO Pascal does not define MINREAL");
		  yyval.ttype = copy_node (real_min_node);
		;
    break;}
case 191:
#line 1001 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ if (pedantic)
		    warning ("ISO Pascal does not define EPSREAL");
		  yyval.ttype = copy_node (real_eps_node);
		;
    break;}
case 192:
#line 1006 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ if (pedantic)
		    warning ("ISO Pascal does not define MAXCHAR");
		  yyval.ttype = copy_node (char_max_node);
		;
    break;}
case 193:
#line 1014 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.code = CONVERT_EXPR; ;
    break;}
case 194:
#line 1016 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.code = NEGATE_EXPR; ;
    break;}
case 195:
#line 1021 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = combine_strings (yyvsp[0].ttype); ;
    break;}
case 198:
#line 1028 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = copy_node (null_pointer_node); ;
    break;}
case 199:
#line 1030 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = copy_node (boolean_false_node); ;
    break;}
case 200:
#line 1032 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = copy_node (boolean_true_node); ;
    break;}
case 202:
#line 1038 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = chainon (yyvsp[-1].ttype, yyvsp[0].ttype); ;
    break;}
case 204:
#line 1047 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ error ("missing type definition"); ;
    break;}
case 206:
#line 1053 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyerrok; ;
    break;}
case 208:
#line 1056 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ error ("missing semicolon");
                  yyerrok; ;
    break;}
case 209:
#line 1059 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ error ("extra semicolon"); ;
    break;}
case 210:
#line 1061 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ /* error ("improperly terminated type_definition_list"); */ ;
    break;}
case 211:
#line 1069 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ tree d;
		  tree type = TREE_VALUE (yyvsp[-1].ttype);

		  /* Pascal allows this: TYPE foo = ^foo;
		   * which creates a pointer to a new type.
		   *
		   * @@ This code works, but it is not correct.
		   */
		  if (TREE_CODE (type) == POINTER_TYPE
		      && TREE_CODE (TREE_TYPE (type)) == IDENTIFIER_NODE
		      && yyvsp[-3].ttype == TREE_TYPE (type))
		    type = build_pascal_pointer_type (integer_type_node);

		  d = start_decl (yyvsp[-3].ttype, tree_cons (NULL_TREE, type,
						 build_tree_list(NULL_TREE,
								 type_id)),
				  0);

		  /* If value_specification is given, attach that to the
		   * TYPE_DECL node just created.
		   */
		  DECL_INITIAL (d) = yyvsp[0].ttype;

		  resolve_forward_pointer (yyvsp[-3].ttype, type);

		  finish_decl (d, NULL_TREE, NULL_TREE);
		;
    break;}
case 212:
#line 1104 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ tree type   = yyvsp[0].ttype;
		  int variant = yyvsp[-1].itype & TYPE_VARIANT;
		  int ext     = yyvsp[-1].itype & TYPE_SELECT;

		  if (variant)
		    type = pascal_type_variant (type, variant, 1);

		  if (lastiddecl)
		    {
		      if (ext)
			type = pascal_type_extension (type, ext);
		      
		      yyval.ttype = build_tree_list (DECL_INITIAL (lastiddecl), type);
		    }
		  else /* error() has been called already; avoid crashing */
		    yyval.ttype = build_tree_list (NULL_TREE, type);
		;
    break;}
case 213:
#line 1123 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ tree type = yyvsp[0].ttype;

		  if (yyvsp[-1].itype & ~(TYPE_QUALIFIER_BINDABLE))
		    error ("Only `Bindable' type qualifier allowed with a new type");

		  if (yyvsp[-1].itype & TYPE_QUALIFIER_BINDABLE)
		    type = pascal_type_variant (type, TYPE_QUALIFIER_BINDABLE, 1);

		  yyval.ttype = build_tree_list (NULL_TREE, type);
		;
    break;}
case 215:
#line 1138 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.itype = TYPE_QUALIFIER_BINDABLE | yyvsp[0].itype; ;
    break;}
case 216:
#line 1140 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.itype = TYPE_QUALIFIER_BINDABLE | TYPE_QUALIFIER_RESTRICTED; ;
    break;}
case 217:
#line 1142 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.itype = TYPE_QUALIFIER_RESTRICTED; ;
    break;}
case 218:
#line 1147 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.itype = 0; ;
    break;}
case 219:
#line 1149 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.itype = TYPE_QUALIFIER_BYTE; ;
    break;}
case 220:
#line 1151 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.itype = TYPE_QUALIFIER_SHORT; ;
    break;}
case 221:
#line 1153 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.itype = TYPE_QUALIFIER_LONG; ;
    break;}
case 222:
#line 1155 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.itype = TYPE_QUALIFIER_LONGLONG; ;
    break;}
case 223:
#line 1157 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.itype = TYPE_QUALIFIER_UNSIGNED; ;
    break;}
case 231:
#line 1179 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ if (current_enum_type) /* @@@ does it need a stack? */
		    abort ();
		  current_enum_type = yyval.ttype = start_enum (NULL_TREE);
		;
    break;}
case 232:
#line 1184 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = finish_enum (yyvsp[-2].ttype, nreverse (yyvsp[-1].ttype));
		  current_enum_type = NULL_TREE;
		  resume_momentary (yyvsp[-3].itype); ;
    break;}
case 233:
#line 1188 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = error_mark_node; ;
    break;}
case 235:
#line 1197 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = chainon (yyvsp[0].ttype, yyvsp[-2].ttype);
		  yyerrok; ;
    break;}
case 236:
#line 1200 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ error ("non-enumerator in enumerator_list"); ;
    break;}
case 237:
#line 1202 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = chainon (yyvsp[0].ttype, yyvsp[-2].ttype); 
                  error ("missing comma");
                  yyerrok; ;
    break;}
case 238:
#line 1206 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = yyvsp[-2].ttype;
                  error ("extra comma"); ;
    break;}
case 239:
#line 1209 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = yyvsp[-1].ttype;
                  /* error ("improperly terminated enum_list"); */ ;
    break;}
case 240:
#line 1217 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = build_enumerator (yyvsp[0].ttype, NULL_TREE); ;
    break;}
case 241:
#line 1232 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ if (pedantic && (! TREE_CONSTANT (yyvsp[0].ttype) || ! TREE_CONSTANT (yyvsp[-2].ttype)))
		      warning ("ISO Pascal does not allow non-constant range bounds\n");
		  if (TREE_TYPE (yyvsp[-2].ttype) != TREE_TYPE (yyvsp[0].ttype)) {
		    error ("subrange bounds are not of the same type");
		    yyval.ttype = error_mark_node;
		  } else
		    /* @@@ Changed in 2.4.3.1 */
		    yyval.ttype = build_range_type (TREE_TYPE (yyvsp[-2].ttype), yyvsp[-2].ttype, yyvsp[0].ttype);
		;
    break;}
case 242:
#line 1247 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = build_pascal_pointer_type (yyvsp[0].ttype); ;
    break;}
case 245:
#line 1259 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ if (lastiddecl != 0 && TREE_CODE (lastiddecl) == TYPE_DECL)
		    yyval.ttype = TREE_TYPE (lastiddecl);
		  else if (last_id_value == STRING_SCHEMA)
		    yyval.ttype = string_schema_proto_type;
		  else /* a forward declared pointer to an unknown type */
		    yyval.ttype = yyvsp[0].ttype; /* return an IDENTIFIER_NODE */
		;
    break;}
case 247:
#line 1272 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{
		  yyval.ttype = build_function_type (void_type_node, yyvsp[0].ttype);
		;
    break;}
case 248:
#line 1276 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{
		  yyval.ttype = build_function_type (yyvsp[0].ttype, yyvsp[-2].ttype);
		;
    break;}
case 249:
#line 1283 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = build_tree_list (NULL_TREE, void_type_node); ;
    break;}
case 250:
#line 1285 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = NULL_TREE; ;
    break;}
case 251:
#line 1287 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = yyvsp[-3].ttype; ;
    break;}
case 252:
#line 1289 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = chainon (yyvsp[-1].ttype,
				build_tree_list (NULL_TREE, void_type_node)); ;
    break;}
case 253:
#line 1295 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = build_tree_list (NULL_TREE, yyvsp[0].ttype); ;
    break;}
case 254:
#line 1297 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = chainon (yyvsp[-2].ttype, build_tree_list (NULL_TREE, yyvsp[0].ttype)); ;
    break;}
case 255:
#line 1299 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ 
		  error ("Invalid argument type list in function pointer");
		  yyval.ttype = NULL_TREE;
		;
    break;}
case 258:
#line 1314 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = grok_packed (yyvsp[0].ttype); ;
    break;}
case 264:
#line 1329 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ if (pedantic)
		    warning ("ISO Pascal does not have `string' type");
		  if (TREE_CODE (TREE_TYPE (yyvsp[0].ttype)) != INTEGER_TYPE)
		    error ("String schema discriminant must be of integer type");
		  yyval.ttype = build_pascal_string_schema (yyvsp[0].ttype);
		;
    break;}
case 265:
#line 1339 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = yyvsp[-1].ttype; ;
    break;}
case 266:
#line 1341 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ if (pedantic)
		    warning ("Pascal wants string capacity in parenthesis");
		    yyval.ttype = yyvsp[-1].ttype;
		;
    break;}
case 267:
#line 1351 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = build_pascal_array_type (TREE_VALUE (yyvsp[0].ttype), yyvsp[-3].ttype); ;
    break;}
case 268:
#line 1356 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = yyvsp[0].ttype; ;
    break;}
case 269:
#line 1358 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = chainon (yyvsp[-2].ttype, yyvsp[0].ttype); 
		  yyerrok; ;
    break;}
case 270:
#line 1361 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ error ("non-expression in array_index_list"); ;
    break;}
case 271:
#line 1363 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ error ("missing comma");
                  yyval.ttype = chainon(yyvsp[-2].ttype, yyvsp[0].ttype);
                  yyerrok; ;
    break;}
case 272:
#line 1367 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ error ("extra comma");
                  yyval.ttype = yyvsp[-2].ttype; ;
    break;}
case 273:
#line 1370 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ /* error ("improperly terminated array_index_list"); */
                  yyval.ttype = yyvsp[-1].ttype; ;
    break;}
case 274:
#line 1383 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = build_tree_list (yyvsp[0].ttype, convert_type_to_range (yyvsp[0].ttype)); ;
    break;}
case 275:
#line 1385 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = build_tree_list (yyvsp[0].ttype, convert_type_to_range (yyvsp[0].ttype)); ;
    break;}
case 276:
#line 1391 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = build_file_type (TREE_VALUE (yyvsp[0].ttype), yyvsp[-2].ttype); ;
    break;}
case 277:
#line 1396 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = NULL_TREE; ;
    break;}
case 278:
#line 1398 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = yyvsp[-1].ttype; ;
    break;}
case 279:
#line 1405 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ tree range = TREE_VALUE (yyvsp[0].ttype);
		  /* Avoid huge sets, like 'set of -maxint..maxint' */
		  TREE_VALUE (yyvsp[0].ttype) = check_set_bounds (TREE_PURPOSE (yyvsp[0].ttype),
						      TREE_VALUE (yyvsp[0].ttype));
		  yyval.ttype = build_set_type (yyvsp[0].ttype);
		;
    break;}
case 280:
#line 1412 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = build_set_type
		        (build_tree_list
			    (void_type_node,
			     build_index_2_type (size_zero_node,
						 build_int_2 (-1, 0))));
		;
    break;}
case 281:
#line 1423 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = yyvsp[-1].ttype; 
		  yyerrok; ;
    break;}
case 282:
#line 1426 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = finish_struct (start_struct (RECORD_TYPE, NULL_TREE),
				      NULL_TREE);
		;
    break;}
case 283:
#line 1434 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = finish_struct (start_struct (RECORD_TYPE, NULL_TREE),
				      NULL_TREE);
		;
    break;}
case 284:
#line 1438 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = finish_struct (start_struct (RECORD_TYPE, NULL_TREE),
				      yyvsp[-1].ttype); 
		;
    break;}
case 285:
#line 1442 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ 
		  /* Chain the tag field or NULL_TREE */
		  tree fields = chainon (yyvsp[-2].ttype, TREE_VALUE (TREE_PURPOSE (yyvsp[0].ttype)));
		  /* Chain the variant part */
		  fields = chainon (yyvsp[-2].ttype, TREE_VALUE (yyvsp[0].ttype));
		  yyval.ttype = finish_struct (start_struct (RECORD_TYPE, NULL_TREE),
				      fields);
		  store_variant_tag_info (yyval.ttype, yyvsp[0].ttype);
		;
    break;}
case 286:
#line 1452 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ 
		  /* Store the tag field or NULL_TREE */
		  tree fields = TREE_VALUE (TREE_PURPOSE (yyvsp[0].ttype));
		  /* Chain the variant part */
		  fields = chainon (fields, TREE_VALUE (yyvsp[0].ttype));
		  yyval.ttype = finish_struct (start_struct (RECORD_TYPE, NULL_TREE),
				      fields);
		  store_variant_tag_info (yyval.ttype, yyvsp[0].ttype);
		;
    break;}
case 288:
#line 1468 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = chainon (yyvsp[-2].ttype, yyvsp[0].ttype); 
		  yyerrok; ;
    break;}
case 289:
#line 1471 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ error ("missing semicolon");
                  yyval.ttype = chainon (yyvsp[-2].ttype, yyvsp[0].ttype); 
                  yyerrok; ;
    break;}
case 290:
#line 1475 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ error ("extra semicolon");
                  yyval.ttype = yyvsp[-2].ttype; ;
    break;}
case 291:
#line 1478 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ /* error ("improperly terminated record fixed part"); */
                  yyval.ttype = yyvsp[-1].ttype; ;
    break;}
case 292:
#line 1486 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = p_grokfields (yyvsp[-2].ttype, TREE_VALUE (yyvsp[0].ttype));
		  resume_momentary (yyvsp[-3].itype); ;
    break;}
case 293:
#line 1498 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ tree vlist = yyvsp[-1].ttype;
		  if (yyvsp[0].ttype)
		    vlist = chainon (vlist, yyvsp[0].ttype);
		  yyval.ttype = build_tree_list (yyvsp[-3].ttype,
			  build_record_variant_part (input_filename, lineno,
						     yyvsp[-3].ttype, vlist)); ;
    break;}
case 294:
#line 1508 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = NULL_TREE; ;
    break;}
case 295:
#line 1510 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = build_tree_list (NULL_TREE,
					grokfield (input_filename, lineno,
						   NULL_TREE,   /* field name */
						   build_tree_list (NULL_TREE, yyvsp[-2].ttype),
						   NULL_TREE)); /* field width */
		;
    break;}
case 296:
#line 1527 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = build_tree_list (yyvsp[0].ttype,
			  grokfield (input_filename,
				     lineno,
				     yyvsp[-2].ttype,
				     build_tree_list (NULL_TREE, yyvsp[0].ttype),
				     NULL_TREE));
		  yyerrok;
		;
    break;}
case 297:
#line 1536 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ error ("missing semicolon");
                  yyval.ttype = build_tree_list (yyvsp[0].ttype,
			  grokfield (input_filename,
				     lineno,
				     yyvsp[-2].ttype,
				     build_tree_list (NULL_TREE, yyvsp[0].ttype),
				     NULL_TREE));
		  yyerrok;
		;
    break;}
case 298:
#line 1547 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = build_tree_list (yyvsp[0].ttype, NULL_TREE); ;
    break;}
case 300:
#line 1558 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = chainon (yyvsp[-2].ttype, yyvsp[0].ttype);
		  yyerrok; ;
    break;}
case 301:
#line 1561 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ error ("missing semicolon");
                  yyval.ttype = chainon (yyvsp[-2].ttype, yyvsp[0].ttype); 
                  yyerrok; ;
    break;}
case 302:
#line 1565 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = NULL_TREE; ;
    break;}
case 303:
#line 1567 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ /* error ("improperly terminated record variant list"); */
                  yyval.ttype = yyvsp[-1].ttype;
                ;
    break;}
case 304:
#line 1574 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = build_tree_list (yyvsp[-4].ttype,
			 grokfield (input_filename, lineno,
				    NULL_TREE,   /* field name */
				    build_tree_list (NULL_TREE, yyvsp[-1].ttype),
				    NULL_TREE)); /* field width */
		;
    break;}
case 306:
#line 1585 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = chainon (yyvsp[-2].ttype, yyvsp[0].ttype);
		  yyerrok; ;
    break;}
case 307:
#line 1588 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ error ("extra comma");
                  yyval.ttype = yyvsp[-2].ttype; ;
    break;}
case 308:
#line 1591 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ error ("missing comma");
		  yyval.ttype = chainon (yyvsp[-2].ttype, yyvsp[0].ttype); 
                  yyerrok; ;
    break;}
case 309:
#line 1595 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ /* error ("improperly terminated case constant list"); */
                  yyval.ttype = yyvsp[-1].ttype; ;
    break;}
case 310:
#line 1601 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = build_tree_list (NULL_TREE, yyvsp[0].ttype); ;
    break;}
case 311:
#line 1603 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = build_tree_list (yyvsp[0].ttype, yyvsp[-2].ttype); ;
    break;}
case 312:
#line 1608 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ error("missing \"..\"");
                  yyval.ttype = build_tree_list (yyvsp[0].ttype, yyvsp[-2].ttype); 
                  yyerrok; ;
    break;}
case 313:
#line 1612 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ error("extra \"..\"");
                  yyval.ttype = build_tree_list (NULL_TREE, yyvsp[-2].ttype); ;
    break;}
case 314:
#line 1619 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = TREE_TYPE (yyvsp[0].ttype);
		  if (pedantic)
		    warning ("ISO Pascal forbids `TYPE OF'");
		;
    break;}
case 316:
#line 1631 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ error ("missing variable declaration"); ;
    break;}
case 318:
#line 1637 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyerrok; ;
    break;}
case 320:
#line 1640 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ error("missing semicolon"); 
                  yyerrok; ;
    break;}
case 322:
#line 1647 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ tree init = yyvsp[0].ttype;
		  /* If variable initialization not given, try type initialization */
		  if (! init)
		    init = TREE_PURPOSE (yyvsp[-1].ttype);
		  declare_vars (yyvsp[-4].ttype, TREE_VALUE (yyvsp[-1].ttype), init, yyvsp[-2].ttype);
		;
    break;}
case 323:
#line 1657 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = NULL_TREE; ;
    break;}
case 325:
#line 1663 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = build_tree_list (NULL_TREE, extern_id); ;
    break;}
case 326:
#line 1665 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = build_tree_list (NULL_TREE, static_id); ;
    break;}
case 327:
#line 1667 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = build_tree_list (NULL_TREE, volatile_id); ;
    break;}
case 329:
#line 1673 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = chainon (yyvsp[-1].ttype, yyvsp[0].ttype); ;
    break;}
case 330:
#line 1679 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = NULL_TREE; ;
    break;}
case 331:
#line 1681 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ if (pedantic)
		    warning ("ISO Pascal does allow type or variable initialization with VALUE");
		  yyval.ttype = yyvsp[0].ttype;
		;
    break;}
case 332:
#line 1693 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{
		  if (is_known_directive (yyvsp[-1].ttype))
		    grok_directive (TREE_VALUE (yyvsp[-3].ttype), TREE_PURPOSE (yyvsp[-3].ttype), yyvsp[-1].ttype,
				    ! global_bindings_p());
		  else
		    error ("A declaration part or a directive expected `%s' given",
			   IDENTIFIER_POINTER (yyvsp[-1].ttype));
	      	;
    break;}
case 333:
#line 1702 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{
		  tree qual    = TREE_VALUE (yyvsp[-1].ttype);
		  tree heading = TREE_PURPOSE (yyvsp[-1].ttype);

		  associate_external_objects (current_module_parms);

		  /* set flag if we are defining a nested function */
		  yyvsp[0].itype = ! global_bindings_p ();

		  if (yyvsp[0].itype)
		    push_c_function_context ();

		  if (current_module_name
		      && ! this_is_an_interface_module /* @@@ Can't be. */
		      && TREE_CODE (TREE_OPERAND (heading, 0)) == IDENTIFIER_NODE
		      && ! name_exported_by_current_module_p (TREE_OPERAND (heading, 0)))
		    qual = maybe_make_static (qual);

		  if (! (yyval.ttype =  start_pascal_function (qual,
							     heading,
							     yyvsp[0].itype)))
		    {
		      if (yyvsp[0].itype)
			pop_c_function_context ();
		      YYERROR1;
		    }
		  reinit_parse_for_function ();
		  store_parm_decls ();
		;
    break;}
case 334:
#line 1732 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{
		  /* Declare the function RESULT_DECL */
		  tree rtype = yyvsp[-1].ttype;

		  /* -O optimized result assignments away,
		   *  so I made it volatile
		   */
		  if (rtype != void_type_node)
		    finish_decl (
		       start_decl
			    (TREE_CHAIN (yyvsp[-3].ttype),
			     chainon (build_tree_list (NULL_TREE, volatile_id),
				      build_tree_list (NULL_TREE, rtype)),
			     0),
		       NULL_TREE,
		       NULL_TREE);
		  push_label_level ();
		;
    break;}
case 335:
#line 1751 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{
	          un_initialize_block (getdecls (), 0);
		;
    break;}
case 336:
#line 1755 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ tree result = DECL_RESULT (current_function_decl);
		  un_initialize_block (getdecls (), 1);

		  pop_label_level ();
		  if (TREE_TYPE (result) != void_type_node)
		    {
		      tree d;
		      /* I do it like this, since if the code
			 directly assigns to DECL_RESULT it will lose
			 on recursive functions.
			     
			 TREE_CHAIN($1) contains the unique name for
			 the return value parameter of this function.
		       */
		      if (! TREE_CHAIN (yyvsp[-8].ttype)
			  || !(d = lookup_name (TREE_CHAIN (yyvsp[-8].ttype))))
			abort ();

		      if (   ! PASCAL_VALUE_ASSIGNED (result)
			  && ! PASCAL_VALUE_ASSIGNED (d))
			warning ("return value of function not assigned");

		      expand_expr_stmt
			(build_modify_expr (result, NOP_EXPR, d));
		    }
	        ;
    break;}
case 337:
#line 1782 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{
		  finish_function (yyvsp[-9].itype);
		  if (yyvsp[-9].itype)
		    pop_c_function_context ();
		;
    break;}
case 338:
#line 1793 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{
		  yyval.ttype = tree_cons (build_nt (CALL_EXPR, yyvsp[-1].ttype, yyvsp[0].ttype, NULL_TREE),
				  tree_cons (NULL_TREE, void_type_node, yyvsp[-3].ttype),
				  NULL_TREE);
		;
    break;}
case 339:
#line 1803 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ tree retval = yyvsp[-1].ttype;

		  /* If user did not specify a name, we create one. */
		  if (retval == NULL_TREE)
		    retval =
		      get_identifier
			(concat ("retval_", IDENTIFIER_POINTER (yyvsp[-3].ttype), ""));

		  yyval.ttype = tree_cons (build_nt (CALL_EXPR, yyvsp[-3].ttype, yyvsp[-2].ttype, NULL_TREE),
				  tree_cons (NULL_TREE, yyvsp[0].ttype, yyvsp[-5].ttype),
				  retval);
		;
    break;}
case 340:
#line 1819 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = NULL_TREE; ;
    break;}
case 341:
#line 1821 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = build_tree_list (NULL_TREE, inline_id); ;
    break;}
case 349:
#line 1839 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = NULL_TREE ;
    break;}
case 350:
#line 1841 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ if (pedantic)
		    warning ("ISO Pascal does not allow function result variable specification");
		  yyval.ttype = yyvsp[0].ttype; ;
    break;}
case 351:
#line 1849 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = void_type_node; ;
    break;}
case 352:
#line 1851 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = yyvsp[0].ttype; /* if with a initial value: Should it init the function? */;
    break;}
case 353:
#line 1853 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = void_type_node; ;
    break;}
case 354:
#line 1860 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ pushlevel (0);
		  clear_parm_order ();
	          declare_parm_level (1); ;
    break;}
case 355:
#line 1864 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = yyvsp[0].ttype;
		  parmlist_tags_warning ();
		  poplevel (0, 0, 0); ;
    break;}
case 356:
#line 1870 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = get_parm_info (1); ;
    break;}
case 357:
#line 1872 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = get_parm_info (1); ;
    break;}
case 358:
#line 1874 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ if (pedantic)
		    warning ("ISO Pascal denies variable number of arguments");
		  yyval.ttype = get_parm_info (0); ;
    break;}
case 359:
#line 1878 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ if (pedantic)
		    warning ("ISO Pascal denies variable number of arguments");
		  yyval.ttype = get_parm_info (0); ;
    break;}
case 360:
#line 1882 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = tree_cons (NULL_TREE, NULL_TREE, NULL_TREE); ;
    break;}
case 362:
#line 1888 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyerrok; ;
    break;}
case 363:
#line 1892 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ error("missing semicolon");
                 yyerrok; ;
    break;}
case 365:
#line 1899 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ handle_formal_param_list (yyvsp[-2].ttype, yyvsp[0].ttype, 0, yyvsp[-3].itype); ;
    break;}
case 366:
#line 1901 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ handle_formal_param_list (yyvsp[-2].ttype, yyvsp[0].ttype, 1, yyvsp[-4].itype); ;
    break;}
case 367:
#line 1903 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ handle_formal_param_list (TREE_PURPOSE (yyvsp[0].ttype), TREE_VALUE (yyvsp[0].ttype), 0, 0); ;
    break;}
case 368:
#line 1905 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ handle_formal_conf_array_param_list (yyvsp[-2].ttype, yyvsp[0].ttype, 0, yyvsp[-3].itype); ;
    break;}
case 369:
#line 1907 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ handle_formal_conf_array_param_list (yyvsp[-2].ttype, yyvsp[0].ttype, 1, yyvsp[-4].itype); ;
    break;}
case 370:
#line 1912 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.itype = 0; ;
    break;}
case 371:
#line 1914 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.itype = 1; ;
    break;}
case 374:
#line 1925 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = string_schema_proto_type; ;
    break;}
case 377:
#line 1937 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = build_tree_list (error_mark_node,
					build_tree_list (yyvsp[-3].ttype, TREE_VALUE (yyvsp[0].ttype)));
		;
    break;}
case 378:
#line 1946 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = build_tree_list (NULL_TREE,
					build_tree_list (yyvsp[-3].ttype, TREE_VALUE (yyvsp[0].ttype)));
		;
    break;}
case 379:
#line 1953 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = build_tree_list (build_tree_list (yyvsp[-4].ttype, yyvsp[-2].ttype), yyvsp[0].ttype); ;
    break;}
case 381:
#line 1959 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = chainon (yyvsp[-2].ttype, yyvsp[0].ttype);
		  yyerrok; ;
    break;}
case 382:
#line 1964 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ error ("missing semicolon");
                yyerrok; ;
    break;}
case 384:
#line 1974 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ stmt_count++; ;
    break;}
case 385:
#line 1979 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyerrok; ;
    break;}
case 387:
#line 1985 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyerrok; ;
    break;}
case 388:
#line 1987 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ error ("missing semicolon"); ;
    break;}
case 389:
#line 1989 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ error ("extra semicolon"); /* @@ Perhaps too innovative :-) */
                yyerrok; ;
    break;}
case 390:
#line 1994 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.filename = input_filename; ;
    break;}
case 391:
#line 1998 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.lineno = lineno; ;
    break;}
case 392:
#line 2003 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ ;
    break;}
case 393:
#line 2008 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ tree label =
		   define_label (input_filename, lineno, yyvsp[-1].ttype);
		  stmt_count++;
		  emit_nop ();
		  if (label)
		    expand_label (label);
		  position_after_white_space (); ;
    break;}
case 398:
#line 2024 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ tree init = yyvsp[0].ttype;
		  if (! init)
		    init = TREE_PURPOSE (yyvsp[-1].ttype); /* Try type initialization */

		  if (pedantic)
		    warning ("ISO Pascal does not allow variable declarations in statement part\n");
		  declare_vars (yyvsp[-4].ttype, TREE_VALUE (yyvsp[-1].ttype), init, yyvsp[-2].ttype);
		;
    break;}
case 405:
#line 2050 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ int i;
		  for (i = yyvsp[-2].itype; i ;i--)
		     poplevel (0, 0, 0);
		;
    break;}
case 407:
#line 2059 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.itype += yyvsp[0].itype;
		  yyerrok; ;
    break;}
case 408:
#line 2062 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.itype = 0; ;
    break;}
case 409:
#line 2064 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ error ("missing comma");
                  yyval.itype += yyvsp[0].itype; 
                  yyerrok; ;
    break;}
case 410:
#line 2068 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ error ("extra comma"); ;
    break;}
case 411:
#line 2073 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ if (TREE_CODE (TREE_TYPE (yyvsp[0].ttype)) != RECORD_TYPE)
		    {
		      error ("WITH element must be of record type");
		      yyval.itype = 0;
		    }
		  else
		    {
	    	      shadow_record_fields (yyvsp[0].ttype);
		      yyval.itype = 1;
		    }
		;
    break;}
case 414:
#line 2096 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ emit_line_note (yyvsp[-4].filename, yyvsp[-3].lineno);
		  stmt_count++;
		  expand_start_cond (yyvsp[-1].ttype, 0);
		  yyvsp[-2].itype = stmt_count;
		  if_stmt_file = yyvsp[-4].filename;
		  if_stmt_line = yyvsp[-3].lineno;
		  position_after_white_space ();
		;
    break;}
case 417:
#line 2110 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ error ("missing THEN"); ;
    break;}
case 418:
#line 2115 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ expand_start_else ();
		  yyvsp[-1].itype = stmt_count;
		  position_after_white_space (); ;
    break;}
case 419:
#line 2119 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ expand_end_cond ();
		  if (extra_warnings && stmt_count == yyvsp[-3].itype)
		    warning("empty body in an else statement");
		;
    break;}
case 420:
#line 2124 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ expand_end_cond ();
		  if (extra_warnings && stmt_count == yyvsp[0].itype)
		    warning_with_file_and_line (if_stmt_file, if_stmt_line,
						"empty body in an if statement");
		;
    break;}
case 421:
#line 2134 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ stmt_count++;
		  emit_line_note (yyvsp[-4].filename, yyvsp[-3].lineno);
		  c_expand_start_case (yyvsp[-1].ttype);
		  /* Don't let the tree nodes for $2 be discarded by
		     clear_momentary during the parsing of the next stmt.  */
		position_after_white_space (); ;
    break;}
case 422:
#line 2141 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ expand_end_case (yyvsp[-5].ttype);
		  yyerrok; ;
    break;}
case 424:
#line 2148 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ error ("missing OF"); ;
    break;}
case 426:
#line 2154 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyerrok; ;
    break;}
case 427:
#line 2156 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ error("case_element expected"); ;
    break;}
case 428:
#line 2159 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ error("missing semicolon");
                yyerrok; ;
    break;}
case 429:
#line 2163 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ error("extra semicolon"); ;
    break;}
case 430:
#line 2169 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ register tree link;
		  register tree value1, value2;
		  register tree label;
		  tree duplicate;

		  for (link = yyvsp[-1].ttype; link; link = TREE_CHAIN (link)) {
		    value1 = TREE_VALUE (link);
		    value2 = TREE_PURPOSE (link);
		    label = build_decl (LABEL_DECL, NULL_TREE, NULL_TREE);

		    /* @@@ use check_case_value ()??? */
		    if (TREE_CODE (value1) != INTEGER_CST
			&& value1 != error_mark_node) {
		      error ("case label does not reduce to an integer constant");
		      continue;
		    }
		    if (value2
			&& TREE_CODE (value2) != INTEGER_CST
			&& value2 != error_mark_node) {
		      error ("upper value of case range does not reduce to an integer constant");
		      continue;
		    }
		    if (value1 != error_mark_node && value2 != error_mark_node) {
		      int success;
		      if (value2) {
			  if (pedantic)
			      warning ("ISO Pascal does not allow case ranges");
			  success = pushcase_range (value1, value2, convert_and_check, label,
						    &duplicate);
		      } else
			  success = pushcase (value1, convert_and_check, label, &duplicate);
		      if (success == 1)
			error ("case label not within case statement");
		      else if (success == 2)
			{
			  error ("duplicate case label value in case statement");
			  error_with_decl (duplicate, "this is the first entry for that value");
			}
		      else if (success == 3)
			warning ("case label out of range");
		      else if (success == 4)
			warning ("empty case label range");
		    }
		  }
		  position_after_white_space ();
		;
    break;}
case 431:
#line 2216 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ expand_exit_something (); ;
    break;}
case 432:
#line 2218 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{
		  tree duplicate;
		  register tree label
		    = build_decl (LABEL_DECL, NULL_TREE, NULL_TREE);
		  int success = pushcase (NULL_TREE, 0, label, &duplicate);
		  stmt_count++;
		  if (pedantic)
		    warning ("ISO Pascal does not allow default label `%s' in CASE statement",
			     IDENTIFIER_POINTER (yyvsp[-1].ttype));
		  if (success == 1)
		    error ("default label not within a case statement");
		  else if (success == 2)
		    {
		      error ("multiple default labels in one case statement");
		      error_with_decl (duplicate, "this is the first entry for that value");
		    }
		  position_after_white_space ();
		;
    break;}
case 433:
#line 2237 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ expand_exit_something (); ;
    break;}
case 440:
#line 2258 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ emit_nop ();
		  stmt_count++;
		  emit_line_note (yyvsp[-2].filename, yyvsp[-1].lineno);
		  expand_start_loop_continue_elsewhere (1); ;
    break;}
case 441:
#line 2263 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ expand_loop_continue_here (); ;
    break;}
case 442:
#line 2265 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ emit_line_note (input_filename, lineno);
		  expand_exit_loop_if_false (0,
			build_pascal_unary_op (TRUTH_NOT_EXPR, yyvsp[0].ttype, 0));
		  expand_end_loop ();
		  /* clear_momentary (); */ ;
    break;}
case 443:
#line 2275 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ emit_nop ();
		  stmt_count++;
		  emit_line_note (yyvsp[-2].filename, yyvsp[-1].lineno);
		  expand_start_loop (1); ;
    break;}
case 444:
#line 2280 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ emit_line_note (input_filename, lineno);
		  expand_exit_loop_if_false (0, yyvsp[0].ttype); ;
    break;}
case 445:
#line 2283 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ expand_end_loop (); ;
    break;}
case 447:
#line 2289 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ error ("missing DO"); ;
    break;}
case 448:
#line 2310 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ tree for_l_bound, for_u_bound;
		  int mark_low = 0;
		  int mark_high = 0;
		  emit_nop ();
		  stmt_count++;
		  emit_line_note (yyvsp[-7].filename, yyvsp[-6].lineno);
		  if (TREE_CONSTANT (yyvsp[-2].ttype))
		    for_l_bound = yyvsp[-2].ttype;
		  else
		    {
		      mark_low++;
		      for_l_bound = start_decl
			(get_unique_identifier ("for_lower", 0),
			 build_tree_list
			   (NULL_TREE,
#if 0
			    type_for_size (TYPE_PRECISION (TREE_TYPE (yyvsp[-4].ttype)),
					   TREE_UNSIGNED (TREE_TYPE (yyvsp[-4].ttype)))),
#else
			    TREE_TYPE (yyvsp[-4].ttype)),
#endif
			 0);
		      finish_decl (for_l_bound, NULL_TREE, NULL_TREE);
		      PASCAL_LOOP_CHECK (for_l_bound) = 1;

		      /* Assign the lower bound to temp */
		      /* @@@ c_expand_expr_stmt() ??? */
		      expand_expr_stmt (build_modify_expr (for_l_bound,
							   NOP_EXPR, yyvsp[-2].ttype));
		    }

		  if (TREE_CONSTANT (yyvsp[0].ttype))
		    for_u_bound = yyvsp[0].ttype;
		  else
		    {
		      mark_high++;
		      for_u_bound = start_decl
			(get_unique_identifier ("for_upper", 0),
			 build_tree_list
			   (NULL_TREE,
#if 0
			    type_for_size (TYPE_PRECISION (TREE_TYPE (yyvsp[-4].ttype)),
					   TREE_UNSIGNED (TREE_TYPE (yyvsp[-4].ttype)))),
#else
			    TREE_TYPE (yyvsp[-4].ttype)),
#endif
			 0);
		      finish_decl (for_u_bound, NULL_TREE, NULL_TREE);
		      PASCAL_LOOP_CHECK (for_u_bound) = 1;

		      emit_line_note (yyvsp[-7].filename, yyvsp[-6].lineno);
		      /* and the upper one */
		      expand_expr_stmt (build_modify_expr (for_u_bound,
							   NOP_EXPR, yyvsp[0].ttype));
		    }
		  yyval.ttype = for_u_bound;

		  /* necessary to prevent infinite loops when
 		   * incrementing/decrementing would cause
		   * wrap-around at maxint/-maxint
		   */
		  expand_start_cond (build_pascal_op (yyvsp[-1].code, for_l_bound,
						      for_u_bound), 0);
		  if (mark_low)
		    PASCAL_LOOP_CHECK (for_l_bound) = 0;
		  if (mark_high)
		    PASCAL_LOOP_CHECK (for_u_bound) = 0;

		  emit_line_note (yyvsp[-7].filename, yyvsp[-6].lineno);
		  expand_expr_stmt (build_modify_expr (yyvsp[-4].ttype, NOP_EXPR, for_l_bound));
		  expand_start_loop_continue_elsewhere (1);
		;
    break;}
case 449:
#line 2383 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ position_after_white_space ();
		;
    break;}
case 450:
#line 2386 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ emit_line_note (yyvsp[-11].filename, yyvsp[-10].lineno);
		  expand_loop_continue_here ();
		  expand_exit_loop_if_false (0,
		     fold (build_pascal_op
			   (yyvsp[-5].code == LE_EXPR ? LT_EXPR : GT_EXPR,
			    yyvsp[-8].ttype, yyvsp[-3].ttype)));
		  expand_expr_stmt (build_pascal_unary_op (
		     (yyvsp[-5].code == GE_EXPR ? POSTDECREMENT_EXPR : POSTINCREMENT_EXPR),
		     yyvsp[-8].ttype, 0));
		  expand_end_loop ();
		  expand_end_cond ();
		;
    break;}
case 451:
#line 2399 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ 
		  error ("Extended Pascal set member iteration not implemented yet");
		;
    break;}
case 452:
#line 2403 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ position_after_white_space (); ;
    break;}
case 453:
#line 2405 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ ;
    break;}
case 454:
#line 2410 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.code = LE_EXPR; ;
    break;}
case 455:
#line 2412 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.code = GE_EXPR; ;
    break;}
case 456:
#line 2414 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ error("missing TO or DOWNTO"); ;
    break;}
case 458:
#line 2421 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ stmt_count++; ;
    break;}
case 459:
#line 2423 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ stmt_count++; ;
    break;}
case 460:
#line 2425 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ stmt_count++; ;
    break;}
case 461:
#line 2427 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ stmt_count++; ;
    break;}
case 463:
#line 2436 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ tree decl;
		  emit_line_note (yyvsp[-3].filename, yyvsp[-2].lineno);
		  decl = lookup_label (yyvsp[0].ttype);
		  if (decl != 0) {
		      TREE_USED (decl) = 1;
		      expand_goto (decl); }
	        ;
    break;}
case 464:
#line 2444 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ emit_line_note (yyvsp[-4].filename, yyvsp[-3].lineno);
		  if (pedantic)
		    warning ("ISO Pascal does not allow indirect jumps");
		  expand_computed_goto (convert (ptr_type_node, yyvsp[0].ttype)); ;
    break;}
case 465:
#line 2464 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = NULL_TREE; ;
    break;}
case 466:
#line 2466 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyvsp[0].itype = suspend_function_calls (); ;
    break;}
case 467:
#line 2468 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{
		  yyval.ttype = yyvsp[-1].ttype;
		  resume_function_calls (yyvsp[-3].itype);
		  yyerrok;
	        ;
    break;}
case 469:
#line 2478 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ error ("missing ')'"); ;
    break;}
case 470:
#line 2483 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = build_tree_list (NULL_TREE, yyvsp[0].ttype); ;
    break;}
case 471:
#line 2485 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = chainon (yyvsp[-2].ttype, build_tree_list (NULL_TREE, yyvsp[0].ttype));
		  yyerrok; ;
    break;}
case 472:
#line 2488 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = NULL_TREE; /* @@ verify this */ ;
    break;}
case 473:
#line 2490 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ error ("extra comma"); ;
    break;}
case 475:
#line 2506 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ tree target = yyvsp[-1].ttype;
		  tree source = yyvsp[0].ttype; /* In assignment != NULL_TREE */

		  if (! source)
		    {
		      if (TREE_CODE (target) == FUNCTION_DECL
			  || (TREE_CODE (target) == PARM_DECL
			      && TREE_CODE (TREE_TYPE (target)) == POINTER_TYPE
			      && TREE_CODE (TREE_TYPE (TREE_TYPE (target))) ==
			         FUNCTION_TYPE))
			target = maybe_call_function (target, NULL_TREE);

		      if (target != error_mark_node)
			{
			  if (TREE_CODE (target) != CALL_EXPR)
			    warning ("Expression used as a statement -- value is ignored");
			  else if (TREE_TYPE (target) != void_type_node)
			    warning ("Function call as a statement -- value is ignored");
			  
			  expand_expr_stmt (target);
			}
		    }
		  else
		    {
		      int allow_restricted_target = FALSE;
		      int allow_restricted_source = FALSE;

		      if (TREE_CODE (target) == FUNCTION_DECL)
			{
			  if (TREE_TYPE (TREE_TYPE (target)) == void_type_node)
			    {
			      error ("You can't assign to a procedure");
			      target = error_mark_node;
			    }
			  else
			    {
			      if (yyvsp[-1].ttype == current_function_decl)
				current_function_returns_value = 1;
			      else if (! maybe_find_function_data (target))
				{
				  error ("Function `%s' value assigned outside it's block",
					 IDENTIFIER_POINTER (DECL_NAME (target)));
				  target = error_mark_node;
				}
			      if (target != error_mark_node)
				{
				  target =
				    lookup_name
				      (get_identifier
				       (concat
					("retval_",
					 IDENTIFIER_POINTER (DECL_NAME (target)),
					 "")));
				  if (! target)
				    abort ();

				  /* Allow assignment of a non-restricted type
				   * to a restricted function return value
				   */
				  allow_restricted_target = TRUE;
				}
			    }
			} 

		      /* @@@@ Maybe this needs further checking */
		      if (TREE_CODE (source) == CALL_EXPR
			  && PASCAL_TYPE_RESTRICTED (TREE_TYPE (source)))
			{
			  allow_restricted_source = TRUE;
			  allow_restricted_target = TRUE;

			  if (! PASCAL_TYPE_RESTRICTED (TREE_TYPE (target)))
			    error ("A restricted return value may only be assigned to a restricted type object");
			}

		      /* To mark that we have assigned to this variable.
			 Currently only used to flag function value assignments,
			 but it cannot be inside the FUNCTION_DECL conditional
			 above, since GPC allows you to define a name for the
			 return value of the function, and that name is not
			 (at least currently) recorded in the function
			 declaration. GPC assigns a VAR_DECL node for the name. */
		      if (TREE_CODE (target) == VAR_DECL)
			PASCAL_VALUE_ASSIGNED (target) = 1;

		      emit_line_note (input_filename, lineno);

		      if ((!allow_restricted_target
			   && PASCAL_TYPE_RESTRICTED (TREE_TYPE (target)))
			  || (!allow_restricted_source
			      && PASCAL_TYPE_RESTRICTED (TREE_TYPE (source))))
			error ("Assigning a restricted type object is not allowed");

		      /* @@ Test new constructor code without this */

		      /* Construct a set directly to the set variable */
		      if (TREE_CODE (TREE_TYPE (target)) == SET_TYPE &&
			  TREE_CODE (source) == CONSTRUCTOR)
			source = construct_set (source, target, 0);

		      if (source)
			{
			   /* handle char, vstring and fstring mixing */
			   if (is_string_type (target)
			       || is_string_type (source))
			     assign_string (target, source);
			   else
			     expand_expr_stmt
			       (build_modify_expr (target, NOP_EXPR, source));
			}
		    }
		;
    break;}
case 476:
#line 2622 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ 
		  if (TREE_CODE (TREE_TYPE (yyvsp[0].ttype)) == REFERENCE_TYPE)
		      yyval.ttype = build_indirect_ref (yyvsp[0].ttype, "VAR parameter ref"); 
		  else
		      yyval.ttype = yyvsp[0].ttype;
		;
    break;}
case 478:
#line 2633 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = NULL_TREE; ;
    break;}
case 479:
#line 2635 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = yyvsp[0].ttype; ;
    break;}
case 481:
#line 2641 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ warning ("Using '=' instead of ':=' in assignment");
		  yyval.code = yyvsp[0].code;
		;
    break;}
case 482:
#line 2648 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ if (pedantic && yyvsp[0].ttype != NULL_TREE)
		      warning ("Extended Pascal does not allow parameters to HALT");
		  build_rts_call (p_HALT, yyvsp[0].ttype); ;
    break;}
case 483:
#line 2652 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ if (pedantic && yyvsp[-1].ttype != NULL_TREE)
		    warning ("ISO Pascal does not allow file name parameter to reset/rewrite");
		  build_rts_call (yyvsp[-4].itype, 
				 tree_cons (NULL_TREE, yyvsp[-2].ttype,
				            build_tree_list (NULL_TREE, yyvsp[-1].ttype)));
		;
    break;}
case 484:
#line 2659 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ build_rts_call (yyvsp[-3].itype, build_tree_list(NULL_TREE, yyvsp[-1].ttype)); ;
    break;}
case 485:
#line 2661 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ build_rts_call (yyvsp[-3].itype, yyvsp[-1].ttype); ;
    break;}
case 486:
#line 2663 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ build_rts_call (p_WRITE, yyvsp[-1].ttype); ;
    break;}
case 487:
#line 2665 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ build_rts_call (p_WRITELN, yyvsp[0].ttype); ;
    break;}
case 488:
#line 2667 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ build_rts_call (p_READLN, yyvsp[0].ttype); ;
    break;}
case 489:
#line 2670 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ build_rts_call (p_WRITESTR, yyvsp[-1].ttype); ;
    break;}
case 490:
#line 2672 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ build_rts_call (p_READSTR, yyvsp[-1].ttype); ;
    break;}
case 491:
#line 2677 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.itype = p_REWRITE; ;
    break;}
case 492:
#line 2679 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.itype = p_RESET; ;
    break;}
case 493:
#line 2681 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.itype = p_EXTEND; ;
    break;}
case 494:
#line 2686 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = null_pointer_node; ;
    break;}
case 495:
#line 2688 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = yyvsp[0].ttype; ;
    break;}
case 496:
#line 2693 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = NULL_TREE; ;
    break;}
case 497:
#line 2695 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = yyvsp[-1].ttype;
		  yyerrok; ;
    break;}
case 499:
#line 2702 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = chainon (yyvsp[-2].ttype, yyvsp[0].ttype);
		  yyerrok; ;
    break;}
case 500:
#line 2705 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ error("missing write_actual_parameter");
                  yyval.ttype = NULL_TREE; ;
    break;}
case 501:
#line 2708 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ error ("missing comma");
                  yyval.ttype = chainon (yyvsp[-2].ttype, yyvsp[0].ttype); 
                  yyerrok; ;
    break;}
case 502:
#line 2712 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ error ("extra comma"); ;
    break;}
case 503:
#line 2720 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = build_tree_list (NULL_TREE, yyvsp[0].ttype); ;
    break;}
case 504:
#line 2722 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = build_tree_list (build_tree_list (NULL_TREE, yyvsp[0].ttype), yyvsp[-2].ttype); ;
    break;}
case 505:
#line 2724 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = build_tree_list (build_tree_list (yyvsp[0].ttype, yyvsp[-2].ttype), yyvsp[-4].ttype); ;
    break;}
case 506:
#line 2730 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.itype = p_PUT; ;
    break;}
case 507:
#line 2732 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.itype = p_GET; ;
    break;}
case 508:
#line 2734 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.itype = p_PAGE; ;
    break;}
case 509:
#line 2736 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.itype = p_MARK; ;
    break;}
case 510:
#line 2738 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.itype = p_RELEASE; ;
    break;}
case 511:
#line 2740 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.itype = p_CLOSE; ;
    break;}
case 512:
#line 2742 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.itype = p_UPDATE; ;
    break;}
case 513:
#line 2744 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.itype = p_GETTIMESTAMP; ;
    break;}
case 514:
#line 2746 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.itype = p_UNBIND; ;
    break;}
case 515:
#line 2751 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.itype = p_READ; ;
    break;}
case 516:
#line 2753 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.itype = p_NEW; ;
    break;}
case 517:
#line 2755 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.itype = p_DISPOSE; ;
    break;}
case 518:
#line 2757 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.itype = p_PACK; ;
    break;}
case 519:
#line 2759 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.itype = p_UNPACK; ;
    break;}
case 520:
#line 2761 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.itype = p_BIND; ;
    break;}
case 521:
#line 2763 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.itype = p_SEEKREAD; ;
    break;}
case 522:
#line 2765 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.itype = p_SEEKWRITE; ;
    break;}
case 523:
#line 2767 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.itype = p_SEEKUPDATE; ;
    break;}
case 524:
#line 2770 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.itype = p_DEFINESIZE; ;
    break;}
case 529:
#line 2783 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ emit_line_note (yyvsp[-2].filename, yyvsp[-1].lineno);
		  if (pedantic)
		    warning ("ISO Pascal does not allow return statement");
		  c_expand_return (NULL_TREE); ;
    break;}
case 530:
#line 2788 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ emit_line_note (yyvsp[-3].filename, yyvsp[-2].lineno);
		  if (pedantic)
		    warning ("ISO Pascal does not allow return statement");
		  current_function_returns_value = 1;
		  c_expand_return (yyvsp[0].ttype); ;
    break;}
case 531:
#line 2797 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ emit_line_note (yyvsp[-2].filename, yyvsp[-1].lineno);
		  if (pedantic)
		    warning ("ISO Pascal does not allow break statement");
		  if ( ! expand_exit_something ())
		    error ("break statement not within loop or case"); ;
    break;}
case 532:
#line 2806 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ emit_line_note (yyvsp[-2].filename, yyvsp[-1].lineno);
		  if (pedantic)
		    warning ("ISO Pascal does not allow continue statement");
		  if (! expand_continue_loop (0))	/* @@@ NP */
		    error ("continue statement not within a loop"); ;
    break;}
case 533:
#line 2815 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ emit_line_note (yyvsp[-6].filename, yyvsp[-5].lineno);
		  if (TREE_CHAIN (yyvsp[-1].ttype)) yyvsp[-1].ttype = combine_strings (yyvsp[-1].ttype);
		  expand_asm (yyvsp[-1].ttype); ;
    break;}
case 534:
#line 2820 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ emit_line_note (yyvsp[-8].filename, yyvsp[-7].lineno);
		  if (TREE_CHAIN (yyvsp[-3].ttype)) yyvsp[-3].ttype = combine_strings (yyvsp[-3].ttype);
		  c_expand_asm_operands (yyvsp[-3].ttype, yyvsp[-1].ttype, NULL_TREE, NULL_TREE,
					 0, input_filename, lineno); ;
    break;}
case 535:
#line 2826 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ emit_line_note (yyvsp[-10].filename, yyvsp[-9].lineno);
		  if (TREE_CHAIN (yyvsp[-5].ttype)) yyvsp[-5].ttype = combine_strings (yyvsp[-5].ttype);
		  c_expand_asm_operands (yyvsp[-5].ttype, yyvsp[-3].ttype, yyvsp[-1].ttype, NULL_TREE,
					 0, input_filename, lineno); ;
    break;}
case 536:
#line 2832 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ emit_line_note (yyvsp[-12].filename, yyvsp[-11].lineno);
		  if (TREE_CHAIN (yyvsp[-7].ttype)) yyvsp[-7].ttype = combine_strings (yyvsp[-7].ttype);
 		  c_expand_asm_operands (yyvsp[-7].ttype, yyvsp[-5].ttype, yyvsp[-3].ttype, yyvsp[-1].ttype,
					 0, input_filename, lineno); ;
    break;}
case 537:
#line 2841 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ if (pedantic)
		    warning ("ISO Pascal forbids use of `asm' keyword"); ;
    break;}
case 538:
#line 2849 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = NULL_TREE; ;
    break;}
case 541:
#line 2856 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = chainon (yyvsp[-2].ttype, yyvsp[0].ttype); ;
    break;}
case 542:
#line 2861 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = build_tree_list (yyvsp[-3].ttype, yyvsp[-1].ttype); ;
    break;}
case 543:
#line 2866 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = tree_cons (NULL_TREE, yyvsp[0].ttype, NULL_TREE); ;
    break;}
case 544:
#line 2868 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = tree_cons (NULL_TREE, yyvsp[0].ttype, yyvsp[-2].ttype); ;
    break;}
case 546:
#line 2876 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ if (lastiddecl != 0 && TREE_CODE (lastiddecl) == TYPE_DECL)
		    yyval.ttype = lastiddecl;
		  else {
		    tree id = check_identifier (lastiddecl, yyvsp[0].ttype);
		    if (TREE_CODE (TREE_TYPE (id)) == REFERENCE_TYPE)
		      yyval.ttype = build_indirect_ref (id, "VAR parameter ref"); 
		    else
		      yyval.ttype = id;
		  }
		;
    break;}
case 547:
#line 2890 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = build_tree_list (NULL_TREE, yyvsp[0].ttype); ;
    break;}
case 548:
#line 2892 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = chainon (yyvsp[-2].ttype, build_tree_list (NULL_TREE, yyvsp[0].ttype));
		  yyerrok; ;
    break;}
case 549:
#line 2895 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ error ("missing expression");
                  yyval.ttype = NULL_TREE; ;
    break;}
case 550:
#line 2898 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ error ("missing comma");
                  yyval.ttype = chainon (yyvsp[-2].ttype, build_tree_list (NULL_TREE, yyvsp[0].ttype)); 
                  yyerrok; ;
    break;}
case 551:
#line 2902 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ error ("extra comma"); ;
    break;}
case 553:
#line 2917 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = fold (yyvsp[0].ttype); ;
    break;}
case 554:
#line 2922 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = fold (yyvsp[0].ttype); ;
    break;}
case 555:
#line 2926 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = build_pascal_op (yyvsp[-1].code, yyvsp[-2].ttype, yyvsp[0].ttype); ;
    break;}
case 556:
#line 2928 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = build_pascal_op (IN_EXPR, yyvsp[-2].ttype, yyvsp[0].ttype); ;
    break;}
case 559:
#line 2935 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = build_pascal_op (yyvsp[-1].code, yyvsp[-2].ttype, yyvsp[0].ttype); ;
    break;}
case 560:
#line 2937 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ enum tree_code code =
			flag_short_circuit ? TRUTH_ORIF_EXPR : TRUTH_OR_EXPR;
		  yyval.ttype = build_pascal_op (code, yyvsp[-2].ttype, yyvsp[0].ttype); ;
    break;}
case 561:
#line 2941 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ if (pedantic)
		      warning ("ISO Pascal does not allow 'OR_ELSE'");
		  yyval.ttype = build_pascal_op (TRUTH_ORIF_EXPR, yyvsp[-2].ttype, yyvsp[0].ttype); ;
    break;}
case 562:
#line 2948 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = NULL_TREE; /* Any tree value is fine */ ;
    break;}
case 564:
#line 2954 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = NULL_TREE; /* Any tree value is fine */ ;
    break;}
case 566:
#line 2961 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = build_pascal_unary_op (yyvsp[-1].code, yyvsp[0].ttype, 0); ;
    break;}
case 569:
#line 2969 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = build_pascal_op (yyvsp[-1].code, yyvsp[-2].ttype, yyvsp[0].ttype); ;
    break;}
case 570:
#line 2971 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = build_pascal_op (BIT_XOR_EXPR, yyvsp[-2].ttype, yyvsp[0].ttype); ;
    break;}
case 571:
#line 2973 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ enum tree_code code =
			flag_short_circuit ? TRUTH_ANDIF_EXPR : TRUTH_AND_EXPR;
		  yyval.ttype = build_pascal_op (code, yyvsp[-2].ttype, yyvsp[0].ttype); ;
    break;}
case 572:
#line 2977 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ if (pedantic)
		    warning ("ISO Pascal does not allow 'AND_THEN'");
		  yyval.ttype = build_pascal_op (TRUTH_ANDIF_EXPR, yyvsp[-2].ttype, yyvsp[0].ttype); ;
    break;}
case 574:
#line 2989 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ if (TREE_CODE (TREE_TYPE (yyvsp[0].ttype)) != INTEGER_TYPE)
		    {
		      error ("`pow' exponent is not of integer type");
		      yyval.ttype = error_mark_node;
		    }
		  else
		    yyval.ttype = build_pascal_op (EXPON_EXPR, yyvsp[-2].ttype, yyvsp[0].ttype);
		;
    break;}
case 575:
#line 2998 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ if (TREE_CODE (TREE_TYPE (yyvsp[0].ttype)) != REAL_TYPE)
		    {
		      error ("`**' exponent is not of real type");
		      yyval.ttype = error_mark_node;
		    }
		  else
		    yyval.ttype = build_pascal_op (EXPON_EXPR, yyvsp[-2].ttype, yyvsp[0].ttype);
		;
    break;}
case 576:
#line 3007 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ error ("Object pascal operator `is' not supported");
		  yyval.ttype = error_mark_node;
		;
    break;}
case 577:
#line 3014 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ tree temp = yyvsp[0].ttype;
		  if (TREE_CODE (yyvsp[0].ttype) == TYPE_DECL)
		    {
			error ("type name given - variable_access expected");
			yyval.ttype = error_mark_node;
		    }
		  else if (TREE_CODE (yyvsp[0].ttype) == FUNCTION_DECL
			   || (TREE_CODE (yyvsp[0].ttype) == PARM_DECL
			       && TREE_CODE (TREE_TYPE (yyvsp[0].ttype)) == POINTER_TYPE
			       && TREE_CODE (TREE_TYPE (TREE_TYPE (yyvsp[0].ttype))) ==
			       	  FUNCTION_TYPE))
		     yyval.ttype = maybe_call_function (yyvsp[0].ttype, NULL_TREE);
		  else
		     yyval.ttype = yyvsp[0].ttype;
		;
    break;}
case 581:
#line 3033 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = yyvsp[-1].ttype; ;
    break;}
case 582:
#line 3036 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = build_pascal_unary_op (TRUTH_NOT_EXPR, yyvsp[0].ttype, 0); ;
    break;}
case 584:
#line 3039 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ if (pedantic)
		    warning ("ISO Pascal does not allow to take addresses of objects");
		  /* Let default_conversion() take care of function pointers */
		  if (TREE_CODE (TREE_TYPE (yyvsp[0].ttype)) == FUNCTION_TYPE)
		    yyval.ttype = yyvsp[0].ttype;
		  else
		    yyval.ttype = build_pascal_unary_op (ADDR_EXPR, yyvsp[0].ttype, 0); ;
    break;}
case 585:
#line 3051 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ tree label = lookup_label (yyvsp[0].ttype);
		  TREE_USED (label) = 1;
		  yyval.ttype = build1 (ADDR_EXPR, ptr_type_node, label);
		  TREE_CONSTANT (yyval.ttype) = 1; ;
    break;}
case 586:
#line 3056 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = build_pascal_unary_op (CONJ_EXPR, yyvsp[-1].ttype, 1); ;
    break;}
case 587:
#line 3058 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ if (TREE_CODE (yyvsp[-1].ttype) == COMPONENT_REF
		      && DECL_BIT_FIELD (TREE_OPERAND (yyvsp[-1].ttype, 1)))
		    error ("`sizeof' applied to a bit-field");
		  yyval.ttype = c_sizeof (TREE_TYPE (yyvsp[-1].ttype)); ;
    break;}
case 588:
#line 3063 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ if (TREE_CODE (yyvsp[-1].ttype) == COMPONENT_REF
		      && DECL_BIT_FIELD (TREE_OPERAND (yyvsp[-1].ttype, 1)))
		    error ("`alignof' applied to a bit-field");
		  if (TREE_CODE (yyvsp[-1].ttype) == INDIRECT_REF)
		    {
		      tree t = TREE_OPERAND (yyvsp[-1].ttype, 0);
		      tree best = t;
		      int bestalign = TYPE_ALIGN (TREE_TYPE (TREE_TYPE (t)));
		      while (TREE_CODE (t) == NOP_EXPR
			     && TREE_CODE (TREE_TYPE (TREE_OPERAND (t, 0))) == POINTER_TYPE)
			{
			  int thisalign;
			  t = TREE_OPERAND (t, 0);
			  thisalign = TYPE_ALIGN (TREE_TYPE (TREE_TYPE (t)));
			  if (thisalign > bestalign)
			    best = t, bestalign = thisalign;
			}
		      yyval.ttype = c_alignof (TREE_TYPE (TREE_TYPE (best)));
		    }
		  else
		    yyval.ttype = c_alignof (TREE_TYPE (yyvsp[-1].ttype)); ;
    break;}
case 589:
#line 3088 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ 
		  if (TREE_CODE (TREE_TYPE (yyvsp[0].ttype)) == REFERENCE_TYPE)
		      yyval.ttype = build_indirect_ref (yyvsp[0].ttype, "VAR parameter ref"); 
		  else if (TREE_CODE (yyvsp[0].ttype) == FUNCTION_DECL
			   || (TREE_CODE (yyvsp[0].ttype) == PARM_DECL
			       && TREE_CODE (TREE_TYPE (yyvsp[0].ttype)) == POINTER_TYPE
			       && TREE_CODE (TREE_TYPE (TREE_TYPE (yyvsp[0].ttype))) ==
			       	  FUNCTION_TYPE))
		     yyval.ttype = maybe_call_function (yyvsp[0].ttype, NULL_TREE);
		  else
		     yyval.ttype = yyvsp[0].ttype;
		;
    break;}
case 591:
#line 3105 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = output_file_node; ;
    break;}
case 592:
#line 3107 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = input_file_node; ;
    break;}
case 593:
#line 3109 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ 
		  if (PASCAL_TYPE_RESTRICTED (TREE_TYPE (yyvsp[-2].ttype)))
		    error ("Accessing fields of a restricted type object is not allowed");
		  yyval.ttype = build_component_ref (yyvsp[-2].ttype, yyvsp[0].ttype);
		;
    break;}
case 594:
#line 3115 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{
		  if (PASCAL_TYPE_RESTRICTED (TREE_TYPE (yyvsp[-2].ttype)))
		    error ("Referencing a restricted type object is not allowed");

		  if (TREE_CODE (TREE_TYPE (yyvsp[-2].ttype)) == FILE_TYPE)
		    {
		      yyval.ttype = build_buffer_ref (yyvsp[-2].ttype);
		      if (yyvsp[0].ttype)
			error ("Argument list given to a file buffer reference");
		    }
		  else if (TREE_CODE (TREE_TYPE (yyvsp[-2].ttype)) == POINTER_TYPE
			   && TREE_CODE (TREE_TYPE (TREE_TYPE (yyvsp[-2].ttype))) ==
				FUNCTION_TYPE)
		    {
		      /* Force a call by giving non-zero args
		       * If the routine has no arguments, pass empty_arglist
		       */
		      yyval.ttype = maybe_call_function (yyvsp[-2].ttype, yyvsp[0].ttype ? yyvsp[0].ttype : empty_arglist);

		      if (pedantic)
			warning ("GPC specific function call via a function pointer");
		    }
		  else if (yyvsp[0].ttype != NULL_TREE)
		    {
		      error ("Argument list given to a non-function pointer reference");
		      yyval.ttype = error_mark_node;
		    }
		  else
		    yyval.ttype = build_indirect_ref (yyvsp[-2].ttype, "^");
		;
    break;}
case 595:
#line 3146 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{
		  if (PASCAL_TYPE_RESTRICTED (TREE_TYPE (yyvsp[-3].ttype)))
		    error ("Accessing an component of a restricted type object is not allowed");

		  yyval.ttype = build_pascal_array_ref (yyvsp[-3].ttype, yyvsp[-1].ttype);
		;
    break;}
case 596:
#line 3153 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyvsp[0].itype = suspend_function_calls ();
		  yyval.ttype = lastiddecl;
		;
    break;}
case 597:
#line 3157 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ resume_function_calls (yyvsp[-3].itype);
		  if (yyvsp[-2].ttype && TREE_CODE (yyvsp[-2].ttype) == TYPE_DECL) {
		      if (pedantic)
			 warning ("ISO Pascal does not allow type casts");
		      if (list_length (yyvsp[-1].ttype) != 1) {
			 error ("type cast expects one expression argument");
			 yyval.ttype = error_mark_node;
		      } else {
			 tree type = 
			   groktypename (
				build_tree_list (build_tree_list (NULL_TREE,
						    TREE_TYPE (yyvsp[-2].ttype)),
						 DECL_NAME (yyvsp[-2].ttype)));
		         yyval.ttype = build_c_cast (type, TREE_VALUE (yyvsp[-1].ttype));
		      }
		  } else
		      yyval.ttype = build_function_call (yyvsp[-4].ttype, yyvsp[-1].ttype);
		;
    break;}
case 598:
#line 3182 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = build_set_constructor (yyvsp[-1].ttype); ;
    break;}
case 599:
#line 3187 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = NULL_TREE; ;
    break;}
case 601:
#line 3190 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ if (yyvsp[0].ttype != NULL_TREE)
		    yyval.ttype = chainon (yyvsp[-2].ttype, yyvsp[0].ttype);
                  yyerrok; ;
    break;}
case 602:
#line 3194 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ error ("need a member_designator");
                  yyval.ttype = NULL_TREE; ;
    break;}
case 603:
#line 3197 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ error ("missing comma");
                  if (yyvsp[0].ttype != NULL_TREE)
		    yyval.ttype = chainon (yyvsp[-2].ttype, yyvsp[0].ttype);
		  yyerrok; ;
    break;}
case 604:
#line 3202 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ error ("extra comma"); ;
    break;}
case 605:
#line 3209 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = construct_set_member (yyvsp[0].ttype, NULL_TREE); ;
    break;}
case 606:
#line 3211 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = construct_set_member (yyvsp[-2].ttype, yyvsp[0].ttype);;
    break;}
case 607:
#line 3216 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = build_rts_call (yyvsp[-3].itype, build_tree_list (NULL_TREE, yyvsp[-1].ttype)); ;
    break;}
case 608:
#line 3218 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = build_rts_call (yyvsp[-5].itype,
			      chainon (build_tree_list (NULL_TREE, yyvsp[-3].ttype),
				       build_tree_list (NULL_TREE, yyvsp[-1].ttype)));
		;
    break;}
case 609:
#line 3223 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = build_rts_call (yyvsp[-1].itype, yyvsp[0].ttype); ;
    break;}
case 610:
#line 3225 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = build_rts_call (yyvsp[-3].itype, yyvsp[-1].ttype); ;
    break;}
case 611:
#line 3231 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = NULL_TREE; ;
    break;}
case 612:
#line 3233 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = build_tree_list (NULL_TREE, yyvsp[-1].ttype); ;
    break;}
case 613:
#line 3238 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.itype = p_EOF; ;
    break;}
case 614:
#line 3240 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.itype = p_EOLN; ;
    break;}
case 615:
#line 3246 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.itype = p_ABS; ;
    break;}
case 616:
#line 3248 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.itype = p_SQR; ;
    break;}
case 617:
#line 3250 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.itype = p_SIN; ;
    break;}
case 618:
#line 3252 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.itype = p_COS; ;
    break;}
case 619:
#line 3254 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.itype = p_EXP; ;
    break;}
case 620:
#line 3256 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.itype = p_LN; ;
    break;}
case 621:
#line 3258 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.itype = p_SQRT; ;
    break;}
case 622:
#line 3260 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.itype = p_ARCTAN; ;
    break;}
case 623:
#line 3262 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.itype = p_ARG; ;
    break;}
case 624:
#line 3264 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.itype = p_RE; ;
    break;}
case 625:
#line 3266 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.itype = p_IM; ;
    break;}
case 626:
#line 3269 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.itype = p_TRUNC; ;
    break;}
case 627:
#line 3271 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.itype = p_ROUND; ;
    break;}
case 628:
#line 3273 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.itype = p_CARD; ;
    break;}
case 629:
#line 3276 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.itype = p_ORD; ;
    break;}
case 630:
#line 3278 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.itype = p_CHR; ;
    break;}
case 631:
#line 3281 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.itype = p_ODD; ;
    break;}
case 632:
#line 3283 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.itype = p_EMPTY; ;
    break;}
case 633:
#line 3286 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.itype = p_POSITION; ;
    break;}
case 634:
#line 3288 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.itype = p_LASTPOSITION; ;
    break;}
case 635:
#line 3291 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.itype = p_LENGTH; ;
    break;}
case 636:
#line 3293 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.itype = p_TRIM; ;
    break;}
case 637:
#line 3296 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.itype = p_BINDING; ;
    break;}
case 638:
#line 3299 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.itype = p_DATE; ;
    break;}
case 639:
#line 3301 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.itype = p_TIME; ;
    break;}
case 640:
#line 3307 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.itype = p_CMPLX; ;
    break;}
case 641:
#line 3309 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.itype = p_POLAR; ;
    break;}
case 642:
#line 3312 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.itype = p_INDEX; ;
    break;}
case 643:
#line 3314 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.itype = p_EQ; ;
    break;}
case 644:
#line 3316 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.itype = p_LT; ;
    break;}
case 645:
#line 3318 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.itype = p_GT; ;
    break;}
case 646:
#line 3320 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.itype = p_NE; ;
    break;}
case 647:
#line 3322 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.itype = p_LE; ;
    break;}
case 648:
#line 3324 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.itype = p_GE; ;
    break;}
case 649:
#line 3329 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.itype = p_SUCC; ;
    break;}
case 650:
#line 3331 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.itype = p_PRED; ;
    break;}
case 651:
#line 3333 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.itype = p_SUBSTR; ;
    break;}
case 652:
#line 3340 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.code = NE_EXPR; ;
    break;}
case 653:
#line 3342 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.code = LE_EXPR; ;
    break;}
case 654:
#line 3344 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.code = GE_EXPR; ;
    break;}
case 658:
#line 3352 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.code = TRUNC_DIV_EXPR; ;
    break;}
case 659:
#line 3354 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.code = FLOOR_MOD_EXPR; ;
    break;}
case 664:
#line 3366 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ /* No yyerrok here. */ ;
    break;}
case 665:
#line 3371 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyerrok; ;
    break;}
case 666:
#line 3373 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyerrok; ;
    break;}
case 673:
#line 3395 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{   emit_line_note (input_filename, lineno);
		    pushlevel (0);
		    clear_last_expr ();
		    expand_start_bindings (0); 
		;
    break;}
case 674:
#line 3405 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{   emit_line_note (input_filename, lineno);
		    pushlevel (0);
		    clear_last_expr ();
		    expand_start_bindings (0); 
		;
    break;}
case 675:
#line 3417 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ 
		;
    break;}
case 676:
#line 3423 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ tree decls = getdecls ();
		  emit_line_note (input_filename, lineno);
		  if (decls != NULL_TREE) {
		    expand_end_bindings (decls, 1, 0);
		    poplevel (1, 1, 0);
		  } else {
		    expand_end_bindings (decls, kept_level_p (), 0);
		    poplevel (kept_level_p (), 0, 0);
		  }
		;
    break;}
case 677:
#line 3437 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.itype = suspend_momentary (); ;
    break;}
case 678:
#line 3446 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ initialize_module (yyvsp[0].ttype);
		  if (pedantic)
		    warning ("ISO Pascal does not support modules");
		;
    break;}
case 680:
#line 3455 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ this_is_an_interface_module = 0; ;
    break;}
case 682:
#line 3458 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{
		  tree module = build_tree_list (NULL_TREE, current_module_name);
		  free_interface_list = chainon (free_interface_list, module);
		;
    break;}
case 683:
#line 3463 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ 
		  tree m = free_interface_list;
		  for (;m; m = TREE_CHAIN (m))
		    if (TREE_VALUE (m) == current_module_name)
		      {
			if (TREE_PURPOSE (m))
			  error ("Module `%s' already has an implementation part",
				 IDENTIFIER_POINTER (current_module_name));
			else
			   TREE_PURPOSE (m) = current_module_name;
		        break;
		      }

		  /* @@ Is this fatal? Should it be reported? */
		  if (! m)
		    warning ("Module `%s' has no interface module",
			     IDENTIFIER_POINTER (current_module_name));

		  this_is_an_interface_module = 0;
		;
    break;}
case 685:
#line 3486 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ if (pedantic)
		    warning ("GPC specific module declaration");
		;
    break;}
case 687:
#line 3494 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{
		  current_module_parms = yyvsp[-1].ttype;
		  associate_external_objects (current_module_parms);
		;
    break;}
case 688:
#line 3502 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ this_is_an_interface_module = 1; ;
    break;}
case 689:
#line 3507 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ ;
    break;}
case 696:
#line 3532 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ tree dir = yyvsp[0].ttype ? yyvsp[0].ttype : get_identifier ("Forward");
		  grok_directive (TREE_VALUE (yyvsp[-2].ttype), TREE_PURPOSE (yyvsp[-2].ttype),
				  dir, 0);
	      	;
    break;}
case 697:
#line 3540 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = NULL_TREE; ;
    break;}
case 698:
#line 3542 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ if (is_known_directive (yyvsp[-1].ttype))
		    yyval.ttype = yyvsp[-1].ttype;
		  else
		    yyval.ttype = NULL_TREE;
		;
    break;}
case 700:
#line 3558 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ tree context;
		  tree name = yyval.ttype = get_unique_identifier ("constructor", 1);
		  context = build_nt (CALL_EXPR, name, NULL_TREE, NULL_TREE);

		  if (! start_function (build_tree_list (NULL_TREE, void_type_node),
					context, 0))
		    YYERROR1;

		  reinit_parse_for_function ();
		  store_parm_decls ();
		  top_level_labels = 1;
		;
    break;}
case 701:
#line 3571 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{
		  tree runid = yyvsp[-3].ttype;

		  if (! runid)
		     runid = integer_one_node;
		  else if (pedantic)
		     warning ("GPC specific module initialization ordering used");
		     
		  init_constructor (lookup_name (yyvsp[-1].ttype), runid);
		;
    break;}
case 702:
#line 3582 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ un_initialize_block (getdecls (), 1);;
    break;}
case 703:
#line 3584 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ finish_function (0);
		  assemble_constructor (IDENTIFIER_POINTER (yyvsp[-6].ttype));
		;
    break;}
case 704:
#line 3591 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = NULL_TREE; ;
    break;}
case 706:
#line 3597 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ tree context;
		  tree name = yyval.ttype = get_unique_identifier ("destructor", 1);
		  context = build_nt (CALL_EXPR, name, NULL_TREE, NULL_TREE);

		  if (! start_function (build_tree_list (NULL_TREE, void_type_node),
					context, 0))
		    YYERROR1;

		  reinit_parse_for_function ();
		  store_parm_decls ();
		  top_level_labels = 1;
		;
    break;}
case 707:
#line 3611 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ un_initialize_block (getdecls (), 1);;
    break;}
case 708:
#line 3613 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ finish_function (0);
		  assemble_destructor (IDENTIFIER_POINTER (yyvsp[-5].ttype));
		;
    break;}
case 710:
#line 3622 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ ;
    break;}
case 711:
#line 3624 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ ;
    break;}
case 713:
#line 3630 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyerrok; ;
    break;}
case 714:
#line 3632 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ error ("Module specifications need an export part"); ;
    break;}
case 715:
#line 3634 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ warning ("missing semicolon");
              yyerrok; ;
    break;}
case 716:
#line 3637 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ error ("extra semicolon"); ;
    break;}
case 717:
#line 3642 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ export_interface (yyvsp[-4].ttype, yyvsp[-1].ttype); ;
    break;}
case 718:
#line 3647 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ warning ("Missing '=' after export interface identifier"); ;
    break;}
case 719:
#line 3649 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ ;
    break;}
case 721:
#line 3655 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = chainon (yyvsp[-2].ttype, yyvsp[0].ttype); ;
    break;}
case 722:
#line 3657 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = NULL_TREE; ;
    break;}
case 723:
#line 3659 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = NULL_TREE; ;
    break;}
case 724:
#line 3661 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = NULL_TREE; ;
    break;}
case 725:
#line 3666 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ if (yyvsp[0].ttype)
		    if (TREE_CODE (yyvsp[0].ttype) == TREE_LIST)
		      yyval.ttype = module_export_range (yyvsp[-1].ttype, TREE_VALUE (yyvsp[0].ttype));
		    else
		      yyval.ttype = module_export_clause (yyvsp[-1].ttype, yyvsp[0].ttype, 0);
		  else
		    yyval.ttype = module_export_clause (yyvsp[-1].ttype, NULL_TREE, 0);
		;
    break;}
case 726:
#line 3675 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = module_export_clause (yyvsp[-1].ttype, yyvsp[0].ttype, 1); ;
    break;}
case 728:
#line 3682 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = build_tree_list (NULL_TREE, yyvsp[0].ttype); ;
    break;}
case 729:
#line 3687 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = NULL_TREE; ;
    break;}
case 730:
#line 3689 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = yyvsp[0].ttype; ;
    break;}
case 732:
#line 3695 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ ;
    break;}
case 735:
#line 3704 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ warning ("Missing semicolon");
		  yyerrok;
		;
    break;}
case 736:
#line 3711 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{
		  /* Recovering from an error if id is NULL_TREE
		   * If $1 is NULL_TREE lastiddecl is one of the
		   * predefined identifiers, but it does not matter
		   * anymore.
		   */
		  if (yyvsp[-2].ttype)
		    import_interface (yyvsp[-2].ttype, yyvsp[0].ttype, yyvsp[-1].ttype != NULL_TREE);
		;
    break;}
case 737:
#line 3724 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = NULL_TREE; ;
    break;}
case 739:
#line 3730 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = NULL_TREE; ;
    break;}
case 740:
#line 3732 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = build_tree_list (NULL_TREE, yyvsp[-1].ttype); ;
    break;}
case 741:
#line 3734 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = build_tree_list (yyvsp[-1].ttype, yyvsp[-1].ttype); ;
    break;}
case 743:
#line 3740 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = chainon (yyvsp[-2].ttype, yyvsp[0].ttype); ;
    break;}
case 744:
#line 3742 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = NULL_TREE; ;
    break;}
case 745:
#line 3744 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ warning ("Missing comma");
		  yyval.ttype = chainon (yyvsp[-2].ttype, yyvsp[0].ttype);
		;
    break;}
case 746:
#line 3748 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = NULL_TREE; ;
    break;}
case 747:
#line 3753 "/src/gnu/gpc/2.5.7/gpc-parse.y"
{ yyval.ttype = build_tree_list (yyvsp[-1].ttype, yyvsp[0].ttype); ;
    break;}
}
   /* the action file gets copied in in place of this dollarsign */
#line 423 "/usr/local/lib/bison.simple"

  yyvsp -= yylen;
  yyssp -= yylen;
#ifdef YYLSP_NEEDED
  yylsp -= yylen;
#endif

#if YYDEBUG != 0
  if (yydebug)
    {
      short *ssp1 = yyss - 1;
      fprintf (stderr, "state stack now");
      while (ssp1 != yyssp)
	fprintf (stderr, " %d", *++ssp1);
      fprintf (stderr, "\n");
    }
#endif

  *++yyvsp = yyval;

#ifdef YYLSP_NEEDED
  yylsp++;
  if (yylen == 0)
    {
      yylsp->first_line = yylloc.first_line;
      yylsp->first_column = yylloc.first_column;
      yylsp->last_line = (yylsp-1)->last_line;
      yylsp->last_column = (yylsp-1)->last_column;
      yylsp->text = 0;
    }
  else
    {
      yylsp->last_line = (yylsp+yylen-1)->last_line;
      yylsp->last_column = (yylsp+yylen-1)->last_column;
    }
#endif

  /* Now "shift" the result of the reduction.
     Determine what state that goes to,
     based on the state we popped back to
     and the rule number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTBASE] + *yyssp;
  if (yystate >= 0 && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTBASE];

  goto yynewstate;

yyerrlab:   /* here on detecting error */

  if (! yyerrstatus)
    /* If not already recovering from an error, report this error.  */
    {
      ++yynerrs;

#ifdef YYERROR_VERBOSE
      yyn = yypact[yystate];

      if (yyn > YYFLAG && yyn < YYLAST)
	{
	  int size = 0;
	  char *msg;
	  int x, count;

	  count = 0;
	  for (x = 0; x < (sizeof(yytname) / sizeof(char *)); x++)
	    if (yycheck[x + yyn] == x)
	      size += strlen(yytname[x]) + 15, count++;
	  msg = (char *) xmalloc(size + 15);
	  strcpy(msg, "parse error");

	  if (count < 5)
	    {
	      count = 0;
	      for (x = 0; x < (sizeof(yytname) / sizeof(char *)); x++)
		if (yycheck[x + yyn] == x)
		  {
		    strcat(msg, count == 0 ? ", expecting `" : " or `");
		    strcat(msg, yytname[x]);
		    strcat(msg, "'");
		    count++;
		  }
	    }
	  yyerror(msg);
	  free(msg);
	}
      else
#endif /* YYERROR_VERBOSE */
	yyerror("parse error");
    }

yyerrlab1:   /* here on error raised explicitly by an action */

  if (yyerrstatus == 3)
    {
      /* if just tried and failed to reuse lookahead token after an error, discard it.  */

      /* return failure if at end of input */
      if (yychar == YYEOF)
	YYABORT;

#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Discarding token %d (%s).\n", yychar, yytname[yychar1]);
#endif

      yychar = YYEMPTY;
    }

  /* Else will try to reuse lookahead token
     after shifting the error token.  */

  yyerrstatus = 3;		/* Each real token shifted decrements this */

  goto yyerrhandle;

yyerrdefault:  /* current state does not do anything special for the error token. */

#if 0
  /* This is wrong; only states that explicitly want error tokens
     should shift them.  */
  yyn = yydefact[yystate];  /* If its default is to accept any token, ok.  Otherwise pop it.*/
  if (yyn) goto yydefault;
#endif

yyerrpop:   /* pop the current state because it cannot handle the error token */

  if (yyssp == yyss) YYABORT;
  yyvsp--;
  yystate = *--yyssp;
#ifdef YYLSP_NEEDED
  yylsp--;
#endif

#if YYDEBUG != 0
  if (yydebug)
    {
      short *ssp1 = yyss - 1;
      fprintf (stderr, "Error: state stack now");
      while (ssp1 != yyssp)
	fprintf (stderr, " %d", *++ssp1);
      fprintf (stderr, "\n");
    }
#endif

yyerrhandle:

  yyn = yypact[yystate];
  if (yyn == YYFLAG)
    goto yyerrdefault;

  yyn += YYTERROR;
  if (yyn < 0 || yyn > YYLAST || yycheck[yyn] != YYTERROR)
    goto yyerrdefault;

  yyn = yytable[yyn];
  if (yyn < 0)
    {
      if (yyn == YYFLAG)
	goto yyerrpop;
      yyn = -yyn;
      goto yyreduce;
    }
  else if (yyn == 0)
    goto yyerrpop;

  if (yyn == YYFINAL)
    YYACCEPT;

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Shifting error token, ");
#endif

  *++yyvsp = yylval;
#ifdef YYLSP_NEEDED
  *++yylsp = yylloc;
#endif

  yystate = yyn;
  goto yynewstate;
}
#line 3756 "/src/gnu/gpc/2.5.7/gpc-parse.y"

/* Lexical analyzer moved to gpc-lex.c */


/* Return a newly-allocated string whose contents concatenate
   those of s1, s2, s3.  */

static char *
concat (s1, s2, s3)
     char *s1, *s2, *s3;
{
  int len1 = strlen (s1), len2 = strlen (s2), len3 = strlen (s3);
  char *result = (char *) xmalloc (len1 + len2 + len3 + 1);

  strcpy (result, s1);
  strcpy (result + len1, s2);
  strcpy (result + len1 + len2, s3);
  *(result + len1 + len2 + len3) = 0;

  return result;
}


/* Sets the value of the 'yydebug' varable to VALUE.
   This is a function so we don't have to have YYDEBUG defined
   in order to build the compiler.  */
void
set_yydebug (value)
     int value;
{
#if YYDEBUG != 0
  yydebug = value;
#else
  warning ("YYDEBUG not defined.");
#endif
}

/*
Local variables:
mode:c
tab-width: 8
version-control: t
End:
*/
