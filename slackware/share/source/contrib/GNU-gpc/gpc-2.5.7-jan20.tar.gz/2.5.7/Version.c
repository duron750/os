char *version_string = "%PROG2%";
char *gpc_version_string = "%PROG1%(%PROG2%)";
