void user_menu_cmd ();
char *expand_format (char);
