#!/usr/local/bin/perl
# Since we use a linear search trought the block and the license and
# the warranty are quite big, we leave them at the end of the help file,
# the index will be consulted quite frequently, so we put it at the beginning. 

@help_file = <>;

foreach $line (@help_file){
    if ($line =~ /\[(.*)\]/){
	$nodes[$node_count++] = $1;
    }
}

print "\x4[Index]\nTopics:\n\n";
foreach $node (sort @nodes){
    print "\x1$node\x2$node\x3\n";
}
foreach $line (@help_file){
    $line =~ s/%NEW_NODE%/\004/g;
}
print @help_file;
