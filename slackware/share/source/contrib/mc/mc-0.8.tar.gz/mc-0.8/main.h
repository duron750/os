void toggle_clean_exec ();
void toggle_show_backup ();
void toggle_show_hidden ();
void toggle_verbose ();
void toggle_mark_move_down ();
void toggle_pause_after_run ();
void toggle_show_mini_status ();
void toggle_easy_patterns ();
void toggle_align_extensions ();
void toggle_auto_save ();
void toggle_auto_menu ();
void toggle_internal ();
void toggle_mix_all_files ();
void toggle_fast_reload ();

#define RP_CLEAR 1
#define RP_NOCLEAR 0

#define UP_OPTIMIZE 0
#define UP_RELOAD   1

#define UP_KEEPSEL (char *) -1
extern int quote;
void execute (char *command);

void untouch_bar ();
void touch_bar ();
