
/* Structure used to hold dialog values */
typedef struct {
    void   *backpointer;	/* The previous dialog */
    WINDOW *d;			/* The dialog */
    WINDOW *f;			/* The frame box */
    WINDOW *t;			/* The text */
} Dialog;

extern WINDOW *top_window;

char *input_dialog (char *header, char *text, char *def_text);
int message (int error, char *header, char *text, ...);
int error (int status, int errnum, char *text,  ...);
void create_dialog (int cols, int rows, char *header, char *text, int error);
int query_dialog (char *header, char *text, int flags, int count, ...);
void done_dialog ();

#define D_NORMAL 0
#define D_ERROR  1
#define D_INSERT 2

WINDOW *get_top_text ();
extern void (*refresh_fn)();
