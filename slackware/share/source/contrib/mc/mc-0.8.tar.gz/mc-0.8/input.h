
typedef struct {
    int  start_x;		/* column input line position */
    int  start_y;		/* row input line position */
    int  pos;			/* cursor position in the input line */
    int  first_shown;		/* Index of the first shown character */
    int  current_max_len;	/* Maximum length of input line */
    int  field_len;		/* Lenght of the editing field */
    int  color;			/* color used */
    int  first;			/* Is first keystroke? */
    char *buffer;		/* pointer to editing buffer */
    WINDOW *window;		/* pointer to window descriptor */
} Input;

void create_input (Input *iline, int x, int y, WINDOW *win, int color, int field_len, char *def_text);

void handle_char (Input *, int c_code);
void update_input (Input *in);

#define XCTRL(x) (x-'a'+1)
#define ALT(x) (0x80|x)
