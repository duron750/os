void wclr (WINDOW *w);
void define_label (WINDOW *fkeys, int index, char *text);
WINDOW *new_fkey ();
