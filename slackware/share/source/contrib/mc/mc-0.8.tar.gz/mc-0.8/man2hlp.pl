#!/usr/local/bin/perl

#open (OUTPUT, ">help") || die "Cant open help file for output";

while (<>){
    if (/^\.SH (.*)$/){
	if ($skip_section == 2){
	    $skip_section = 0;
	}
	$a = $1;
	if ($no_split){
	    print "\n$a\n";
	    $no_split = 0;
	} else {
	    $a =~ s/\"//g;
	    if (!$skip_section){
		# To work around fmt's feature of deleting ^D's
		print "%NEW_NODE%[$a]\n\n$a\n\n";
	    } else {
		$skip_section = 2;
	    }
	}
    } elsif (/^.\\"DONT_SPLIT"/){
	$no_split = 1;
    } elsif (/^.\\"SLINK"/){
	print "\0x1";
	$in_link = 1;
    } elsif (/^.\\"ELINK"/){
	$in_link = 0;
	print "\0x3";
    } elsif (/^.\\"SKIP_SECTION"/){
	$skip_section = 1;
    } elsif (/^\.PP/){
	print "\n";
    } else {
	s/^.TH.*//;
	s/^\.I (.*)\n/$1 /;
	s/^\.B (.*)\n/$1 /;
	s/^\.TP//;
	s/^\.IP/ /;
	s/^\.LP//;
	s/^\.nf//;
	s/^\.fi//;
	s@\\-@-@g;
	s@\\\\@\\@g;
	print if (!$skip_section);
    }
}

print  "\n%NEW_NODE%";
