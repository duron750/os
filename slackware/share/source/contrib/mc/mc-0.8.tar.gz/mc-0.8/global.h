extern char *home_dir;

#define min(x,y) (x>y ? y: x)
#define max(x,y) (x>y ? x: y)

void repaint_screen ();
void refresh_screen ();

#ifdef ultrix
char *strdup (char *);
#endif
