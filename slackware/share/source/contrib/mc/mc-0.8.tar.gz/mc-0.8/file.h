void copy_file_file (char *s, char *d);
void copy_file_dir (char *s, char *d);
int erase_file (char *s);
int erase_dir (char *s);
int move_file (char *s, char *d);
int move_file_dir (char *s, char *d);
extern int verbose;
