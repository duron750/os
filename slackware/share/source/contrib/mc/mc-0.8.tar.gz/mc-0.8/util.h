int msglen (char *text, int *lines);
char *trim (char *s, char *d, int len);
char *name_trunc (char *txt, int trunc_len);
char *size_trunc (long int size);
int is_exe (mode_t mode);
char *string_perm (mode_t mode_bits);
char *strip_home(char *dir);
char *extension (char *);
char *split_extension (char *, int pad);
extern int easy_patterns;
extern int align_extensions;
void *xmalloc (int, char *);

int set_int (char *, char *, int);
int get_int (char *, char *, int);

char *load_file (char *filename);

#ifdef ultrix
#define S_ISLNK(x) (((x) & S_IFLNK) == S_IFLNK)
#define S_ISSOCK(x) (((x) & S_IFSOCK) == S_IFSOCK)
#endif

char *get_group (int);
char *get_owner (int);
char *file_date (time_t);
char *file_date_pck (time_t);
int exist_file (char *name);

/* Returns a copy of *s until a \n is found and is below top */
char *extract_line (char *s, char *top);
char *icase_search (char *text, char *data);
int regexp_match (char *pattern, char *string);

int my_system (char *shell, char *command);
void save_stop_handler ();
