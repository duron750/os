

#ifdef __STDC__
#define HEADER(func,type,arg)func(type arg,...)
#else
#define HEADER(func,type,arg)func(arg)type arg;
#endif

#ifdef USE_VARARGS
#include<varargs.h>
#else
#include<stdarg.h>
#endif
#include<stdio.h>



static int indentation= 0;




#ifdef USE_VARARGS


void debug(va_alist)
va_dcl
{
	va_list ap;
	char *format;

	va_start(ap);
	format= va_arg(ap,char *);
	/*6:*/

	{
		int i;
		for(i= indentation *2;i>0;i--)
			(void)putc(' ',stderr);
	}

	/*:6*/

	(void)vfprintf(stderr,format,ap);
	va_end(ap);
}

#else

void HEADER(debug,char *,format)
{
	va_list ap;

	va_start(ap,format);
	/*6:*/

	{
		int i;
		for(i= indentation *2;i>0;i--)
			(void)putc(' ',stderr);
	}

	/*:6*/

	(void)vfprintf(stderr,format,ap);
	va_end(ap);
}

#endif





#ifdef USE_VARARGS

void debug0(va_alist)
va_dcl
{
	va_list ap;
	char *format;

	va_start(ap);
	format= va_arg(ap,char *);
	(void)vfprintf(stderr,format,ap);
	va_end(ap);
}

#else

void HEADER(debug0,char *,format)
{
	va_list ap;

	va_start(ap,format);
	(void)vfprintf(stderr,format,ap);
	va_end(ap);
}

#endif





#ifdef USE_VARARGS

void enter(va_alist)
va_dcl
{
	va_list ap;
	char *format;

	va_start(ap);
	format= va_arg(ap,char *);
	/*6:*/

	{
		int i;
		for(i= indentation *2;i>0;i--)
			(void)putc(' ',stderr);
	}

	/*:6*/

	(void)fprintf(stderr,"> ");
	(void)vfprintf(stderr,format,ap);
	indentation++;
	va_end(ap);
}

#else

void HEADER(enter,char *,format)
{
	va_list ap;

	va_start(ap,format);
	/*6:*/

	{
		int i;
		for(i= indentation *2;i>0;i--)
			(void)putc(' ',stderr);
	}

	/*:6*/

	(void)fprintf(stderr,"> ");
	(void)vfprintf(stderr,format,ap);
	indentation++;
	va_end(ap);
}

#endif





#ifdef USE_VARARGS

void leave(va_alist)
va_dcl
{
	va_list ap;
	char *format;

	va_start(ap);
	format= va_arg(ap,char *);
	indentation--;
	/*6:*/

	{
		int i;
		for(i= indentation *2;i>0;i--)
			(void)putc(' ',stderr);
	}

	/*:6*/

	(void)fprintf(stderr,"< ");
	(void)vfprintf(stderr,format,ap);
	va_end(ap);
}

#else

void HEADER(leave,char *,format)
{
	va_list ap;

	va_start(ap,format);
	indentation--;
	/*6:*/

	{
		int i;
		for(i= indentation *2;i>0;i--)
			(void)putc(' ',stderr);
	}

	/*:6*/

	(void)fprintf(stderr,"< ");
	(void)vfprintf(stderr,format,ap);
	va_end(ap);
}

#endif



