/*2:*/
#line 36 "types.web"

typedef struct _STRING *STRING;

/*:2*//*3:*/
#line 93 "types.web"

typedef enum{Undefined,Proc,Var,Type,Def,Incl,Trans}DeclTp;
typedef struct _Decl{
DeclTp tp;
int lineno;
STRING typesym,type;
STRING namesym,name;
STRING valuesym,value;
struct _Decl *params;
STRING body;
struct _Decl *next;
} *Decl;

/*:3*//*4:*/
#line 110 "types.web"

#line 111 "types.web"
typedef struct _Section{
STRING text;
Decl decl;
struct _Section *next;
} *Section;

/*:4*//*5:*/
#line 121 "types.web"

#line 122 "types.web"
typedef struct _Option{
STRING opt,val;
struct _Option *next;
} *Option;

/*:5*//*6:*/
#line 132 "types.web"

#line 133 "types.web"
typedef struct _Class{
int lineno;
STRING name,superclass,filename;
Option options;
STRING text;
Section classvars,publicvars,privatevars,methods,actions,
translations,imports,exports,utilities;
struct _Class *daughters, *sister, *super;
struct _Class *next;
} *Class;

/*:6*//*7:*/
#line 146 "types.web"

#line 147 "types.web"
#ifndef False
typedef enum{False,True}Boolean;
#endif

/*:7*/
