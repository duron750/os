typedef union {
  STRING string;
  Option option;
  Class class;
  Section section;
  Decl decl;
  int i;
} YYSTYPE;
#define	CLASS	258
#define	CLASSVARS	259
#define	PUBLIC	260
#define	PRIVATE	261
#define	METHODS	262
#define	ACTIONS	263
#define	TRANSLATIONS	264
#define	IMPORTS	265
#define	EXPORTS	266
#define	UTILITIES	267
#define	VAR	268
#define	DEF	269
#define	TYPE	270
#define	PROC	271
#define	TRANS	272
#define	INCL	273
#define	TEXT	274
#define	BRACKETED	275
#define	ILL_CHAR	276
#define	UNKNOWN	277
#define	ILL_BODY	278
#define	NOCODE	279
#define	NODOC	280
#define	GUARD	281
#define	GUARDP	282
#define	FILE_OPT	283
#define	IDENT	284
#define	LPAR	285
#define	RPAR	286
#define	STAR	287
#define	NUMBER	288
#define	LBRACK	289
#define	RBRACK	290
#define	SEMI	291
#define	EQUALS	292
#define	PLUS	293
#define	COMMA	294
#define	COLON	295
#define	TILDE	296
#define	EXCLAM	297
#define	CTOK	298
#define	CSTRING	299
#define	BODY	300
#define	COMMENT	301


extern YYSTYPE yylval;
